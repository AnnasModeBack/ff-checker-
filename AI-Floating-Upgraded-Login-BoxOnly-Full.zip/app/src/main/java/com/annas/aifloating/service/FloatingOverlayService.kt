package com.annas.aifloating.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.R
import com.annas.aifloating.overlay.ScreenSelectionOverlayView
import java.net.URLEncoder
import kotlin.math.abs

class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloating.START"
        const val ACTION_STOP = "com.annas.aifloating.STOP"
        const val ACTION_HIDE_ICON = "com.annas.aifloating.HIDE_ICON"
        const val ACTION_SHOW_ICON = "com.annas.aifloating.SHOW_ICON"
        const val ACTION_OPEN_GOOGLE_LOGIN = "com.annas.aifloating.OPEN_GOOGLE_LOGIN"

        private const val NOTIF_ID = 2026
        private const val GOOGLE_AI_MODE_URL = "https://www.google.com/search?udm=50"
        private const val GOOGLE_LOGIN_URL =
            "https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fwww.google.com%2Fsearch%3Fudm%3D50"

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        var isIconHidden: Boolean = false
    }

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubbleView: View? = null
    private var verticalBarView: View? = null
    private var cropOverlayView: ScreenSelectionOverlayView? = null
    private var hiddenHandleView: View? = null
    private var webWindowView: View? = null
    private var webView: WebView? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var vbarParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var webParams: WindowManager.LayoutParams? = null

    private var tvWindowModeTitle: TextView? = null
    private var statusBanner: LinearLayout? = null
    private var tvProcessingStatus: TextView? = null
    private var isFullscreenMode: Boolean = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                cleanupAllResources()
                isRunning = false
                isIconHidden = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    hideBubbleToEdge()
                }
                return START_STICKY
            }
            ACTION_SHOW_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    collapseToBubble()
                }
                return START_STICKY
            }
            ACTION_OPEN_GOOGLE_LOGIN -> {
                if (Settings.canDrawOverlays(this)) {
                    isRunning = true
                    startForegroundCompat()
                    openFloatingWeb(
                        url = GOOGLE_LOGIN_URL,
                        title = "Login Akun Google AI",
                        processingHint = "Masuk akun Google agar sesi Google AI Mode aktif di jendela mengambang."
                    )
                }
                return START_STICKY
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning = false
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        isIconHidden = false
        startForegroundCompat()
        collapseToBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanupAllResources()
        isRunning = false
        isIconHidden = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundCompat() {
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun getScreenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    private fun collapseToBubble() {
        removeCropOverlay()
        verticalBarView?.visibility = View.GONE
        hiddenHandleView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (bubbleView != null) {
            bubbleView?.visibility = View.VISIBLE
            snapBubbleToNearestEdge()
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 280
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                hideBubbleToEdge()
                Toast.makeText(
                    this,
                    "Icon disembunyikan. Ketuk panah tepi layar atau notifikasi untuk memunculkan lagi.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 650)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    val metrics = getScreenMetrics()
                    params.x = (startX + dx).coerceIn(0, (metrics.widthPixels - 140).coerceAtLeast(0))
                    params.y = (startY + dy).coerceIn(40, (metrics.heightPixels - 180).coerceAtLeast(40))
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!isDragging && !longPressTriggered && event.action == MotionEvent.ACTION_UP) {
                        openVerticalBar()
                    } else if (isDragging) {
                        snapBubbleToNearestEdge()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    private fun snapBubbleToNearestEdge() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        val metrics = getScreenMetrics()
        val bubbleW = if (view.width > 0) view.width else (60 * metrics.density).toInt()
        val maxX = (metrics.widthPixels - bubbleW - 12).coerceAtLeast(12)
        val targetX = if (params.x + bubbleW / 2 < metrics.widthPixels / 2) 12 else maxX

        ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                try {
                    if (view.parent != null) {
                        windowManager.updateViewLayout(view, params)
                    }
                } catch (_: Exception) {
                }
            }
            start()
        }
    }

    // Hanya 2 tombol: [+] Kotak Seleksi Area -> Google AI Mode, dan [⌄] Lipat ke Bubble
    private fun openVerticalBar() {
        bubbleView?.visibility = View.GONE
        removeCropOverlay()

        val bx = bubbleParams?.x ?: 16
        val by = bubbleParams?.y ?: 280
        val metrics = getScreenMetrics()
        val barWidthPx = (66 * metrics.density).toInt()
        val safeX = bx.coerceIn(12, (metrics.widthPixels - barWidthPx - 12).coerceAtLeast(12))
        val safeY = by.coerceIn(60, (metrics.heightPixels - (170 * metrics.density).toInt()).coerceAtLeast(60))

        if (verticalBarView != null) {
            vbarParams?.x = safeX
            vbarParams?.y = safeY
            try {
                windowManager.updateViewLayout(verticalBarView, vbarParams)
            } catch (_: Exception) {
            }
            verticalBarView?.visibility = View.VISIBLE
            return
        }

        val barView = LayoutInflater.from(this).inflate(R.layout.floating_vertical_bar, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = safeX
            y = safeY
        }

        barView.findViewById<LinearLayout>(R.id.btnVbarCropBox).setOnClickListener {
            ScreenTextAccessibilityService.instance?.captureCurrentScreenBlocks()
            showCropSelectionBox()
        }

        barView.findViewById<LinearLayout>(R.id.btnVbarCollapse).setOnClickListener {
            collapseToBubble()
        }

        vbarParams = params
        verticalBarView = barView
        windowManager.addView(barView, params)
    }

    private fun showCropSelectionBox() {
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        removeCropOverlay()

        val cropView = ScreenSelectionOverlayView(
            context = this,
            onCancelCrop = {
                removeCropOverlay()
                collapseToBubble()
            },
            onConfirmCrop = { selectedRect ->
                removeCropOverlay()
                processCroppedSelectionToGoogleAi(selectedRect)
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        cropOverlayView = cropView
        windowManager.addView(cropView, params)
    }

    private fun removeCropOverlay() {
        cropOverlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        cropOverlayView = null
    }

    private fun processCroppedSelectionToGoogleAi(cropRect: Rect) {
        val a11y = ScreenTextAccessibilityService.instance
        if (a11y == null) {
            openFloatingWeb(
                url = GOOGLE_AI_MODE_URL,
                title = "Google AI Mode",
                processingHint = "Aktifkan Pembaca Teks Area Kotak agar teks di kotak langsung terkirim ke Google AI Mode."
            )
            return
        }

        val extractedText = a11y.extractTextInsideRect(cropRect)
        if (extractedText.isNotBlank()) {
            val trimmed = if (extractedText.length > 900) extractedText.substring(0, 900) else extractedText
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            val googleAiUrl = "$GOOGLE_AI_MODE_URL&q=$encoded"
            openFloatingWeb(
                url = googleAiUrl,
                title = "Google AI Mode",
                processingHint = "Mengirim area kotak ke Google AI Mode..."
            )
        } else {
            openFloatingWeb(
                url = GOOGLE_AI_MODE_URL,
                title = "Google AI Mode",
                processingHint = "Area kotak dipilih — langsung ke Google AI Mode."
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openFloatingWeb(url: String, title: String, processingHint: String?) {
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        hiddenHandleView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (webWindowView != null) {
            tvWindowModeTitle?.text = title
            if (!processingHint.isNullOrBlank()) {
                statusBanner?.visibility = View.VISIBLE
                tvProcessingStatus?.text = processingHint
                mainHandler.postDelayed({ statusBanner?.visibility = View.GONE }, 2200)
            } else {
                statusBanner?.visibility = View.GONE
            }
            webWindowView?.visibility = View.VISIBLE
            applyWindowSize(fullscreen = true)
            webView?.loadUrl(url)
            return
        }

        val wView = LayoutInflater.from(this).inflate(R.layout.floating_web_window, null)
        val metrics = getScreenMetrics()
        val fullW = (metrics.widthPixels * 0.94f).toInt()
        val fullH = (metrics.heightPixels * 0.84f).toInt()

        val params = WindowManager.LayoutParams(
            fullW,
            fullH,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val headerDrag = wView.findViewById<LinearLayout>(R.id.headerDragBar)
        val titleView = wView.findViewById<TextView>(R.id.tvWindowModeTitle)
        val btnGoogleLogin = wView.findViewById<TextView>(R.id.btnFloatingGoogleLogin)
        val btnRecrop = wView.findViewById<ImageButton>(R.id.btnQuickRecrop)
        val btnBack = wView.findViewById<ImageButton>(R.id.btnWebBack)
        val btnRefresh = wView.findViewById<ImageButton>(R.id.btnWebRefresh)
        val btnToggleSize = wView.findViewById<ImageButton>(R.id.btnToggleSize)
        val btnHideAll = wView.findViewById<ImageButton>(R.id.btnHideAll)
        val btnCloseRed = wView.findViewById<LinearLayout>(R.id.btnCloseAiRed)
        val banner = wView.findViewById<LinearLayout>(R.id.statusProcessingBanner)
        val bannerText = wView.findViewById<TextView>(R.id.tvProcessingStatus)
        val progressBar = wView.findViewById<ProgressBar>(R.id.webProgressBar)
        val wv = wView.findViewById<WebView>(R.id.floatingWebView)

        titleView.text = title
        if (!processingHint.isNullOrBlank()) {
            banner.visibility = View.VISIBLE
            bannerText.text = processingHint
            mainHandler.postDelayed({ banner.visibility = View.GONE }, 2200)
        }

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(wv, true)

        wv.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val targetUrl = view?.hitTestResult?.extra
                if (!targetUrl.isNullOrBlank()) {
                    view.loadUrl(targetUrl)
                }
                return false
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val targetUrl = request?.url?.toString() ?: return false
                if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
                    view?.loadUrl(targetUrl)
                }
                return true
            }
        }

        btnGoogleLogin.setOnClickListener {
            titleView.text = "Login Akun Google AI"
            wv.loadUrl(GOOGLE_LOGIN_URL)
        }

        btnRecrop.setOnClickListener {
            ScreenTextAccessibilityService.instance?.captureCurrentScreenBlocks()
            showCropSelectionBox()
        }

        btnBack.setOnClickListener {
            if (wv.canGoBack()) wv.goBack()
        }

        btnRefresh.setOnClickListener {
            wv.reload()
        }

        btnToggleSize.setOnClickListener {
            isFullscreenMode = !isFullscreenMode
            applyWindowSize(fullscreen = isFullscreenMode)
        }

        btnHideAll.setOnClickListener {
            hideBubbleToEdge()
        }

        btnCloseRed.setOnClickListener {
            cookieManager.flush()
            collapseToBubble()
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        headerDrag.setOnTouchListener { _, event ->
            if (isFullscreenMode) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try {
                        windowManager.updateViewLayout(wView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }

        wv.loadUrl(url)
        isFullscreenMode = true
        tvWindowModeTitle = titleView
        statusBanner = banner
        tvProcessingStatus = bannerText
        webView = wv
        webParams = params
        webWindowView = wView
        windowManager.addView(wView, params)
    }

    private fun applyWindowSize(fullscreen: Boolean) {
        val wView = webWindowView ?: return
        val params = webParams ?: return
        val metrics = getScreenMetrics()
        isFullscreenMode = fullscreen
        if (fullscreen) {
            params.width = (metrics.widthPixels * 0.94f).toInt()
            params.height = (metrics.heightPixels * 0.84f).toInt()
            params.gravity = Gravity.CENTER
            params.x = 0
            params.y = 0
        } else {
            params.width = (metrics.widthPixels * 0.86f).toInt()
            params.height = (metrics.heightPixels * 0.56f).toInt()
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 24
            params.y = 140
        }
        try {
            windowManager.updateViewLayout(wView, params)
        } catch (_: Exception) {
        }
    }

    private fun hideBubbleToEdge() {
        isIconHidden = true
        removeCropOverlay()
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        updateNotification()

        if (hiddenHandleView != null) {
            hiddenHandleView?.visibility = View.VISIBLE
            return
        }

        val hView = LayoutInflater.from(this).inflate(R.layout.floating_hidden_handle, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = bubbleParams?.y ?: 280
        }

        var startY = 0
        var touchY = 0f
        var isDragging = false

        hView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = params.y
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dy) > 10) isDragging = true
                    params.y = (startY + dy).coerceAtLeast(40)
                    try {
                        windowManager.updateViewLayout(hView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        collapseToBubble()
                    }
                    true
                }
                else -> false
            }
        }

        handleParams = params
        hiddenHandleView = hView
        windowManager.addView(hView, params)
    }

    private fun cleanupAllResources() {
        mainHandler.removeCallbacksAndMessages(null)
        removeCropOverlay()

        try {
            CookieManager.getInstance().flush()
        } catch (_: Exception) {
        }

        webView?.destroy()
        webView = null
        webWindowView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        webWindowView = null

        verticalBarView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        verticalBarView = null

        hiddenHandleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        hiddenHandleView = null

        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleView = null
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleVisIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = if (isIconHidden) ACTION_SHOW_ICON else ACTION_HIDE_ICON
        }
        val pendingToggleVis = PendingIntent.getService(
            this, 2, toggleVisIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val offIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingOff = PendingIntent.getService(
            this, 1, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isIconHidden) "AI Floating (Icon Tersembunyi)" else "AI Floating Aktif"
        val text = if (isIconHidden) {
            "Ketuk 'Munculkan Lagi' untuk menampilkan bubble SVG."
        } else {
            "Pencet bubble lalu pakai Kotak Seleksi (+) ke Google AI Mode."
        }
        val toggleBtnText = if (isIconHidden) "Munculkan Lagi" else "Sembunyikan"

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, toggleBtnText, pendingToggleVis)
            .addAction(0, "OFF", pendingOff)
            .build()
    }
}
