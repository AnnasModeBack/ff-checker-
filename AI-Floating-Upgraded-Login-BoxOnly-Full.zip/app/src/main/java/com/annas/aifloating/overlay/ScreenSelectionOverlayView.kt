package com.annas.aifloating.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.annas.aifloating.R
import kotlin.math.abs
import kotlin.math.hypot

class ScreenSelectionOverlayView(
    context: Context,
    private val onCancelCrop: () -> Unit,
    private val onConfirmCrop: (Rect) -> Unit
) : View(context) {

    private enum class DragMode {
        NONE, MOVE,
        TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT,
        LEFT, TOP, RIGHT, BOTTOM
    }

    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#90000000")
        style = Paint.Style.FILL
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC00F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 3.6f
    }

    private val handleOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7700FF9D")
        style = Paint.Style.FILL
    }

    private val handleInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F000F0FF")
        style = Paint.Style.FILL
    }

    private val actionDockFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F20F172A")
        style = Paint.Style.FILL
    }

    private val actionDockStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6600F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
    }

    private val cancelBtnFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E53935")
        style = Paint.Style.FILL
    }

    private val confirmBtnFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.FILL
    }

    private val iconCancel: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_svg_crop_cancel)
    private val iconConfirm: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_svg_crop_confirm)

    private val cropBox = RectF()
    private val dockRect = RectF()
    private val cancelBtnRect = RectF()
    private val confirmBtnRect = RectF()

    private var initialized = false
    private var dragMode = DragMode.NONE
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private val minBoxSize = 110f
    private val touchSlopRadius = 70f

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!initialized && w > 0 && h > 0) {
            val boxW = w * 0.82f
            val boxH = h * 0.34f
            val left = (w - boxW) / 2f
            val top = (h - boxH) / 2.35f
            cropBox.set(left, top, left + boxW, top + boxH)
            initialized = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        canvas.drawRoundRect(cropBox, 26f, 26f, clearPaint)
        canvas.drawRoundRect(cropBox, 26f, 26f, borderPaint)

        val handles = listOf(
            cropBox.left to cropBox.top,
            cropBox.right to cropBox.top,
            cropBox.left to cropBox.bottom,
            cropBox.right to cropBox.bottom,
            cropBox.left to cropBox.centerY(),
            cropBox.right to cropBox.centerY(),
            cropBox.centerX() to cropBox.top,
            cropBox.centerX() to cropBox.bottom
        )
        for ((hx, hy) in handles) {
            canvas.drawCircle(hx, hy, 22f, handleOuterPaint)
            canvas.drawCircle(hx, hy, 11f, handleInnerPaint)
        }

        val btnW = 86f
        val btnH = 74f
        val innerGap = 14f
        val dockPad = 14f
        val dockW = btnW * 2 + innerGap + dockPad * 2
        val dockH = btnH + dockPad * 2

        val dockCx = cropBox.centerX().coerceIn(dockW / 2f + 20f, width - dockW / 2f - 20f)
        val preferredDockTop = cropBox.bottom + 18f
        val dockTop = if (preferredDockTop + dockH <= height - 30f) {
            preferredDockTop
        } else {
            (cropBox.top - dockH - 18f).coerceAtLeast(60f)
        }

        dockRect.set(dockCx - dockW / 2f, dockTop, dockCx + dockW / 2f, dockTop + dockH)
        canvas.drawRoundRect(dockRect, 20f, 20f, actionDockFill)
        canvas.drawRoundRect(dockRect, 20f, 20f, actionDockStroke)

        val cancelLeft = dockRect.left + dockPad
        val cancelTop = dockRect.top + dockPad
        cancelBtnRect.set(cancelLeft, cancelTop, cancelLeft + btnW, cancelTop + btnH)
        canvas.drawRoundRect(cancelBtnRect, 14f, 14f, cancelBtnFill)
        iconCancel?.let {
            val iconHalf = 22
            it.setBounds(
                (cancelBtnRect.centerX() - iconHalf).toInt(),
                (cancelBtnRect.centerY() - iconHalf).toInt(),
                (cancelBtnRect.centerX() + iconHalf).toInt(),
                (cancelBtnRect.centerY() + iconHalf).toInt()
            )
            it.draw(canvas)
        }

        val confirmLeft = cancelBtnRect.right + innerGap
        val confirmTop = dockRect.top + dockPad
        confirmBtnRect.set(confirmLeft, confirmTop, confirmLeft + btnW, confirmTop + btnH)
        canvas.drawRoundRect(confirmBtnRect, 14f, 14f, confirmBtnFill)
        iconConfirm?.let {
            val iconHalf = 24
            it.setBounds(
                (confirmBtnRect.centerX() - iconHalf).toInt(),
                (confirmBtnRect.centerY() - iconHalf).toInt(),
                (confirmBtnRect.centerX() + iconHalf).toInt(),
                (confirmBtnRect.centerY() + iconHalf).toInt()
            )
            it.draw(canvas)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelBtnRect.contains(x, y)) {
                    onCancelCrop()
                    return true
                }
                if (confirmBtnRect.contains(x, y)) {
                    val resultRect = Rect(
                        cropBox.left.toInt().coerceAtLeast(0),
                        cropBox.top.toInt().coerceAtLeast(0),
                        cropBox.right.toInt().coerceAtMost(width),
                        cropBox.bottom.toInt().coerceAtMost(height)
                    )
                    onConfirmCrop(resultRect)
                    return true
                }

                dragMode = detectDragMode(x, y)
                lastTouchX = x
                lastTouchY = y
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = x - lastTouchX
                val dy = y - lastTouchY
                lastTouchX = x
                lastTouchY = y
                applyBoxTransform(dx, dy)
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragMode = DragMode.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun detectDragMode(x: Float, y: Float): DragMode {
        if (hypot(x - cropBox.left, y - cropBox.top) <= touchSlopRadius) return DragMode.TOP_LEFT
        if (hypot(x - cropBox.right, y - cropBox.top) <= touchSlopRadius) return DragMode.TOP_RIGHT
        if (hypot(x - cropBox.left, y - cropBox.bottom) <= touchSlopRadius) return DragMode.BOTTOM_LEFT
        if (hypot(x - cropBox.right, y - cropBox.bottom) <= touchSlopRadius) return DragMode.BOTTOM_RIGHT

        if (abs(x - cropBox.left) <= touchSlopRadius && y in cropBox.top..cropBox.bottom) return DragMode.LEFT
        if (abs(x - cropBox.right) <= touchSlopRadius && y in cropBox.top..cropBox.bottom) return DragMode.RIGHT
        if (abs(y - cropBox.top) <= touchSlopRadius && x in cropBox.left..cropBox.right) return DragMode.TOP
        if (abs(y - cropBox.bottom) <= touchSlopRadius && x in cropBox.left..cropBox.right) return DragMode.BOTTOM

        if (cropBox.contains(x, y)) return DragMode.MOVE
        return DragMode.NONE
    }

    private fun applyBoxTransform(dx: Float, dy: Float) {
        val maxW = width.toFloat()
        val maxH = height.toFloat()

        when (dragMode) {
            DragMode.MOVE -> {
                var newLeft = cropBox.left + dx
                var newTop = cropBox.top + dy
                if (newLeft < 0f) newLeft = 0f
                if (newTop < 0f) newTop = 0f
                if (newLeft + cropBox.width() > maxW) newLeft = maxW - cropBox.width()
                if (newTop + cropBox.height() > maxH) newTop = maxH - cropBox.height()
                cropBox.offsetTo(newLeft, newTop)
            }
            DragMode.TOP_LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.TOP_RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.BOTTOM_LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.BOTTOM_RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
            }
            DragMode.RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
            }
            DragMode.TOP -> {
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.BOTTOM -> {
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.NONE -> Unit
        }
    }
}
