package com.aifloating.ultra;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LauncherMainActivity extends AppCompatActivity {

    private static final String DEFAULT_GEMINI_URL = "https://gemini.google.com/app";

    private UltraPreferences prefs;
    private CheckBox cbMarkedGoGemini;
    private Switch swStealth;
    private Switch swAutoRevive;
    private EditText etMarkedPrompt;
    private EditText etGeminiApiKey;
    private EditText etStealthLabel;
    private EditText etTargetUrl;
    private TextView tvStatusPill;

    private boolean suppressCheckbox = false;
    private boolean pendingAfterPermission = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new UltraPreferences(this);
        setContentView(R.layout.activity_launcher_ultra);

        android.view.View heroCard = findViewById(R.id.card_hero);
        android.view.View controlCard = findViewById(R.id.card_controls);
        if (heroCard != null) heroCard.startAnimation(AnimationUtils.loadAnimation(this, R.anim.card_slide_up));
        if (controlCard != null) controlCard.startAnimation(AnimationUtils.loadAnimation(this, R.anim.card_fade_in));

        tvStatusPill = findViewById(R.id.tv_status_pill);
        cbMarkedGoGemini = findViewById(R.id.cb_marked_go_gemini);
        swStealth = findViewById(R.id.sw_stealth);
        swAutoRevive = findViewById(R.id.sw_auto_revive);
        etMarkedPrompt = findViewById(R.id.et_marked_prompt);
        etGeminiApiKey = findViewById(R.id.et_gemini_api_key);
        etStealthLabel = findViewById(R.id.et_main_stealth_label);
        etTargetUrl = findViewById(R.id.et_exam_url);

        ImageButton btnPasteMarked = findViewById(R.id.btn_paste_marked);
        Button btnStartFloating = findViewById(R.id.btn_start_floating);
        Button btnStopFloating = findViewById(R.id.btn_stop_floating);
        Button btnOpenExam = findViewById(R.id.btn_open_exam_mode);
        Button btnPermission = findViewById(R.id.btn_grant_perms);

        swStealth.setChecked(prefs.isStealthMode());
        swAutoRevive.setChecked(prefs.isAutoReviveEnabled());
        etMarkedPrompt.setText(prefs.getInitialMarkedQuery());
        etGeminiApiKey.setText(prefs.getGeminiApiKey());
        etStealthLabel.setText(prefs.getStealthName());

        String savedUrl = prefs.getLastTargetUrl();
        if (savedUrl == null || savedUrl.trim().isEmpty()) {
            savedUrl = DEFAULT_GEMINI_URL;
        }
        etTargetUrl.setText(savedUrl);

        suppressCheckbox = true;
        cbMarkedGoGemini.setChecked(prefs.isFloatingEnabled());
        suppressCheckbox = false;

        btnPasteMarked.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                if (cs != null && !cs.toString().trim().isEmpty()) {
                    etMarkedPrompt.setText(cs.toString().trim());
                    Toast.makeText(this, "Teks dari clipboard ditempel", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            Toast.makeText(this, "Clipboard masih kosong", Toast.LENGTH_SHORT).show();
        });

        cbMarkedGoGemini.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (suppressCheckbox) return;
            buttonView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.bubble_pop));
            saveFormToPrefs();

            if (isChecked) {
                if (!UltraOverlayHelper.hasOverlayPermission(this)) {
                    pendingAfterPermission = true;
                    Toast.makeText(this, "Aktifkan izin Tampil di atas aplikasi lain, lalu otomatis ke Gemini", Toast.LENGTH_LONG).show();
                    UltraOverlayHelper.openOverlaySettings(this);
                    return;
                }
                executeCheckedFlow();
            } else {
                stopFloatingService();
            }
        });

        btnPermission.setOnClickListener(v -> {
            UltraOverlayHelper.openOverlaySettings(this);
            UltraOverlayHelper.requestIgnoreBatteryOptimization(this);
        });

        btnStartFloating.setOnClickListener(v -> {
            saveFormToPrefs();
            if (!UltraOverlayHelper.hasOverlayPermission(this)) {
                Toast.makeText(this, "Aktifkan izin Tampil di atas aplikasi lain terlebih dahulu", Toast.LENGTH_LONG).show();
                UltraOverlayHelper.openOverlaySettings(this);
                return;
            }
            prefs.setFloatingEnabled(true);
            UltraAiApp.ensureServiceRunning(this, true);
            setCheckboxSilent(true);
            refreshStatusPill();
            Toast.makeText(this, "Gemini Floating Ultra aktif & anti-mati", Toast.LENGTH_SHORT).show();
        });

        btnStopFloating.setOnClickListener(v -> {
            stopFloatingService();
            Toast.makeText(this, "Gemini Floating dihentikan", Toast.LENGTH_SHORT).show();
        });

        btnOpenExam.setOnClickListener(v -> {
            saveFormToPrefs();
            if (UltraOverlayHelper.hasOverlayPermission(this)) {
                prefs.setFloatingEnabled(true);
                UltraAiApp.ensureServiceRunning(this, true);
                setCheckboxSilent(true);
            }
            openBrowserWithMarkedQuery(resolveTargetUrl(), etMarkedPrompt.getText().toString().trim());
        });

        handleIncomingTextIntent(getIntent());
        refreshStatusPill();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingTextIntent(intent);
    }

    private void handleIncomingTextIntent(Intent intent) {
        if (intent == null) return;
        String incoming = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Intent.ACTION_PROCESS_TEXT.equals(intent.getAction())) {
            CharSequence selected = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
            if (selected != null) incoming = selected.toString();
        } else if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            incoming = intent.getStringExtra(Intent.EXTRA_TEXT);
        }

        if (incoming != null && !incoming.trim().isEmpty()) {
            String text = incoming.trim();
            etMarkedPrompt.setText(text);
            saveFormToPrefs();
            if (UltraOverlayHelper.hasOverlayPermission(this)) {
                executeCheckedFlow();
            } else {
                pendingAfterPermission = true;
                UltraOverlayHelper.openOverlaySettings(this);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatusPill();
        if (pendingAfterPermission && UltraOverlayHelper.hasOverlayPermission(this)) {
            pendingAfterPermission = false;
            executeCheckedFlow();
        } else {
            setCheckboxSilent(prefs.isFloatingEnabled() && UltraOverlayHelper.hasOverlayPermission(this));
        }
    }

    private void executeCheckedFlow() {
        prefs.setFloatingEnabled(true);
        UltraAiApp.ensureServiceRunning(this, true);
        setCheckboxSilent(true);
        refreshStatusPill();

        String markedText = etMarkedPrompt.getText().toString().trim();
        if (!markedText.isEmpty()) {
            Intent askIntent = new Intent(this, UltraFloatingService.class);
            askIntent.setAction(UltraFloatingService.ACTION_ASK_MARKED);
            askIntent.putExtra(UltraFloatingService.EXTRA_MARKED_TEXT, markedText);
            startService(askIntent);
        }

        openBrowserWithMarkedQuery(resolveTargetUrl(), markedText);
    }

    private void openBrowserWithMarkedQuery(String baseUrl, String markedText) {
        String finalUrl = baseUrl;
        if (!markedText.isEmpty() && baseUrl.contains("gemini.google.com")) {
            finalUrl = "https://gemini.google.com/app?q=" + Uri.encode(markedText);
        }
        Intent intent = new Intent(this, ExamBrowserActivity.class);
        intent.putExtra(ExamBrowserActivity.EXTRA_URL, finalUrl);
        intent.putExtra(ExamBrowserActivity.EXTRA_MARKED_TEXT, markedText);
        startActivity(intent);
    }

    private void stopFloatingService() {
        prefs.setFloatingEnabled(false);
        Intent stop = new Intent(this, UltraFloatingService.class);
        stop.setAction(UltraFloatingService.ACTION_STOP);
        startService(stop);
        setCheckboxSilent(false);
        refreshStatusPill();
    }

    private String resolveTargetUrl() {
        String url = etTargetUrl.getText().toString().trim();
        if (url.isEmpty()) {
            url = DEFAULT_GEMINI_URL;
        } else if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }
        return url;
    }

    private void setCheckboxSilent(boolean checked) {
        suppressCheckbox = true;
        cbMarkedGoGemini.setChecked(checked);
        suppressCheckbox = false;
    }

    private void saveFormToPrefs() {
        prefs.setStealthMode(swStealth.isChecked());
        prefs.setAutoReviveEnabled(swAutoRevive.isChecked());
        prefs.setInitialMarkedQuery(etMarkedPrompt.getText().toString());
        prefs.setGeminiApiKey(etGeminiApiKey.getText().toString());
        prefs.setStealthName(etStealthLabel.getText().toString());
        prefs.setLastTargetUrl(resolveTargetUrl());
    }

    private void refreshStatusPill() {
        boolean perm = UltraOverlayHelper.hasOverlayPermission(this);
        boolean active = prefs.isFloatingEnabled();
        if (!perm) {
            tvStatusPill.setText("Izin Overlay Belum Aktif");
        } else if (active) {
            tvStatusPill.setText(prefs.isStealthMode()
                    ? "Floating ON • Mode Menyamar Aktif"
                    : "Floating ON • Gemini Direct API Aktif");
        } else {
            tvStatusPill.setText("Centang Kotak SVG untuk Langsung ke Gemini");
        }
    }
}
