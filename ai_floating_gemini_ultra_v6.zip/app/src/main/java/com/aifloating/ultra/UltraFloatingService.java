package com.aifloating.ultra;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;

public class UltraFloatingService extends Service {

    public static final String ACTION_START = "com.aifloating.ultra.action.START";
    public static final String ACTION_STOP = "com.aifloating.ultra.action.STOP";
    public static final String ACTION_STEALTH = "com.aifloating.ultra.action.STEALTH";
    public static final String ACTION_ASK_MARKED = "com.aifloating.ultra.action.ASK_MARKED";
    public static final String EXTRA_MARKED_TEXT = "extra_marked_text";

    private static final String CHANNEL_ID = "ultra_gemini_floating_channel_v6";
    private static final int NOTIF_ID = 9906;
    private static final long WATCHDOG_MS = 8000L;

    private WindowManager wm;
    private View bubbleView;
    private View panelView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;

    private UltraPreferences prefs;
    private GeminiDirectClient aiClient;
    private PowerManager.WakeLock wakeLock;
    private ObjectAnimator bubbleRotateAnim;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<GeminiDirectClient.Turn> history = new ArrayList<>();

    private boolean panelOpen = false;
    private boolean panelCompact = false;
    private boolean stealthMode = false;
    private boolean panicHidden = false;
    private boolean userStopped = false;

    private TextView tvTitle;
    private TextView tvSub;
    private ScrollView svChat;
    private LinearLayout llChat;
    private EditText etInput;
    private Button btnSend;
    private Button btnToggleStealth;
    private Button btnPanic;
    private Button btnOpenBrowser;
    private Button btnPasteClipboard;
    private View settingsPanel;
    private EditText etCfgApiKey;
    private EditText etCfgModel;
    private EditText etCfgStealthName;
    private EditText etCfgPin;

    private final Runnable watchdogRunnable = new Runnable() {
        @Override
        public void run() {
            if (!userStopped && prefs.isFloatingEnabled()) {
                ensureBubbleAttached();
                updateNotification();
                handler.postDelayed(this, WATCHDOG_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new UltraPreferences(this);
        aiClient = new GeminiDirectClient(prefs);
        stealthMode = prefs.isStealthMode();
        prefs.setFloatingEnabled(true);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        acquireWakeLock();
        createChannel();
        startForeground(NOTIF_ID, buildNotif());

        buildBubble();
        buildPanel();
        ensureBubbleAttached();
        handler.postDelayed(watchdogRunnable, WATCHDOG_MS);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String act = intent.getAction();
            if (ACTION_STOP.equals(act)) {
                userStopped = true;
                prefs.setFloatingEnabled(false);
                stopSelf();
                return START_NOT_STICKY;
            } else if (ACTION_STEALTH.equals(act)) {
                toggleStealth();
            } else if (ACTION_ASK_MARKED.equals(act)) {
                String marked = intent.getStringExtra(EXTRA_MARKED_TEXT);
                if (marked != null && !marked.trim().isEmpty()) {
                    openPanel();
                    submitPromptToGemini(marked.trim());
                }
            }
        }
        userStopped = false;
        prefs.setFloatingEnabled(true);
        ensureBubbleAttached();
        updateNotification();
        return START_STICKY;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "UltraGeminiFloating::KeepAliveV6");
                wakeLock.acquire(8 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
    }

    private void buildBubble() {
        bubbleView = LayoutInflater.from(this).inflate(R.layout.layout_floating_bubble, null);
        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = prefs.getBubbleX();
        bubbleParams.y = prefs.getBubbleY();

        ImageView ivIcon = bubbleView.findViewById(R.id.iv_bubble_svg);
        if (ivIcon != null) {
            bubbleRotateAnim = ObjectAnimator.ofFloat(ivIcon, "rotation", 0f, 360f);
            bubbleRotateAnim.setDuration(8500L);
            bubbleRotateAnim.setRepeatCount(ValueAnimator.INFINITE);
            bubbleRotateAnim.setInterpolator(new AccelerateDecelerateInterpolator());
            bubbleRotateAnim.start();
        }

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private boolean dragged = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        dragged = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downX);
                        int dy = (int) (event.getRawY() - downY);
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) dragged = true;
                        bubbleParams.x = Math.max(0, startX + dx);
                        bubbleParams.y = Math.max(0, startY + dy);
                        safeUpdateView(bubbleView, bubbleParams);
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!dragged) {
                            v.startAnimation(AnimationUtils.loadAnimation(UltraFloatingService.this, R.anim.bubble_pop));
                            togglePanel();
                        } else {
                            int width = getResources().getDisplayMetrics().widthPixels;
                            int mid = bubbleParams.x + (v.getWidth() / 2);
                            int targetX = (mid < width / 2) ? 14 : Math.max(14, width - v.getWidth() - 14);
                            animateBubbleSnap(bubbleParams.x, targetX);
                        }
                        return true;
                }
                return false;
            }
        });

        applyBubbleAppearance();
    }

    private void animateBubbleSnap(int fromX, int toX) {
        ValueAnimator anim = ValueAnimator.ofInt(fromX, toX);
        anim.setDuration(220L);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            bubbleParams.x = (int) a.getAnimatedValue();
            safeUpdateView(bubbleView, bubbleParams);
        });
        anim.start();
        prefs.saveBubblePos(toX, bubbleParams.y);
    }

    private void ensureBubbleAttached() {
        if (!UltraOverlayHelper.hasOverlayPermission(this) || bubbleView == null) return;
        try {
            if (bubbleView.getWindowToken() == null) {
                wm.addView(bubbleView, bubbleParams);
            }
            applyBubbleAppearance();
        } catch (Exception ignored) {
        }
    }

    private void safeUpdateView(View view, WindowManager.LayoutParams params) {
        try {
            if (view != null && view.getWindowToken() != null) {
                wm.updateViewLayout(view, params);
            }
        } catch (Exception ignored) {
        }
    }

    private void buildPanel() {
        panelView = LayoutInflater.from(this).inflate(R.layout.layout_floating_panel, null);
        int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.74f);

        panelParams = new WindowManager.LayoutParams(
                w,
                h,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.CENTER;

        tvTitle = panelView.findViewById(R.id.tv_panel_title);
        tvSub = panelView.findViewById(R.id.tv_panel_sub);
        svChat = panelView.findViewById(R.id.sv_chat);
        llChat = panelView.findViewById(R.id.ll_chat);
        etInput = panelView.findViewById(R.id.et_input);
        btnSend = panelView.findViewById(R.id.btn_send);
        btnToggleStealth = panelView.findViewById(R.id.btn_toggle_stealth);
        btnPanic = panelView.findViewById(R.id.btn_panic);
        btnOpenBrowser = panelView.findViewById(R.id.btn_open_exam);
        btnPasteClipboard = panelView.findViewById(R.id.btn_paste_clip);
        ImageButton btnResize = panelView.findViewById(R.id.btn_resize_panel);
        ImageButton btnClose = panelView.findViewById(R.id.btn_close);
        ImageButton btnGear = panelView.findViewById(R.id.btn_gear);
        Button btnClear = panelView.findViewById(R.id.btn_clear);

        Button chipSolve = panelView.findViewById(R.id.chip_solve_fast);
        Button chipExplain = panelView.findViewById(R.id.chip_explain);
        Button chipTranslate = panelView.findViewById(R.id.chip_translate);

        settingsPanel = panelView.findViewById(R.id.ll_settings_panel);
        etCfgApiKey = panelView.findViewById(R.id.et_cfg_api_key);
        etCfgModel = panelView.findViewById(R.id.et_cfg_model);
        etCfgStealthName = panelView.findViewById(R.id.et_cfg_stealth_name);
        etCfgPin = panelView.findViewById(R.id.et_cfg_pin);
        Button btnSaveCfg = panelView.findViewById(R.id.btn_save_cfg);

        syncUiLabels();
        addSysMsg("Gemini Floating Ultra v6 siap. Gunakan tombol cepat atau tekan 'Tempel Soal'.");

        btnResize.setOnClickListener(v -> {
            panelCompact = !panelCompact;
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            panelParams.width = (int) (sw * (panelCompact ? 0.86f : 0.94f));
            panelParams.height = (int) (sh * (panelCompact ? 0.48f : 0.74f));
            safeUpdateView(panelView, panelParams);
            Toast.makeText(this, panelCompact ? "Ukuran Panel: Mini" : "Ukuran Panel: Penuh", Toast.LENGTH_SHORT).show();
        });

        btnClose.setOnClickListener(v -> closePanel());
        btnToggleStealth.setOnClickListener(v -> toggleStealth());
        btnPanic.setOnClickListener(v -> activatePanicHide());

        btnOpenBrowser.setOnClickListener(v -> {
            closePanel();
            Intent i = new Intent(this, ExamBrowserActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });

        btnPasteClipboard.setOnClickListener(v -> {
            String clipText = readClipboardText();
            if (!clipText.isEmpty()) {
                etInput.setText(clipText);
                submitPromptToGemini(clipText);
            } else {
                Toast.makeText(this, "Clipboard kosong — salin teks dulu", Toast.LENGTH_SHORT).show();
            }
        });

        chipSolve.setOnClickListener(v -> runQuickChip("Jawab cepat & tepat dengan pilihan/hasil akhir yang jelas:\n"));
        chipExplain.setOnClickListener(v -> runQuickChip("Jelaskan langkah-langkah penyelesaian soal ini secara singkat:\n"));
        chipTranslate.setOnClickListener(v -> runQuickChip("Terjemahkan ke Bahasa Indonesia yang natural dan jelas:\n"));

        btnClear.setOnClickListener(v -> {
            history.clear();
            llChat.removeAllViews();
            addSysMsg("Riwayat percakapan dibersihkan.");
        });

        btnGear.setOnClickListener(v -> {
            boolean open = settingsPanel.getVisibility() != View.VISIBLE;
            if (open) {
                etCfgApiKey.setText(prefs.getGeminiApiKey());
                etCfgModel.setText(prefs.getModel());
                etCfgStealthName.setText(prefs.getStealthName());
            }
            settingsPanel.setVisibility(open ? View.VISIBLE : View.GONE);
        });

        btnSaveCfg.setOnClickListener(v -> {
            String pinInput = etCfgPin.getText().toString().trim();
            if (prefs.isPinEnabled() && !pinInput.isEmpty() && !prefs.verifyPin(pinInput)) {
                Toast.makeText(this, "PIN lama tidak cocok", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.setGeminiApiKey(etCfgApiKey.getText().toString());
            prefs.setModel(etCfgModel.getText().toString());
            prefs.setStealthName(etCfgStealthName.getText().toString());
            if (!pinInput.isEmpty()) {
                prefs.setPin(pinInput);
                etCfgPin.setText("");
            }
            stealthMode = prefs.isStealthMode();
            syncUiLabels();
            applyBubbleAppearance();
            updateNotification();
            settingsPanel.setVisibility(View.GONE);
            Toast.makeText(this, "Pengaturan & API Key tersimpan aman", Toast.LENGTH_SHORT).show();
        });

        btnSend.setOnClickListener(v -> {
            String q = etInput.getText().toString().trim();
            if (q.isEmpty()) return;
            etInput.setText("");
            submitPromptToGemini(q);
        });
    }

    private void runQuickChip(String prefix) {
        String current = etInput.getText().toString().trim();
        if (current.isEmpty()) {
            current = readClipboardText();
        }
        if (current.isEmpty()) {
            Toast.makeText(this, "Ketik atau salin teks terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }
        etInput.setText("");
        submitPromptToGemini(prefix + current);
    }

    private String readClipboardText() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                if (cs != null) return cs.toString().trim();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private void submitPromptToGemini(String q) {
        history.add(new GeminiDirectClient.Turn("user", q));
        addChatBubble("Pertanyaan", q, true);

        btnSend.setEnabled(false);
        tvSub.setText("Gemini sedang memproses...");

        aiClient.ask(q, history, stealthMode, new GeminiDirectClient.ResponseCallback() {
            @Override
            public void onResult(String reply) {
                handler.post(() -> {
                    btnSend.setEnabled(true);
                    syncUiLabels();
                    history.add(new GeminiDirectClient.Turn("model", reply));
                    addChatBubble(stealthMode ? prefs.getStealthName() : "Gemini AI", reply, false);
                });
            }

            @Override
            public void onError(String reason) {
                handler.post(() -> {
                    btnSend.setEnabled(true);
                    syncUiLabels();
                    addSysMsg("Info: " + reason);
                });
            }
        });
    }

    private void togglePanel() {
        if (panicHidden) {
            panicHidden = false;
            applyBubbleAppearance();
        }
        if (panelOpen) {
            closePanel();
        } else {
            openPanel();
        }
    }

    private void openPanel() {
        ensureBubbleAttached();
        if (panelView != null && panelView.getWindowToken() == null) {
            try {
                wm.addView(panelView, panelParams);
                panelView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.panel_zoom_in));
                panelOpen = true;
                syncUiLabels();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal membuka panel: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void closePanel() {
        if (panelOpen && panelView != null && panelView.getWindowToken() != null) {
            try {
                wm.removeView(panelView);
            } catch (Exception ignored) {
            }
        }
        panelOpen = false;
    }

    private void toggleStealth() {
        stealthMode = !stealthMode;
        prefs.setStealthMode(stealthMode);
        syncUiLabels();
        applyBubbleAppearance();
        updateNotification();
        Toast.makeText(this, stealthMode ? "Mode Menyamar: ON" : "Mode Menyamar: OFF", Toast.LENGTH_SHORT).show();
    }

    private void activatePanicHide() {
        closePanel();
        panicHidden = true;
        bubbleParams.x = 0;
        bubbleParams.y = 85;
        safeUpdateView(bubbleView, bubbleParams);
        if (bubbleView != null) {
            bubbleView.setAlpha(0.14f);
        }
        Toast.makeText(this, "Disamarkan ke sudut atas (ketuk sudut untuk munculkan)", Toast.LENGTH_SHORT).show();
    }

    private void applyBubbleAppearance() {
        if (bubbleView == null) return;
        TextView tvTag = bubbleView.findViewById(R.id.tv_bubble_label);
        ImageView ivIcon = bubbleView.findViewById(R.id.iv_bubble_svg);
        if (tvTag != null) {
            tvTag.setText(stealthMode ? prefs.getStealthName() : "GEMINI AI");
        }
        if (ivIcon != null) {
            ivIcon.setImageResource(stealthMode ? R.drawable.ic_svg_shield : R.drawable.ic_ultra_logo);
        }
        if (panicHidden) {
            bubbleView.setAlpha(0.14f);
        } else {
            bubbleView.setAlpha(stealthMode ? Math.min(prefs.getBubbleAlpha(), 0.72f) : prefs.getBubbleAlpha());
        }
    }

    private void syncUiLabels() {
        if (tvTitle != null) {
            tvTitle.setText(stealthMode ? prefs.getStealthName() + " • Stealth" : "Gemini Floating Ultra");
        }
        if (tvSub != null) {
            tvSub.setText(stealthMode ? "Menyamar ON • Direct API" : "Direct Gemini API • Tanpa Proxy");
        }
        if (btnToggleStealth != null) {
            btnToggleStealth.setText(stealthMode ? "Menyamar: ON" : "Menyamar: OFF");
        }
    }

    private void addChatBubble(String sender, String msg, boolean isUser) {
        TextView tv = new TextView(this);
        String shown = msg;
        if (stealthMode && !isUser && msg.length() > 160) {
            shown = msg.substring(0, 160) + "... [Mode Menyamar: tekan lama untuk salin penuh]";
        }
        tv.setText(sender + ":\n" + shown);
        tv.setTextColor(0xFFF3F4F6);
        tv.setTextSize(13f);
        tv.setPadding(24, 16, 24, 16);
        tv.setBackgroundResource(isUser ? R.drawable.bg_bubble_user : R.drawable.bg_bubble_ai);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, 12);
        tv.setLayoutParams(lp);
        tv.startAnimation(AnimationUtils.loadAnimation(this, R.anim.card_fade_in));

        tv.setOnLongClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("GeminiAI", msg));
                Toast.makeText(this, "Jawaban lengkap disalin", Toast.LENGTH_SHORT).show();
            }
            return true;
        });

        llChat.addView(tv);
        svChat.post(() -> svChat.fullScroll(View.FOCUS_DOWN));
    }

    private void addSysMsg(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFF9CA3AF);
        tv.setTextSize(12f);
        tv.setPadding(12, 6, 12, 10);
        llChat.addView(tv);
        svChat.post(() -> svChat.fullScroll(View.FOCUS_DOWN));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    stealthMode ? prefs.getStealthName() + " Sync" : "Gemini Floating Ultra",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif() {
        Intent stealthIntent = new Intent(this, UltraFloatingService.class);
        stealthIntent.setAction(ACTION_STEALTH);
        PendingIntent piStealth = PendingIntent.getService(
                this, 10, stealthIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, UltraFloatingService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(
                this, 11, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String title = stealthMode ? prefs.getStealthName() + " Background" : "Gemini Floating Ultra Aktif";
        String text = stealthMode
                ? "Layanan berjalan • Bubble mengambang aktif"
                : "Asisten Gemini Direct API siap di semua layar";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_ultra_logo)
                .setOngoing(true)
                .addAction(0, "Menyamar", piStealth)
                .addAction(0, "Matikan", piStop)
                .build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIF_ID, buildNotif());
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (!userStopped && prefs.isFloatingEnabled() && prefs.isAutoReviveEnabled()) {
            Intent revive = new Intent(this, ServiceGuardReceiver.class);
            revive.setAction(ServiceGuardReceiver.ACTION_RESTART_SERVICE);
            sendBroadcast(revive);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(watchdogRunnable);
        if (bubbleRotateAnim != null) {
            bubbleRotateAnim.cancel();
        }
        closePanel();
        if (bubbleView != null && bubbleView.getWindowToken() != null) {
            try {
                wm.removeView(bubbleView);
            } catch (Exception ignored) {
            }
        }
        releaseWakeLock();
        if (!userStopped && prefs != null && prefs.isFloatingEnabled() && prefs.isAutoReviveEnabled()) {
            Intent revive = new Intent(this, ServiceGuardReceiver.class);
            revive.setAction(ServiceGuardReceiver.ACTION_RESTART_SERVICE);
            sendBroadcast(revive);
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
