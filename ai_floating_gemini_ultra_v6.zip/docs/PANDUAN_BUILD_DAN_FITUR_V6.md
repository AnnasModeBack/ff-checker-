# AI Floating Gemini Ultra v6 (Cyber SVG Pro + Build AI Floating APK)

## Cara Build APK di GitHub Actions
1. Upload atau ekstrak ZIP ke repository GitHub (workflow `.github/workflows/build-apk.yml` dibiarkan persis sama dan mendukung auto-extract ZIP).
2. Jalankan workflow **Build AI Floating APK** di tab **Actions**.
3. Unduh artifact **AI-Floating-APK** yang berisi `app-debug.apk` dan `app-release-unsigned.apk`.

## Peningkatan Terbaru di v6
- **Animasi Edge-Snap & Memori Posisi Bubble**: Bubble floating meluncur halus ke tepi layar saat dilepas dan menyimpan koordinat terakhirnya.
- **Tombol Resize Panel (Mini / Penuh)**: Ubah ukuran jendela floating antara mode ringkas (48% layar) dan penuh (74% layar) dengan satu ketukan ikon panah diagonal SVG.
- **Dukungan Share Intent (`ACTION_SEND`) & Blok Teks (`ACTION_PROCESS_TEXT`)**: Kirim atau blok teks dari browser/aplikasi mana pun langsung ke Gemini Floating.
- **Direct Gemini API Multi-Model Fallback**: Otomatis mencoba `gemini-2.5-flash` -> `gemini-2.0-flash` -> `gemini-1.5-flash` tanpa perantara proxy.
