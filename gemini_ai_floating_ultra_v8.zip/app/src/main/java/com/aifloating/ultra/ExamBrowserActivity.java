package com.aifloating.ultra;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class ExamBrowserActivity extends AppCompatActivity {

    public static final String EXTRA_URL = "extra_exam_url";
    public static final String EXTRA_MARKED_TEXT = "extra_marked_text";

    private WebView webView;
    private EditText etUrlBar;
    private ProgressBar progressBar;
    private UltraPreferences prefs;
    private String markedText = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new UltraPreferences(this);
        setContentView(R.layout.activity_exam_browser);

        etUrlBar = findViewById(R.id.et_url_bar);
        progressBar = findViewById(R.id.pb_exam_load);
        webView = findViewById(R.id.wv_exam);
        Button btnGo = findViewById(R.id.btn_go_url);
        Button btnFormShortcut = findViewById(R.id.btn_form_shortcut);
        Button btnStealthQuick = findViewById(R.id.btn_exam_stealth);

        markedText = getIntent().getStringExtra(EXTRA_MARKED_TEXT);
        if (markedText == null) markedText = "";

        CookieManager.getInstance().setAcceptCookie(true);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null) {
                    etUrlBar.setText(url);
                    prefs.setLastTargetUrl(url);
                }
                if (!markedText.isEmpty() && url != null && url.contains("gemini.google.com")) {
                    String quoted = JSONObject.quote(markedText);
                    String js = "(function(){try{var el=document.querySelector('textarea,[contenteditable=\"true\"]');"
                            + "if(el){el.focus();if(el.tagName==='TEXTAREA'){el.value=" + quoted + ";}else{el.innerText=" + quoted + ";}"
                            + "el.dispatchEvent(new Event('input',{bubbles:true}));}}catch(e){}})();";
                    view.evaluateJavascript(js, null);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });

        String targetUrl = getIntent().getStringExtra(EXTRA_URL);
        if (targetUrl == null || targetUrl.trim().isEmpty()) {
            targetUrl = prefs.getLastTargetUrl();
        }
        if (targetUrl == null || targetUrl.trim().isEmpty()) {
            targetUrl = "https://gemini.google.com/app";
        }
        etUrlBar.setText(targetUrl);
        webView.loadUrl(targetUrl);

        btnGo.setOnClickListener(v -> {
            String raw = etUrlBar.getText().toString().trim();
            if (raw.isEmpty()) return;
            if (!raw.startsWith("http://") && !raw.startsWith("https://")) {
                raw = "https://" + raw;
            }
            prefs.setLastTargetUrl(raw);
            webView.loadUrl(raw);
        });

        btnFormShortcut.setOnClickListener(v -> {
            String formUrl = "https://docs.google.com/forms/";
            etUrlBar.setText(formUrl);
            webView.loadUrl(formUrl);
        });

        btnStealthQuick.setOnClickListener(v -> {
            boolean next = !prefs.isStealthMode();
            prefs.setStealthMode(next);
            Intent i = new Intent(this, UltraFloatingService.class);
            i.setAction(UltraFloatingService.ACTION_STEALTH);
            startService(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs.isFloatingEnabled()) {
            UltraAiApp.ensureServiceRunning(this, false);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
