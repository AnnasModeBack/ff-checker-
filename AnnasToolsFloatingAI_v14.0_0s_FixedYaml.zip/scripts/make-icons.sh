#!/usr/bin/env bash
set -e
python3 -c '
import os
from PIL import Image
src = "app/src/main/assets/icon.jpg"
res = "app/src/main/res"
sizes = {"mipmap-mdpi": 48, "mipmap-hdpi": 72, "mipmap-xhdpi": 96, "mipmap-xxhdpi": 144, "mipmap-xxxhdpi": 192}
if os.path.exists(src):
    im = Image.open(src).convert("RGBA")
    for folder, px in sizes.items():
        out_dir = os.path.join(res, folder)
        os.makedirs(out_dir, exist_ok=True)
        resized = im.resize((px, px), Image.Resampling.LANCZOS)
        resized.save(os.path.join(out_dir, "ic_launcher.png"), "PNG")
        resized.save(os.path.join(out_dir, "ic_launcher_round.png"), "PNG")
'
