package com.annas.aifloating.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.R
import java.net.URLEncoder
import kotlin.math.abs

class FloatingChromeService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloating.START"
        const val ACTION_STOP = "com.annas.aifloating.STOP"
        const val ACTION_HIDE_ICON = "com.annas.aifloating.HIDE_ICON"
        const val ACTION_SHOW_ICON = "com.annas.aifloating.SHOW_ICON"
        private const val NOTIF_ID = 2026
        private const val HOME_URL = "https://www.google.com"

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        var isIconHidden: Boolean = false
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var hiddenHandleView: View? = null
    private var webWindowView: View? = null
    private var webView: WebView? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var webParams: WindowManager.LayoutParams? = null

    private var isFullscreenMode: Boolean = true
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                removeAllViews()
                isRunning = false
                isIconHidden = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    hideBubbleToEdge()
                }
                return START_STICKY
            }
            ACTION_SHOW_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    restoreBubbleFromEdge()
                }
                return START_STICKY
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning = false
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        isIconHidden = false
        startForeground(NOTIF_ID, buildNotification())
        showBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllViews()
        isRunning = false
        isIconHidden = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    private fun showBubble() {
        hiddenHandleView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (bubbleView != null) {
            bubbleView?.visibility = View.VISIBLE
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                hideBubbleToEdge()
                Toast.makeText(
                    this,
                    "Icon disembunyikan! Ketuk panah tepi kiri atau notifikasi untuk memunculkan lagi.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 650)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    params.x = (startX + dx).coerceAtLeast(0)
                    params.y = (startY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!isDragging && !longPressTriggered && event.action == MotionEvent.ACTION_UP) {
                        openFullscreenOverlayWeb()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    private fun hideBubbleToEdge() {
        isIconHidden = true
        bubbleView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        updateNotification()

        if (hiddenHandleView != null) {
            hiddenHandleView?.visibility = View.VISIBLE
            return
        }

        val hView = LayoutInflater.from(this).inflate(R.layout.floating_hidden_handle, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = bubbleParams?.y ?: 280
        }

        var startY = 0
        var touchY = 0f
        var isDragging = false

        hView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = params.y
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dy) > 10) isDragging = true
                    params.y = (startY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(hView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        restoreBubbleFromEdge()
                    }
                    true
                }
                else -> false
            }
        }

        handleParams = params
        hiddenHandleView = hView
        windowManager.addView(hView, params)
    }

    private fun restoreBubbleFromEdge() {
        isIconHidden = false
        hiddenHandleView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        showBubble()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openFullscreenOverlayWeb() {
        bubbleView?.visibility = View.GONE
        hiddenHandleView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (webWindowView != null) {
            webWindowView?.visibility = View.VISIBLE
            applyWindowSize(fullscreen = true)
            return
        }

        val wView = LayoutInflater.from(this).inflate(R.layout.floating_web_window, null)
        val (screenW, screenH) = getScreenDimensions()
        val fullW = (screenW * 0.96f).toInt()
        val fullH = (screenH * 0.88f).toInt()

        val params = WindowManager.LayoutParams(
            fullW,
            fullH,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val headerDrag = wView.findViewById<LinearLayout>(R.id.headerDragBar)
        val btnBack = wView.findViewById<ImageButton>(R.id.btnWebBack)
        val btnForward = wView.findViewById<ImageButton>(R.id.btnWebForward)
        val btnRefresh = wView.findViewById<ImageButton>(R.id.btnWebRefresh)
        val btnToggleSize = wView.findViewById<ImageButton>(R.id.btnToggleSize)
        val btnHideAll = wView.findViewById<ImageButton>(R.id.btnHideAll)
        val btnMinimize = wView.findViewById<ImageButton>(R.id.btnMinimizeWeb)
        val etUrl = wView.findViewById<EditText>(R.id.etWebUrl)
        val btnGo = wView.findViewById<LinearLayout>(R.id.btnWebGo)
        val progressBar = wView.findViewById<ProgressBar>(R.id.webProgressBar)
        val wv = wView.findViewById<WebView>(R.id.floatingWebView)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val targetUrl = request?.url?.toString() ?: return false
                if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
                    view?.loadUrl(targetUrl)
                    etUrl.setText(targetUrl)
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    etUrl.setText(url)
                }
            }
        }

        fun navigateFromInput() {
            val raw = etUrl.text.toString().trim()
            if (raw.isEmpty()) {
                wv.loadUrl(HOME_URL)
                return
            }
            val finalUrl = when {
                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                else -> "https://www.google.com/search?q=" + URLEncoder.encode(raw, "UTF-8")
            }
            wv.loadUrl(finalUrl)
        }

        btnGo.setOnClickListener { navigateFromInput() }

        etUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateFromInput()
                true
            } else {
                false
            }
        }

        btnBack.setOnClickListener {
            if (wv.canGoBack()) wv.goBack()
        }

        btnForward.setOnClickListener {
            if (wv.canGoForward()) wv.goForward()
        }

        btnRefresh.setOnClickListener {
            wv.reload()
        }

        btnToggleSize.setOnClickListener {
            isFullscreenMode = !isFullscreenMode
            applyWindowSize(fullscreen = isFullscreenMode)
        }

        btnHideAll.setOnClickListener {
            hideBubbleToEdge()
        }

        btnMinimize.setOnClickListener {
            webWindowView?.visibility = View.GONE
            bubbleView?.visibility = View.VISIBLE
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        headerDrag.setOnTouchListener { _, event ->
            if (isFullscreenMode) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    params.x = startX + dx
                    params.y = startY + dy
                    try {
                        windowManager.updateViewLayout(wView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }

        wv.loadUrl(HOME_URL)
        isFullscreenMode = true
        webView = wv
        webParams = params
        webWindowView = wView
        windowManager.addView(wView, params)
    }

    private fun applyWindowSize(fullscreen: Boolean) {
        val wView = webWindowView ?: return
        val params = webParams ?: return
        val (screenW, screenH) = getScreenDimensions()
        isFullscreenMode = fullscreen
        if (fullscreen) {
            params.width = (screenW * 0.96f).toInt()
            params.height = (screenH * 0.88f).toInt()
            params.gravity = Gravity.CENTER
            params.x = 0
            params.y = 0
        } else {
            params.width = (screenW * 0.85f).toInt()
            params.height = (screenH * 0.55f).toInt()
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 24
            params.y = 140
        }
        try {
            windowManager.updateViewLayout(wView, params)
        } catch (_: Exception) {
        }
    }

    private fun removeAllViews() {
        mainHandler.removeCallbacksAndMessages(null)
        webView?.destroy()
        webView = null
        webWindowView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        webWindowView = null

        hiddenHandleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        hiddenHandleView = null

        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleView = null
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleVisActionIntent = Intent(this, FloatingChromeService::class.java).apply {
            action = if (isIconHidden) ACTION_SHOW_ICON else ACTION_HIDE_ICON
        }
        val pendingToggleVis = PendingIntent.getService(
            this, 2, toggleVisActionIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val offIntent = Intent(this, FloatingChromeService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingOff = PendingIntent.getService(
            this, 1, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusTitle = if (isIconHidden) {
            "AI Floating (Icon Tersembunyi)"
        } else {
            "AI Floating Aktif"
        }
        val statusText = if (isIconHidden) {
            "Ketuk 'Munculkan Lagi' di bawah untuk menampilkan icon Chrome."
        } else {
            "Ketuk icon mengambang untuk Chrome Full Layar."
        }
        val toggleLabel = if (isIconHidden) "Munculkan Lagi" else "Sembunyikan"

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle(statusTitle)
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, toggleLabel, pendingToggleVis)
            .addAction(0, "OFF", pendingOff)
            .build()
    }
}
