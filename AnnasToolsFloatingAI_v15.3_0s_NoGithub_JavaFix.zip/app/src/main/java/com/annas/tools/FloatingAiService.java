package com.annas.tools;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingAiService extends Service {

    public static volatile boolean isRunning = false;
    public static volatile boolean autoLoopRunning = false;
    public static FloatingAiService instance = null;

    private WindowManager windowManager;
    private LinearLayout rootContainer;
    private TextView floatingBubble;
    private LinearLayout controlPanel;
    private TextView statusBadge;
    private TextView liveStatusText;
    private TextView answerHighlightText;
    private Button btnAutoLoop;
    private Button btnSingleSolve;

    private boolean isExpanded = false;
    private volatile boolean isBusy = false;
    private String lastSolvedQuestionHash = "";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private final Runnable sequentialLoopRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isRunning || !autoLoopRunning) return;
            if (!isBusy) {
                processOneQuestion(true);
            }
            if (isRunning && autoLoopRunning) {
                mainHandler.postDelayed(this, 0L);
            }
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        instance = this;
        startForegroundNotif();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 24;
        params.y = 240;

        rootContainer = new LinearLayout(this);
        rootContainer.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColor(Color.parseColor("#0B1120"));
        bubbleBg.setStroke(5, Color.parseColor("#22D3EE"));

        floatingBubble = new TextView(this);
        floatingBubble.setText("0s");
        floatingBubble.setTextColor(Color.parseColor("#22D3EE"));
        floatingBubble.setTextSize(16f);
        floatingBubble.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        floatingBubble.setGravity(Gravity.CENTER);
        floatingBubble.setWidth(138);
        floatingBubble.setHeight(138);
        floatingBubble.setBackground(bubbleBg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            floatingBubble.setElevation(18f);
        }

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(34f);
        panelBg.setColor(Color.parseColor("#F50B1120"));
        panelBg.setStroke(3, Color.parseColor("#22D3EE"));

        controlPanel = new LinearLayout(this);
        controlPanel.setOrientation(LinearLayout.VERTICAL);
        controlPanel.setBackground(panelBg);
        controlPanel.setPadding(26, 22, 26, 22);
        controlPanel.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            controlPanel.setElevation(24f);
        }

        LinearLayout topHeader = new LinearLayout(this);
        topHeader.setOrientation(LinearLayout.HORIZONTAL);
        topHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView panelTitle = new TextView(this);
        panelTitle.setText("ANNAS AI 0s ENGINE");
        panelTitle.setTextColor(Color.parseColor("#F8FAFC"));
        panelTitle.setTextSize(13f);
        panelTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panelTitle.setPadding(0, 0, 14, 0);

        statusBadge = new TextView(this);
        statusBadge.setText("0s READY");
        statusBadge.setTextColor(Color.parseColor("#22D3EE"));
        statusBadge.setTextSize(10.5f);
        statusBadge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);

        topHeader.addView(panelTitle);
        topHeader.addView(statusBadge);

        liveStatusText = new TextView(this);
        liveStatusText.setText("Status: Siap eksekusi instan 0s di layar.");
        liveStatusText.setTextColor(Color.parseColor("#CBD5E1"));
        liveStatusText.setTextSize(12f);
        liveStatusText.setPadding(0, 10, 0, 6);
        liveStatusText.setMaxWidth(620);

        answerHighlightText = new TextView(this);
        answerHighlightText.setText("Rekomendasi Jawaban: -");
        answerHighlightText.setTextColor(Color.parseColor("#22C55E"));
        answerHighlightText.setTextSize(13f);
        answerHighlightText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        answerHighlightText.setPadding(0, 2, 0, 12);
        answerHighlightText.setMaxWidth(620);

        btnAutoLoop = new Button(this);
        btnAutoLoop.setText("Mulai Otomatis 0s (1-by-1)");
        btnAutoLoop.setTextSize(12f);
        btnAutoLoop.setAllCaps(false);
        btnAutoLoop.setBackgroundColor(Color.parseColor("#1E293B"));
        btnAutoLoop.setTextColor(Color.parseColor("#22D3EE"));
        btnAutoLoop.setOnClickListener(v -> toggleAutoLoop());

        btnSingleSolve = new Button(this);
        btnSingleSolve.setText("Kerjakan 1 Soal Sekarang (0s)");
        btnSingleSolve.setTextSize(12.5f);
        btnSingleSolve.setAllCaps(false);
        btnSingleSolve.setBackgroundColor(Color.parseColor("#22C55E"));
        btnSingleSolve.setTextColor(Color.parseColor("#052E16"));
        btnSingleSolve.setOnClickListener(v -> processOneQuestion(false));

        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setPadding(0, 8, 0, 0);

        Button btnMinimize = new Button(this);
        btnMinimize.setText("Kecilkan");
        btnMinimize.setTextSize(11.5f);
        btnMinimize.setAllCaps(false);
        btnMinimize.setBackgroundColor(Color.parseColor("#1E293B"));
        btnMinimize.setTextColor(Color.parseColor("#F8FAFC"));
        btnMinimize.setOnClickListener(v -> {
            isExpanded = false;
            controlPanel.setVisibility(View.GONE);
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            windowManager.updateViewLayout(rootContainer, params);
        });

        Button btnStopAll = new Button(this);
        btnStopAll.setText("Matikan Layanan");
        btnStopAll.setTextSize(11.5f);
        btnStopAll.setAllCaps(false);
        btnStopAll.setBackgroundColor(Color.parseColor("#7F1D1D"));
        btnStopAll.setTextColor(Color.parseColor("#FCA5A5"));
        btnStopAll.setOnClickListener(v -> stopSelf());

        bottomRow.addView(btnMinimize);
        bottomRow.addView(btnStopAll);

        controlPanel.addView(topHeader);
        controlPanel.addView(liveStatusText);
        controlPanel.addView(answerHighlightText);
        controlPanel.addView(btnAutoLoop);
        controlPanel.addView(btnSingleSolve);
        controlPanel.addView(bottomRow);

        rootContainer.addView(floatingBubble);
        rootContainer.addView(controlPanel);

        floatingBubble.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragging = false;
                        floatingBubble.animate().scaleX(0.92f).scaleY(0.92f).setDuration(0).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX);
                        int dy = (int) (event.getRawY() - initialTouchY);
                        if (Math.hypot(dx, dy) > 12.0) {
                            isDragging = true;
                        }
                        if (isDragging) {
                            params.x = initialX + dx;
                            params.y = initialY + dy;
                            windowManager.updateViewLayout(rootContainer, params);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        floatingBubble.animate().scaleX(1f).scaleY(1f).setDuration(0).start();
                        if (!isDragging) {
                            isExpanded = !isExpanded;
                            controlPanel.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
                            params.flags = isExpanded
                                    ? WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                                    : WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                            windowManager.updateViewLayout(rootContainer, params);
                        }
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(rootContainer, params);
        if (MainActivity.activeActivity != null) {
            MainActivity.activeActivity.notifyWebSync();
        }
    }

    private void toggleAutoLoop() {
        autoLoopRunning = !autoLoopRunning;
        mainHandler.removeCallbacks(sequentialLoopRunnable);
        if (autoLoopRunning) {
            lastSolvedQuestionHash = "";
            btnAutoLoop.setText("Hentikan Mode 0s");
            btnAutoLoop.setBackgroundColor(Color.parseColor("#14532D"));
            btnAutoLoop.setTextColor(Color.parseColor("#86EFAC"));
            updateStatus("0s LOOP", "Mode otomatis 0s 1-by-1 aktif...");
            mainHandler.post(sequentialLoopRunnable);
        } else {
            btnAutoLoop.setText("Mulai Otomatis 0s (1-by-1)");
            btnAutoLoop.setBackgroundColor(Color.parseColor("#1E293B"));
            btnAutoLoop.setTextColor(Color.parseColor("#22D3EE"));
            updateStatus("0s READY", "Mode otomatis dihentikan.");
        }
        if (MainActivity.activeActivity != null) {
            MainActivity.activeActivity.notifyWebSync();
        }
    }

    private void updateStatus(String badge, String detail) {
        mainHandler.post(() -> {
            if (statusBadge != null) statusBadge.setText(badge);
            if (liveStatusText != null) liveStatusText.setText(detail);
        });
    }

    private void updateAnswerHighlight(String text) {
        mainHandler.post(() -> {
            if (answerHighlightText != null) answerHighlightText.setText(text);
        });
    }

    private void processOneQuestion(boolean skipIfDuplicate) {
        if (isBusy) return;
        ScreenAutoService acc = ScreenAutoService.instance;
        if (acc == null) {
            updateStatus("IZIN KURANG", "Aktifkan Layanan Aksesibilitas di Pengaturan HP.");
            return;
        }

        isBusy = true;
        updateStatus("0s BACA", "Membaca soal & opsi secara instan...");

        executor.execute(() -> {
            try {
                String screenText = acc.extractScreenText();
                if (screenText == null || screenText.trim().length() < 5) {
                    updateStatus("LAYAR KOSONG", "Tidak ada teks soal terdeteksi di layar.");
                    isBusy = false;
                    return;
                }

                String currentHash = String.valueOf(screenText.trim().hashCode());
                if (skipIfDuplicate && currentHash.equals(lastSolvedQuestionHash)) {
                    isBusy = false;
                    return;
                }

                updateStatus("0s ANALISIS", "AI menganalisis soal semua mata pelajaran...");
                SharedPreferences prefs = getSharedPreferences("annas_ai_prefs", Context.MODE_PRIVATE);
                String apiKey = prefs.getString("ai_api_key", "").trim();

                ScreenAutoService.SolveDecision decision;
                if (!apiKey.isEmpty()) {
                    decision = queryGeminiApi(apiKey, screenText);
                    if (decision == null) {
                        decision = acc.solveLocallyFallback(screenText);
                    }
                } else {
                    decision = acc.solveLocallyFallback(screenText);
                }

                lastSolvedQuestionHash = currentHash;
                boolean clicked = acc.clickOptionOnScreen(decision.optionLetter, decision.optionText);

                if (clicked) {
                    updateStatus("0s KLIK OK", "Opsi " + decision.optionLetter + " diklik instan (0s).");
                    updateAnswerHighlight("Jawaban Terpilih: " + decision.optionLetter + " (" + decision.optionText + ")");
                } else {
                    updateStatus("KLIK MANUAL", "Pilih manual rekomendasi jawaban:");
                    updateAnswerHighlight("Rekomendasi Jawaban: " + decision.optionLetter + " — " + decision.optionText);
                }
            } catch (Exception e) {
                updateStatus("0s SAFE", "Menangani gangguan baca layar tanpa force close.");
            } finally {
                isBusy = false;
            }
        });
    }

    private ScreenAutoService.SolveDecision queryGeminiApi(String apiKey, String screenText) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(8000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);

            String prompt = "Analisis 1 soal pilihan ganda berikut dari layar (bisa dari aplikasi atau web tersemat, semua mata pelajaran). "
                    + "Balas HANYA dalam format JSON valid tanpa markdown: "
                    + "{"option":"A/B/C/D/E","text":"teks opsi terpilih"}. Teks layar:
" + screenText;

            JSONObject part = new JSONObject().put("text", prompt);
            JSONArray parts = new JSONArray().put(part);
            JSONObject content = new JSONObject().put("parts", parts);
            JSONArray contents = new JSONArray().put(content);
            JSONObject body = new JSONObject().put("contents", contents);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            if (conn.getResponseCode() != 200) return null;

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder resp = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                resp.append(line);
            }
            br.close();

            JSONObject jsonResp = new JSONObject(resp.toString());
            String rawText = jsonResp.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim();

            int start = rawText.indexOf('{');
            int end = rawText.lastIndexOf('}');
            if (start >= 0 && end > start) {
                JSONObject parsed = new JSONObject(rawText.substring(start, end + 1));
                String opt = parsed.optString("option", "A").trim().toUpperCase();
                if (opt.length() > 1) opt = opt.substring(0, 1);
                String optTxt = parsed.optString("text", "Opsi " + opt).trim();
                return new ScreenAutoService.SolveDecision(opt, optTxt);
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    private void startForegroundNotif() {
        String channelId = "annas_ai_v15_3_0s_channel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(channelId, "Annas Tools AI 0s Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Notification notif = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("Annas Tools AI 0s Aktif")
                .setContentText("Ikon bulat 0s siap di layar")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build();
        startForeground(153, notif);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        autoLoopRunning = false;
        instance = null;
        mainHandler.removeCallbacks(sequentialLoopRunnable);
        executor.shutdownNow();
        if (rootContainer != null && windowManager != null) {
            try {
                windowManager.removeView(rootContainer);
            } catch (Exception ignored) {
            }
        }
        if (MainActivity.activeActivity != null) {
            MainActivity.activeActivity.notifyWebSync();
        }
    }
}
