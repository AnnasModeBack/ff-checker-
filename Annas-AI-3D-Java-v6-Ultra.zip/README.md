# Annas AI 3D Pro v6 (Java Native Ultra Edition)

Aplikasi asisten tugas otomatis berbasis **Java murni** dengan **3D Floating Bubble**, **Kotak Penanda + Centang (✓) ke Google AI**, **Izin Pemberitahuan**, **Animasi 3D Tingkat Tinggi**, **Tipografi Modern**, dan **100% Vector SVG Full HD**.

## Upgrade Utama di v6
- **Arsitektur Java Murni Ultra-Ringan:** Target ukuran APK di kisaran ~1 MB (dengan stripping ABI/debug & optimasi resource/DEX).
- **Kotak Penanda AI + Centang (✓) + Riwayat Prompt:** Arahkan kotak penanda ke area soal/tugas, ubah ukuran kotak (`260x150`, `310x195`, `345x240`), lalu tekan tombol **Centang (`✓`)** untuk langsung mengirim ke **Google AI (`gemini-flash-latest`)**.
- **Animasi 3D & Tipografi Tingkat Tinggi:** Efek *3D perspective tilt entrance*, *3D orbital floating loop*, *3D tactile pop click*, *pulse ring*, serta *letter-spacing*, *line-height*, dan *fontFamily* yang tajam dan mudah dibaca.
- **Full Vector SVG HD:** Logo 3D bergradasi cyan-violet-emerald dan seluruh ikon tombol memakai `<vector>` SVG agar tetap tajam di layar resolusi tinggi.
- **Workflow GitHub Actions Modern (`v5`):** Menggunakan `actions/checkout@v5`, `actions/setup-java@v5`, dan `gradle/actions/setup-gradle@v5` dengan `cache-disabled: true` (sesuai panduan *disabling caching* & *cache cleanup disabled when cache is disabled* pada `setup-gradle`).
