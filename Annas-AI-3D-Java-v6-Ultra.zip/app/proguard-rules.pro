-dontwarn android.support.**
-dontwarn androidx.**
-keep class com.annas.aifloating.MainActivity { *; }
-keep class com.annas.aifloating.FloatingAIService { *; }
-keepclassmembers class com.annas.aifloating.** {
    public <init>(...);
}
