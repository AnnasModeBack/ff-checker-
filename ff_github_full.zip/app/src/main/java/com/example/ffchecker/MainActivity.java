package com.example.ffchecker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#090B10"));
        web.setFitsSystemWindows(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        // Nama "FlutterHttp" dipertahankan agar index.html yang sama bisa dipakai tanpa diubah.
        web.addJavascriptInterface(new Bridge(), "FlutterHttp");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Jembatan HTTP native: melewati batasan CORS pada halaman file://. */
    private class Bridge {
        @JavascriptInterface
        public void postMessage(final String message) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    String id = "null";
                    try {
                        JSONObject req = new JSONObject(message);
                        id = String.valueOf(req.get("id"));
                        HttpURLConnection c = (HttpURLConnection) new URL(req.getString("url")).openConnection();
                        c.setConnectTimeout(12000);
                        c.setReadTimeout(15000);
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) FFChecker");
                        JSONObject h = req.optJSONObject("headers");
                        if (h != null) {
                            Iterator<String> it = h.keys();
                            while (it.hasNext()) {
                                String k = it.next();
                                c.setRequestProperty(k, h.getString(k));
                            }
                        }
                        int code = c.getResponseCode();
                        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        StringBuilder sb = new StringBuilder();
                        if (is != null) {
                            BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line).append('\n');
                            r.close();
                        }
                        reply(id, code, sb.toString());
                    } catch (Exception e) {
                        reply(id, 0, String.valueOf(e.getMessage()));
                    }
                }
            });
        }
    }

    private void reply(String id, int code, String body) {
        final String js = "window.__ffResolve(" + id + "," + code + ","
                + JSONObject.quote(body).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029") + ");";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
