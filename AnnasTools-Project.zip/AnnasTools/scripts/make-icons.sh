#!/usr/bin/env bash
# Salin assets/icon.jpg menjadi ikon launcher semua densitas. Jika tidak ada, buat ikon default.
set -e
SRC=assets/icon.jpg; R=app/src/main/res
mkdir -p assets
[ -f "$SRC" ] || convert -size 512x512 gradient:'#3B5BDB-#18212F' -gravity center -fill white -pointsize 260 -annotate 0 'A' "$SRC"
for d in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
  n=${d%%:*}; s=${d##*:}; mkdir -p $R/mipmap-$n
  convert "$SRC" -resize ${s}x${s}^ -gravity center -extent ${s}x${s} $R/mipmap-$n/ic_launcher.png
done
