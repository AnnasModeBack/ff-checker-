package com.annas.tools;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#EFF2F7"));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(UA);
        web.setBackgroundColor(Color.parseColor("#EFF2F7"));
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v; customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            }
            @Override public void onHideCustomView() { exitFullscreen(); }
        });
        web.setDownloadListener((url, ua, cd, mime, len) ->
            enqueue(url, URLUtil.guessFileName(url, cd, mime)));
        web.loadUrl("file:///android_asset/index.html");
    }

    private void exitFullscreen() {
        if (customView == null) return;
        root.removeView(customView); customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        web.setVisibility(View.VISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void enqueue(String url, String name) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.addRequestHeader("User-Agent", UA);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            Toast.makeText(this, "Mengunduh: " + name, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengunduh", Toast.LENGTH_SHORT).show();
        }
    }

    class Bridge {
        @JavascriptInterface public void download(String url, String name) {
            runOnUiThread(() -> enqueue(url, name));
        }
        // Request jaringan native: lolos dari batasan CORS WebView.
        @JavascriptInterface public void nativeFetch(final int id, final String url) {
            new Thread(() -> {
                int code = -1; byte[] body = new byte[0];
                try {
                    if (!url.startsWith("http")) throw new Exception("bad url");
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(20000); c.setReadTimeout(25000);
                    c.setRequestProperty("User-Agent", UA);
                    c.setRequestProperty("Accept", "application/json,*/*");
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        ByteArrayOutputStream o = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                        body = o.toByteArray();
                    }
                } catch (Exception e) { code = -1; }
                final String b64 = Base64.encodeToString(body, Base64.NO_WRAP);
                final int st = code;
                runOnUiThread(() -> web.evaluateJavascript(
                    "window.__nf(" + id + ",'" + b64 + "'," + st + ")", null));
            }).start();
        }
    }

    @Override public void onBackPressed() {
        if (customView != null) { exitFullscreen(); return; }
        web.evaluateJavascript("window.annasBack?window.annasBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { ((ViewGroup) web.getParent()).removeView(web); web.destroy(); super.onDestroy(); }
}
