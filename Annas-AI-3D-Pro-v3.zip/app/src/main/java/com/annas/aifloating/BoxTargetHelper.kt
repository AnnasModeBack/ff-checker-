package com.annas.aifloating

import android.content.ClipboardManager
import android.content.Context

object BoxTargetHelper {

    fun resolveTargetContent(context: Context, boxX: Int, boxY: Int, boxW: Int, boxH: Int): String {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clipText = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.trim()
        return if (!clipText.isNullOrBlank()) {
            "Area Kotak Ditandai [x=$boxX, y=$boxY, ukuran=${boxW}x${boxH}px]:\n$clipText"
        } else {
            "Area layar yang ditandai kotak AI berada di koordinat X=$boxX, Y=$boxY dengan ukuran ${boxW}x${boxH} piksel. Tolong bantu jawab atau jelaskan tugas/soal yang ada di area tersebut secara akurat."
        }
    }
}
