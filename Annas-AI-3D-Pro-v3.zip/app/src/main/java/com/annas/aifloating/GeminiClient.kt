package com.annas.aifloating

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    suspend fun solveTask(apiKey: String, mode: String, question: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext "Error: API Key Google Gemini belum diisi. Buka aplikasi Annas AI 3D Pro untuk menyimpan API Key."
        }
        try {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$apiKey"
            val url = URL(endpoint)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                doOutput = true
                connectTimeout = 20000
                readTimeout = 30000
            }

            val instruction = when {
                mode.contains("Pilihan Ganda") ->
                    "Kamu adalah asisten pengerja soal pilihan ganda. Sebutkan huruf jawaban paling tepat di baris pertama (contoh: Jawaban: B), lalu berikan alasan singkat dan jelas dalam Bahasa Indonesia."
                mode.contains("Matematika") ->
                    "Kamu adalah tutor matematika. Selesaikan langkah demi langkah secara runtut dan tampilkan jawaban akhir yang jelas dalam Bahasa Indonesia."
                mode.contains("Coding") ->
                    "Kamu adalah asisten pemrograman. Berikan solusi kode yang rapi, bebas error, dan penjelasan ringkas."
                else ->
                    "Kamu adalah asisten pengerja tugas pintar. Analisis konten yang ditandai atau soal berikut, lalu berikan jawaban yang tepat, terstruktur, dan jelas dalam Bahasa Indonesia."
            }

            val fullPrompt = "$instruction\n\nInput:\n$question"

            val partObj = JSONObject().put("text", fullPrompt)
            val partsArr = JSONArray().put(partObj)
            val contentObj = JSONObject().put("parts", partsArr)
            val contentsArr = JSONArray().put(contentObj)
            val payload = JSONObject().put("contents", contentsArr)

            OutputStreamWriter(conn.outputStream, "UTF-8").use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val rawResponse = stream.bufferedReader().use { it.readText() }

            if (code !in 200..299) {
                return@withContext "Gagal terhubung ke Google AI ($code): $rawResponse"
            }

            val json = JSONObject(rawResponse)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return@withContext parts.getJSONObject(0).optString("text", "Tidak ada respons teks.")
                }
            }
            "Respons Google AI kosong."
        } catch (e: Exception) {
            "Terjadi kesalahan: ${e.message}"
        }
    }
}
