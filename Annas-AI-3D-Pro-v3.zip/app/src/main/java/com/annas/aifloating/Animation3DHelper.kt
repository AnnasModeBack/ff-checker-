package com.annas.aifloating

import android.view.View
import android.view.animation.OvershootInterpolator

object Animation3DHelper {

    fun apply3DTiltEntrance(view: View, delayMs: Long = 0L) {
        view.alpha = 0f
        view.scaleX = 0.78f
        view.scaleY = 0.78f
        view.rotationX = 16f
        view.rotationY = -12f
        view.cameraDistance = 14000f * view.resources.displayMetrics.density

        view.animate()
            .setStartDelay(delayMs)
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .rotationX(0f)
            .rotationY(0f)
            .setDuration(420L)
            .setInterpolator(OvershootInterpolator(1.25f))
            .start()
    }

    fun pop3DClick(view: View) {
        view.animate()
            .scaleX(0.9f)
            .scaleY(0.9f)
            .rotationY(10f)
            .setDuration(90L)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .rotationY(0f)
                    .setDuration(140L)
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }
            .start()
    }
}
