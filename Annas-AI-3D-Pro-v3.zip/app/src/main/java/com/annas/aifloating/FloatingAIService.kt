package com.annas.aifloating

import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlinx.coroutines.*

class FloatingAIService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private var boxSelectorView: View? = null
    private var boxParams: WindowManager.LayoutParams? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isMcqMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(
            NotificationHelper.SERVICE_NOTIF_ID,
            NotificationHelper.buildServiceNotification(this)
        )

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.overlay_floating, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 36
            y = 220
        }

        windowManager.addView(floatingView, params)
        Animation3DHelper.apply3DTiltEntrance(floatingView)

        val bubbleContainer = floatingView.findViewById<LinearLayout>(R.id.bubbleContainer)
        val panelContainer = floatingView.findViewById<LinearLayout>(R.id.panelContainer)
        val btnMinimize = floatingView.findViewById<Button>(R.id.btnMinimize)
        val btnToggleBoxSelector = floatingView.findViewById<Button>(R.id.btnToggleBoxSelector)
        val btnPaste = floatingView.findViewById<Button>(R.id.btnPasteClipboard)
        val btnModeMcq = floatingView.findViewById<Button>(R.id.btnModeMCQ)
        val etPrompt = floatingView.findViewById<EditText>(R.id.etPrompt)
        val btnSolve = floatingView.findViewById<Button>(R.id.btnSolve)
        val tvResult = floatingView.findViewById<TextView>(R.id.tvResult)
        val btnCopy = floatingView.findViewById<Button>(R.id.btnCopyResult)

        bubbleContainer.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = kotlin.math.abs(event.rawX - touchX)
                        val dy = kotlin.math.abs(event.rawY - touchY)
                        if (dx < 12 && dy < 12) {
                            Animation3DHelper.pop3DClick(bubbleContainer)
                            bubbleContainer.visibility = View.GONE
                            panelContainer.visibility = View.VISIBLE
                            Animation3DHelper.apply3DTiltEntrance(panelContainer)
                        }
                        return true
                    }
                }
                return false
            }
        })

        btnMinimize.setOnClickListener {
            Animation3DHelper.pop3DClick(btnMinimize)
            panelContainer.visibility = View.GONE
            bubbleContainer.visibility = View.VISIBLE
            Animation3DHelper.apply3DTiltEntrance(bubbleContainer)
        }

        btnToggleBoxSelector.setOnClickListener {
            Animation3DHelper.pop3DClick(btnToggleBoxSelector)
            showBoxSelector(overlayType, etPrompt, tvResult)
        }

        btnPaste.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clipText = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!clipText.isNullOrBlank()) {
                etPrompt.setText(clipText)
                Toast.makeText(this, "Soal ditempel dari clipboard", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Clipboard masih kosong", Toast.LENGTH_SHORT).show()
            }
        }

        btnModeMcq.setOnClickListener {
            isMcqMode = !isMcqMode
            btnModeMcq.text = if (isMcqMode) "Mode PG: ON" else "Mode PG"
            Toast.makeText(
                this,
                if (isMcqMode) "Mode Pilihan Ganda Aktif" else "Mode Tugas Lengkap Aktif",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnSolve.setOnClickListener {
            val promptText = etPrompt.text.toString().trim()
            if (promptText.isEmpty()) {
                Toast.makeText(this, "Masukkan soal atau gunakan Kotak Centang AI dulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            sendPromptToGoogleAI(promptText, etPrompt, tvResult, btnSolve)
        }

        btnCopy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Jawaban Google AI", tvResult.text.toString())
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "Jawaban disalin!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBoxSelector(overlayType: Int, etPrompt: EditText, tvResult: TextView) {
        removeBoxSelector()

        val boxView = LayoutInflater.from(this).inflate(R.layout.overlay_box_selector, null)
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 90
            y = 320
        }

        boxSelectorView = boxView
        boxParams = layoutParams
        windowManager.addView(boxView, layoutParams)
        Animation3DHelper.apply3DTiltEntrance(boxView)

        val boxFrame = boxView.findViewById<LinearLayout>(R.id.boxFrame)
        val dragHandle = boxView.findViewById<TextView>(R.id.tvBoxDragHandle)
        val btnConfirmCheck = boxView.findViewById<Button>(R.id.btnConfirmCheckAI)
        val btnClose = boxView.findViewById<Button>(R.id.btnCloseBox)
        val btnResize = boxView.findViewById<Button>(R.id.btnResizeBox)

        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            private var initX = 0
            private var initY = 0
            private var downX = 0f
            private var downY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = layoutParams.x
                        initY = layoutParams.y
                        downX = event.rawX
                        downY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initX + (event.rawX - downX).toInt()
                        layoutParams.y = initY + (event.rawY - downY).toInt()
                        windowManager.updateViewLayout(boxView, layoutParams)
                        return true
                    }
                }
                return false
            }
        })

        var sizeStep = 0
        btnResize.setOnClickListener {
            sizeStep = (sizeStep + 1) % 3
            val (wDp, hDp) = when (sizeStep) {
                1 -> Pair(310, 185)
                2 -> Pair(340, 230)
                else -> Pair(250, 140)
            }
            val density = resources.displayMetrics.density
            val lp = boxFrame.layoutParams
            lp.width = (wDp * density).toInt()
            lp.height = (hDp * density).toInt()
            boxFrame.layoutParams = lp
            Animation3DHelper.pop3DClick(btnResize)
        }

        btnConfirmCheck.setOnClickListener {
            Animation3DHelper.pop3DClick(btnConfirmCheck)
            val currentW = boxFrame.width
            val currentH = boxFrame.height
            val targetPrompt = BoxTargetHelper.resolveTargetContent(
                this,
                layoutParams.x,
                layoutParams.y,
                currentW,
                currentH
            )
            etPrompt.setText(targetPrompt)
            removeBoxSelector()

            val panelContainer = floatingView.findViewById<LinearLayout>(R.id.panelContainer)
            val bubbleContainer = floatingView.findViewById<LinearLayout>(R.id.bubbleContainer)
            val btnSolve = floatingView.findViewById<Button>(R.id.btnSolve)
            bubbleContainer.visibility = View.GONE
            panelContainer.visibility = View.VISIBLE
            Animation3DHelper.apply3DTiltEntrance(panelContainer)

            sendPromptToGoogleAI(targetPrompt, etPrompt, tvResult, btnSolve)
        }

        btnClose.setOnClickListener {
            removeBoxSelector()
        }
    }

    private fun sendPromptToGoogleAI(
        promptText: String,
        etPrompt: EditText,
        tvResult: TextView,
        btnSolve: Button
    ) {
        val prefs = getSharedPreferences("annas_ai_3d_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        val savedMode = prefs.getString("mode_name", "Auto Tugas & Jawaban Lengkap") ?: "Auto Tugas"
        val activeMode = if (isMcqMode) "Pilihan Ganda Cepat" else savedMode

        tvResult.text = "Mengirim ke Google AI & memproses jawaban..."
        btnSolve.isEnabled = false

        serviceScope.launch {
            val answer = GeminiClient.solveTask(apiKey, activeMode, promptText)
            tvResult.text = answer
            btnSolve.isEnabled = true
            NotificationHelper.showAnswerNotification(
                this@FloatingAIService,
                "Jawaban Google AI Siap",
                answer
            )
        }
    }

    private fun removeBoxSelector() {
        boxSelectorView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        boxSelectorView = null
        boxParams = null
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        removeBoxSelector()
        if (::floatingView.isInitialized) {
            try {
                windowManager.removeView(floatingView)
            } catch (_: Exception) {
            }
        }
    }
}
