@rem Gradle startup script for Windows
@echo off
if exist "%USERPROFILE%\.gradle\wrapper\dists" (
  for /r "%USERPROFILE%\.gradle\wrapper\dists" %%i in (gradle.bat) do (
    "%%i" %*
    exit /b %ERRORLEVEL%
  )
)
gradle %*
