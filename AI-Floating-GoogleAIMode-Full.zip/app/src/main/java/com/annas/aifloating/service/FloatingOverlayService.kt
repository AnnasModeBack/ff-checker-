package com.annas.aifloating.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.R
import com.annas.aifloating.capture.ScreenCaptureManager
import com.annas.aifloating.ocr.OcrTextExtractor
import com.annas.aifloating.state.OverlayState
import com.annas.aifloating.ui.ScreenCapturePermissionActivity
import com.annas.aifloating.ui.SelectionBoxOverlayView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import kotlin.math.abs

/**
 * Service utama pengelola siklus hidup & transisi state Floating Overlay:
 * IDLE -> FLOATING_BAR_OPEN -> SELECTING_BOX -> EXTRACTING -> GOOGLE_AI_MODE
 */
class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloating.ACTION_START"
        const val ACTION_STOP = "com.annas.aifloating.ACTION_STOP"
        const val ACTION_SET_PROJECTION = "com.annas.aifloating.ACTION_SET_PROJECTION"
        const val ACTION_OPEN_CROP_FALLBACK = "com.annas.aifloating.ACTION_OPEN_CROP_FALLBACK"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_AUTO_OPEN_CROP = "extra_auto_open_crop"

        private const val NOTIF_ID = 3030
        // Google AI Mode / AI Search URL
        private const val GOOGLE_AI_MODE_HOME = "https://www.google.com/search?udm=50"
        private const val GOOGLE_WEB_HOME = "https://www.google.com"

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        var currentState: OverlayState = OverlayState.IDLE
    }

    private lateinit var windowManager: WindowManager
    private lateinit var captureManager: ScreenCaptureManager
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var extractionJob: Job? = null

    private var bubbleView: View? = null
    private var verticalBarView: View? = null
    private var cropOverlayView: View? = null
    private var aiWindowView: View? = null
    private var aiWebView: WebView? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var barParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        captureManager = ScreenCaptureManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                cleanupAllViews()
                captureManager.release()
                isRunning = false
                currentState = OverlayState.IDLE
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SET_PROJECTION -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)
                val autoCrop = intent.getBooleanExtra(EXTRA_AUTO_OPEN_CROP, false)
                if (code == Activity.RESULT_OK && data != null) {
                    captureManager.initProjection(code, data)
                }
                if (autoCrop && Settings.canDrawOverlays(this)) {
                    transitionTo(OverlayState.SELECTING_BOX)
                }
                return START_STICKY
            }
            ACTION_OPEN_CROP_FALLBACK -> {
                if (Settings.canDrawOverlays(this)) {
                    transitionTo(OverlayState.SELECTING_BOX)
                }
                return START_STICKY
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning = false
            currentState = OverlayState.IDLE
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        startForeground(NOTIF_ID, buildNotification())
        if (currentState == OverlayState.IDLE) {
            transitionTo(OverlayState.IDLE)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        extractionJob?.cancel()
        serviceScope.cancel()
        cleanupAllViews()
        captureManager.release()
        isRunning = false
        currentState = OverlayState.IDLE
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun getScreenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    /**
     * Pusat transisi state mesin agar hanya lapisan UI yang relevan tampil dan bebas kebocoran view.
     */
    private fun transitionTo(newState: OverlayState, initialUrl: String? = null, initialQuery: String? = null) {
        currentState = newState
        when (newState) {
            OverlayState.IDLE -> {
                hideVerticalBar()
                hideCropOverlay()
                hideAiWindow()
                showFloatingBubble()
            }
            OverlayState.FLOATING_BAR_OPEN -> {
                hideFloatingBubble()
                hideCropOverlay()
                hideAiWindow()
                showVerticalFloatingBar()
            }
            OverlayState.SELECTING_BOX -> {
                hideFloatingBubble()
                hideVerticalBar()
                hideAiWindow()
                showCropSelectorOverlay()
            }
            OverlayState.EXTRACTING -> {
                // Sembunyikan overlay crop sebelum screenshot agar hasil crop layar bersih
                hideCropOverlay()
                showGoogleAiWindow(
                    title = "Google AI Mode",
                    url = null,
                    queryText = "",
                    processingStatus = "Mengambil & mengekstrak area kotak seleksi..."
                )
            }
            OverlayState.GOOGLE_AI_MODE -> {
                hideFloatingBubble()
                hideVerticalBar()
                hideCropOverlay()
                showGoogleAiWindow(
                    title = "Google AI Mode",
                    url = initialUrl ?: GOOGLE_AI_MODE_HOME,
                    queryText = initialQuery.orEmpty(),
                    processingStatus = null
                )
            }
        }
    }

    // =========================================================================
    // 1. FLOATING BUBBLE (IDLE) — Draggable + Auto-Snap ke Tepi Layar
    // =========================================================================
    private fun showFloatingBubble() {
        if (bubbleView != null) {
            bubbleView?.visibility = View.VISIBLE
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_floating_bubble, null)
        val (screenW, _) = getScreenSize()
        val bubblePx = (60 * resources.displayMetrics.density).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - bubblePx - 16
            y = 320
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                    }
                    params.x = (startX + dx).coerceIn(0, (screenW - bubblePx).coerceAtLeast(0))
                    params.y = (startY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Bubble dipencet -> buka Floating Bar Vertikal
                        transitionTo(OverlayState.FLOATING_BAR_OPEN)
                    } else {
                        // Otomatis menempel rapi ke tepi layar kiri/kanan terdekat
                        snapBubbleToNearestEdge(view, params, screenW, bubblePx)
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    private fun snapBubbleToNearestEdge(
        view: View,
        params: WindowManager.LayoutParams,
        screenW: Int,
        bubblePx: Int
    ) {
        val targetX = if (params.x + bubblePx / 2 < screenW / 2) {
            16
        } else {
            (screenW - bubblePx - 16).coerceAtLeast(16)
        }
        ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                try {
                    windowManager.updateViewLayout(view, params)
                } catch (_: Exception) {
                }
            }
            start()
        }
    }

    private fun hideFloatingBubble() {
        bubbleView?.visibility = View.GONE
    }

    // =========================================================================
    // 2. FLOATING BAR VERTIKAL (Tombol 1, Tombol 2 (+), Tombol 3, Tombol 4)
    // =========================================================================
    private fun showVerticalFloatingBar() {
        val (screenW, screenH) = getScreenSize()
        val barW = (64 * resources.displayMetrics.density).toInt()
        val barH = (260 * resources.displayMetrics.density).toInt()

        val bx = (bubbleParams?.x ?: (screenW - barW - 16)).coerceIn(12, (screenW - barW - 12).coerceAtLeast(12))
        val by = (bubbleParams?.y ?: 280).coerceIn(40, (screenH - barH - 40).coerceAtLeast(40))

        if (verticalBarView != null) {
            barParams?.x = bx
            barParams?.y = by
            verticalBarView?.visibility = View.VISIBLE
            try {
                windowManager.updateViewLayout(verticalBarView, barParams)
            } catch (_: Exception) {
            }
            return
        }

        val vBar = LayoutInflater.from(this).inflate(R.layout.overlay_vertical_bar, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bx
            y = by
        }

        // Tombol 1: Cari & Google AI Mode
        vBar.findViewById<LinearLayout>(R.id.btnBar1SearchAi).setOnClickListener {
            transitionTo(
                OverlayState.GOOGLE_AI_MODE,
                initialUrl = GOOGLE_AI_MODE_HOME,
                initialQuery = ""
            )
        }

        // Tombol 2 (+): Mode Kotak Seleksi Area
        vBar.findViewById<LinearLayout>(R.id.btnBar2SelectArea).setOnClickListener {
            if (!captureManager.hasProjection() && ScreenTextAccessibilityService.instance == null) {
                // Minta izin tangkap layar sekali agar crop area selalu berhasil
                val permIntent = Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra(EXTRA_AUTO_OPEN_CROP, true)
                }
                startActivity(permIntent)
            } else {
                transitionTo(OverlayState.SELECTING_BOX)
            }
        }

        // Tombol 3: Web & Browser Floating
        vBar.findViewById<LinearLayout>(R.id.btnBar3WebBrowser).setOnClickListener {
            transitionTo(
                OverlayState.GOOGLE_AI_MODE,
                initialUrl = GOOGLE_WEB_HOME,
                initialQuery = GOOGLE_WEB_HOME
            )
            aiWindowView?.findViewById<TextView>(R.id.tvWindowTitle)?.text = "Web & Browser Floating"
        }

        // Tombol 4 (Bawah): Tutup & Lipat kembali ke Floating Bubble
        vBar.findViewById<LinearLayout>(R.id.btnBar4Collapse).setOnClickListener {
            transitionTo(OverlayState.IDLE)
        }

        barParams = params
        verticalBarView = vBar
        windowManager.addView(vBar, params)
    }

    private fun hideVerticalBar() {
        verticalBarView?.visibility = View.GONE
    }

    // =========================================================================
    // 3. MODE KOTAK SELEKSI (+) & TOMBOL AKSI X / ✓
    // =========================================================================
    private fun showCropSelectorOverlay() {
        if (cropOverlayView == null) {
            val cView = LayoutInflater.from(this).inflate(R.layout.overlay_crop_selector, null)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
            }

            val selectionView = cView.findViewById<SelectionBoxOverlayView>(R.id.selectionBoxView)
            val actionBar = cView.findViewById<LinearLayout>(R.id.cropActionBar)
            val btnCancelX = cView.findViewById<LinearLayout>(R.id.btnCropCancelX)
            val btnConfirmCheck = cView.findViewById<LinearLayout>(R.id.btnCropConfirmCheck)

            // Posisikan bar aksi X / ✓ tepat di bawah kotak seleksi secara real-time
            selectionView.onSelectionChanged = { rect ->
                positionCropActionBar(actionBar, rect, selectionView.width, selectionView.height)
            }

            // Tombol Batal (X): batalkan seleksi & kembali tanpa memproses area
            btnCancelX.setOnClickListener {
                transitionTo(OverlayState.FLOATING_BAR_OPEN)
            }

            // Tombol Centang (✓): kunci area di dalam kotak seleksi & mulai ekstraksi -> Google AI Mode
            btnConfirmCheck.setOnClickListener {
                val selectedRect = selectionView.getSelectionRect()
                startCropExtractionAndOpenGoogleAi(selectedRect)
            }

            cropOverlayView = cView
            windowManager.addView(cView, params)
        } else {
            cropOverlayView?.visibility = View.VISIBLE
            val selectionView = cropOverlayView?.findViewById<SelectionBoxOverlayView>(R.id.selectionBoxView)
            val actionBar = cropOverlayView?.findViewById<LinearLayout>(R.id.cropActionBar)
            if (selectionView != null && actionBar != null) {
                positionCropActionBar(
                    actionBar,
                    selectionView.getSelectionRect(),
                    selectionView.width,
                    selectionView.height
                )
            }
        }
    }

    private fun positionCropActionBar(
        actionBar: View,
        rect: RectF,
        containerW: Int,
        containerH: Int
    ) {
        val barW = if (actionBar.width > 0) actionBar.width else (165 * resources.displayMetrics.density).toInt()
        val barH = if (actionBar.height > 0) actionBar.height else (52 * resources.displayMetrics.density).toInt()
        val margin = (12 * resources.displayMetrics.density)

        val targetX = (rect.centerX() - barW / 2f).coerceIn(16f, (containerW - barW - 16f).coerceAtLeast(16f))
        val belowY = rect.bottom + margin
        val targetY = if (belowY + barH + 24f <= containerH) {
            belowY
        } else {
            (rect.top - barH - margin).coerceAtLeast(48f)
        }

        actionBar.x = targetX
        actionBar.y = targetY
    }

    private fun hideCropOverlay() {
        cropOverlayView?.visibility = View.GONE
    }

    // =========================================================================
    // 4. EKSTRAKSI CEPAT (EXTRACTING) -> LANGSUNG GOOGLE AI MODE
    // =========================================================================
    private fun startCropExtractionAndOpenGoogleAi(selectionRect: RectF) {
        extractionJob?.cancel()
        transitionTo(OverlayState.EXTRACTING)

        extractionJob = serviceScope.launch {
            // Beri jeda 90ms agar layer crop hilang sepenuhnya sebelum layar di-capture bersih
            delay(90L)

            var extractedText = ""

            // Jalur 1 (Utama): Capture gambar layar via MediaProjection -> Crop tepat di dalam kotak -> ML Kit OCR
            val croppedBitmap = withContext(Dispatchers.Default) {
                captureManager.captureCroppedArea(selectionRect)
            }
            if (croppedBitmap != null) {
                extractedText = withContext(Dispatchers.Default) {
                    OcrTextExtractor.extractText(croppedBitmap)
                }
                croppedBitmap.recycle()
            }

            // Jalur 2 (Fallback Cepat): Jika bitmap kosong / hasil OCR tipis, ambil teks node Accessibility di dalam Rect
            if (extractedText.length < 3) {
                val a11yText = ScreenTextAccessibilityService.instance?.extractTextInRect(selectionRect).orEmpty()
                if (a11yText.isNotEmpty()) {
                    extractedText = a11yText
                }
            }

            // Buka langsung Google AI Mode dengan query hasil seleksi area
            if (extractedText.isNotBlank()) {
                val encoded = URLEncoder.encode(extractedText, "UTF-8")
                // udm=50 mengarahkan langsung ke Google AI Mode / AI Overview Search
                val aiModeUrl = "https://www.google.com/search?udm=50&q=$encoded"
                currentState = OverlayState.GOOGLE_AI_MODE
                showGoogleAiWindow(
                    title = "Google AI Mode",
                    url = aiModeUrl,
                    queryText = extractedText,
                    processingStatus = null
                )
            } else {
                // Fallback aman jika hasil crop buram / gambar tanpa teks
                currentState = OverlayState.GOOGLE_AI_MODE
                showGoogleAiWindow(
                    title = "Google AI Mode",
                    url = GOOGLE_AI_MODE_HOME,
                    queryText = "",
                    processingStatus = "Teks tidak terbaca jelas — ketik pertanyaan di kotak atas atau tekan '+ Seleksi'."
                )
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showGoogleAiWindow(
        title: String,
        url: String?,
        queryText: String,
        processingStatus: String?
    ) {
        if (aiWindowView == null) {
            val wView = LayoutInflater.from(this).inflate(R.layout.overlay_google_ai_window, null)
            val (screenW, screenH) = getScreenSize()
            val winW = (screenW * 0.95f).toInt()
            val winH = (screenH * 0.86f).toInt()

            val params = WindowManager.LayoutParams(
                winW,
                winH,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }

            val etQuery = wView.findViewById<EditText>(R.id.etAiQuery)
            val btnSend = wView.findViewById<TextView>(R.id.btnAiSendQuery)
            val btnQuickReselect = wView.findViewById<TextView>(R.id.btnQuickReselect)
            val btnBack = wView.findViewById<ImageButton>(R.id.btnAiBack)
            val btnRefresh = wView.findViewById<ImageButton>(R.id.btnAiRefresh)
            val btnMinimize = wView.findViewById<ImageButton>(R.id.btnAiMinimize)
            val webProgress = wView.findViewById<ProgressBar>(R.id.aiWebProgress)
            val wv = wView.findViewById<WebView>(R.id.aiWebView)

            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = true
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                userAgentString =
                    "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
            }

            wv.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    if (newProgress in 1..99) {
                        webProgress.visibility = View.VISIBLE
                        webProgress.progress = newProgress
                    } else {
                        webProgress.visibility = View.GONE
                    }
                }
            }

            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val target = request?.url?.toString() ?: return false
                    if (target.startsWith("http://") || target.startsWith("https://")) {
                        view?.loadUrl(target)
                    }
                    return true
                }
            }

            fun submitQuery() {
                val raw = etQuery.text.toString().trim()
                if (raw.isEmpty()) {
                    wv.loadUrl(GOOGLE_AI_MODE_HOME)
                    return
                }
                val destination = when {
                    raw.startsWith("http://") || raw.startsWith("https://") -> raw
                    raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                    else -> "https://www.google.com/search?udm=50&q=" + URLEncoder.encode(raw, "UTF-8")
                }
                wView.findViewById<LinearLayout>(R.id.statusBanner).visibility = View.GONE
                wv.loadUrl(destination)
            }

            btnSend.setOnClickListener { submitQuery() }
            etQuery.setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    submitQuery()
                    true
                } else {
                    false
                }
            }

            btnQuickReselect.setOnClickListener {
                transitionTo(OverlayState.SELECTING_BOX)
            }

            btnBack.setOnClickListener {
                if (wv.canGoBack()) wv.goBack()
            }

            btnRefresh.setOnClickListener {
                wv.reload()
            }

            btnMinimize.setOnClickListener {
                transitionTo(OverlayState.IDLE)
            }

            aiWebView = wv
            aiWindowView = wView
            windowManager.addView(wView, params)
        } else {
            aiWindowView?.visibility = View.VISIBLE
        }

        val wView = aiWindowView ?: return
        wView.findViewById<TextView>(R.id.tvWindowTitle).text = title
        val etQuery = wView.findViewById<EditText>(R.id.etAiQuery)
        if (queryText.isNotEmpty()) {
            etQuery.setText(queryText)
        }

        val statusBanner = wView.findViewById<LinearLayout>(R.id.statusBanner)
        val statusSpinner = wView.findViewById<ProgressBar>(R.id.statusSpinner)
        val tvStatusMsg = wView.findViewById<TextView>(R.id.tvStatusMessage)

        if (!processingStatus.isNullOrBlank()) {
            statusBanner.visibility = View.VISIBLE
            statusSpinner.visibility = if (currentState == OverlayState.EXTRACTING) View.VISIBLE else View.GONE
            tvStatusMsg.text = processingStatus
        } else {
            statusBanner.visibility = View.GONE
        }

        if (!url.isNullOrBlank()) {
            aiWebView?.loadUrl(url)
        }
    }

    private fun hideAiWindow() {
        aiWindowView?.visibility = View.GONE
    }

    private fun cleanupAllViews() {
        aiWebView?.destroy()
        aiWebView = null

        listOf(aiWindowView, cropOverlayView, verticalBarView, bubbleView).forEach { view ->
            view?.let {
                try {
                    windowManager.removeView(it)
                } catch (_: Exception) {
                }
            }
        }
        aiWindowView = null
        cropOverlayView = null
        verticalBarView = null
        bubbleView = null
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val offIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingOff = PendingIntent.getService(
            this, 1, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle("AI Floating Aktif")
            .setContentText("Ketuk bubble untuk membuka Floating Bar (1 • 2 • 3).")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, "OFF (Matikan)", pendingOff)
            .build()
    }
}
