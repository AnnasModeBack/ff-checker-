package com.annas.aifloating.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.annas.aifloating.service.FloatingOverlayService

/**
 * Activity transparan untuk meminta izin MediaProjection (Tangkap Layar)
 * lalu mengirimkan token izin ke FloatingOverlayService tanpa mengganggu layar pengguna.
 */
class ScreenCapturePermissionActivity : AppCompatActivity() {

    private var openCropAfterGrant = false

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingOverlayService::class.java).apply {
                    action = FloatingOverlayService.ACTION_SET_PROJECTION
                    putExtra(FloatingOverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingOverlayService.EXTRA_RESULT_DATA, result.data)
                    putExtra(FloatingOverlayService.EXTRA_AUTO_OPEN_CROP, openCropAfterGrant)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
            } else if (openCropAfterGrant) {
                // Jika user menolak MediaProjection, tetap izinkan seleksi dengan fallback Accessibility / Input Manual
                val fallbackIntent = Intent(this, FloatingOverlayService::class.java).apply {
                    action = FloatingOverlayService.ACTION_OPEN_CROP_FALLBACK
                }
                ContextCompat.startForegroundService(this, fallbackIntent)
            }
            finish()
            overridePendingTransition(0, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openCropAfterGrant = intent.getBooleanExtra(FloatingOverlayService.EXTRA_AUTO_OPEN_CROP, false)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }
}
