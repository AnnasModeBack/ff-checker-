package com.annas.aifloating

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.annas.aifloating.service.FloatingOverlayService
import com.annas.aifloating.service.ScreenTextAccessibilityService
import com.annas.aifloating.ui.ScreenCapturePermissionActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvCaptureStatus: TextView
    private lateinit var tvNotifStatus: TextView
    private lateinit var tvA11yStatus: TextView
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerSub: TextView
    private lateinit var switchFloating: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvCaptureStatus = findViewById(R.id.tvCaptureStatus)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        tvA11yStatus = findViewById(R.id.tvA11yStatus)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerSub = findViewById(R.id.tvPowerSub)
        switchFloating = findViewById(R.id.switchFloating)

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            requestOverlayPermission()
        }

        findViewById<Button>(R.id.btnGrantCapture).setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            startActivity(Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                putExtra(FloatingOverlayService.EXTRA_AUTO_OPEN_CROP, false)
            })
        }

        findViewById<Button>(R.id.btnGrantNotif).setOnClickListener {
            requestNotificationPermission()
        }

        findViewById<Button>(R.id.btnGrantA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnTurnOn).setOnClickListener {
            turnOnFloating()
        }

        findViewById<Button>(R.id.btnTurnOff).setOnClickListener {
            turnOffFloating()
        }

        bindSwitchListener()
        updateUiState()
    }

    override fun onResume() {
        super.onResume()
        updateUiState()
    }

    private fun bindSwitchListener() {
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) turnOnFloating() else turnOffFloating()
        }
    }

    private fun turnOnFloating() {
        if (!hasOverlayPermission()) {
            updateUiState()
            requestOverlayPermission()
            return
        }
        val startIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_START
        }
        ContextCompat.startForegroundService(this, startIntent)
        updateUiState(forceActive = true)
        Toast.makeText(this, "AI Floating ON — Pencet icon bubble untuk membuka tombol 1 • 2 • 3!", Toast.LENGTH_SHORT).show()
    }

    private fun turnOffFloating() {
        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_STOP
        }
        startService(stopIntent)
        updateUiState(forceActive = false)
        Toast.makeText(this, "AI Floating OFF", Toast.LENGTH_SHORT).show()
    }

    private fun updateUiState(forceActive: Boolean? = null) {
        val overlayOk = hasOverlayPermission()
        val notifOk = hasNotificationPermission()
        val a11yOk = isAccessibilityEnabled()

        tvOverlayStatus.text = if (overlayOk) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvOverlayStatus.setTextColor(getColor(if (overlayOk) R.color.neon_emerald else R.color.neon_coral))

        tvNotifStatus.text = if (notifOk) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvNotifStatus.setTextColor(getColor(if (notifOk) R.color.neon_emerald else R.color.neon_amber))

        tvA11yStatus.text = if (a11yOk) "Aktif ✓" else "Opsional (Cadangan Teks Layar)"
        tvA11yStatus.setTextColor(getColor(if (a11yOk) R.color.neon_emerald else R.color.text_secondary))

        val isActive = forceActive ?: (FloatingOverlayService.isRunning && overlayOk)
        switchFloating.setOnCheckedChangeListener(null)
        switchFloating.isChecked = isActive
        bindSwitchListener()

        if (isActive) {
            tvPowerLabel.text = "STATUS: ON"
            tvPowerLabel.setTextColor(getColor(R.color.neon_emerald))
            tvPowerSub.text = "Bubble mengambang aktif di tepi layar. Pencet icon untuk memunculkan tombol 1, 2 (+), dan 3."
        } else {
            tvPowerLabel.text = "STATUS: OFF"
            tvPowerLabel.setTextColor(getColor(R.color.neon_coral))
            tvPowerSub.text = "Aktifkan ON untuk memunculkan bubble mengambang di tepi layar."
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, ScreenTextAccessibilityService::class.java).flattenToString()
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun requestOverlayPermission() {
        AlertDialog.Builder(this)
            .setTitle("Izinkan Tampil di Atas Aplikasi")
            .setMessage("Pilih 'AI Floating' lalu aktifkan 'Tampilkan di atas aplikasi lain' agar bubble & kotak seleksi (+) bisa muncul di atas layar.")
            .setPositiveButton("Buka Pengaturan") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        } else {
            Toast.makeText(this, "Izin notifikasi sudah otomatis aktif", Toast.LENGTH_SHORT).show()
        }
    }
}
