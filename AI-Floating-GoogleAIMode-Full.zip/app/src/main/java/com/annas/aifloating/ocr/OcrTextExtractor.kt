package com.annas.aifloating.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Ekstraksi teks ultra-cepat menggunakan Google ML Kit on-device OCR
 * dari potongan gambar (Bitmap) tepat di dalam kotak seleksi.
 */
object OcrTextExtractor {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun extractText(croppedBitmap: Bitmap): String {
        val image = InputImage.fromBitmap(croppedBitmap, 0)
        val rawResult = withTimeoutOrNull(2500L) {
            suspendCancellableCoroutine { cont ->
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        if (cont.isActive) {
                            cont.resume(visionText.text)
                        }
                    }
                    .addOnFailureListener {
                        if (cont.isActive) {
                            cont.resume("")
                        }
                    }
            }
        }.orEmpty()

        return rawResult
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(" ")
            .replace(Regex("\s+"), " ")
            .trim()
    }
}
