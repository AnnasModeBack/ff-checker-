package com.annas.aifloating.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Custom View untuk mode kotak seleksi (+):
 * - Overlay gelap transparan di luar kotak seleksi (PorterDuff.Mode.CLEAR)
 * - Kotak seleksi cerah dengan 4 sudut & 4 sisi yang mulus (smooth drag & resize)
 * - Callback real-time agar Action Bar (X / ✓) selalu menempel tepat di bawah kotak seleksi
 */
class SelectionBoxOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class TouchMode {
        NONE, MOVE,
        RESIZE_TOP_LEFT, RESIZE_TOP_RIGHT, RESIZE_BOTTOM_LEFT, RESIZE_BOTTOM_RIGHT,
        RESIZE_LEFT, RESIZE_RIGHT, RESIZE_TOP, RESIZE_BOTTOM
    }

    var onSelectionChanged: ((RectF) -> Unit)? = null

    private val boxRect = RectF()
    private var initialized = false
    private var touchMode = TouchMode.NONE
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private val minBoxSize = 110f
    private val handleTouchRadius = 52f

    private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A6040812")
        style = Paint.Style.FILL
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF9D")
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3300F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!initialized && w > 0 && h > 0) {
            val boxW = w * 0.78f
            val boxH = h * 0.24f
            val left = (w - boxW) / 2f
            val top = (h - boxH) / 2.4f
            boxRect.set(left, top, left + boxW, top + boxH)
            initialized = true
            post { onSelectionChanged?.invoke(RectF(boxRect)) }
        }
    }

    fun getSelectionRect(): RectF = RectF(boxRect)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // 1. Lapisan gelap transparan penuh
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), scrimPaint)

        // 2. Lubangi area tepat di dalam kotak seleksi agar soal/konten terlihat jernih
        canvas.drawRoundRect(boxRect, 18f, 18f, clearPaint)

        // 3. Garis grid halus & border kotak seleksi
        val thirdW = boxRect.width() / 3f
        val thirdH = boxRect.height() / 3f
        canvas.drawLine(boxRect.left + thirdW, boxRect.top, boxRect.left + thirdW, boxRect.bottom, gridPaint)
        canvas.drawLine(boxRect.left + 2 * thirdW, boxRect.top, boxRect.left + 2 * thirdW, boxRect.bottom, gridPaint)
        canvas.drawLine(boxRect.left, boxRect.top + thirdH, boxRect.right, boxRect.top + thirdH, gridPaint)
        canvas.drawLine(boxRect.left, boxRect.top + 2 * thirdH, boxRect.right, boxRect.top + 2 * thirdH, gridPaint)

        canvas.drawRoundRect(boxRect, 18f, 18f, borderPaint)

        // 4. Penanda sudut L-bracket tebal agar mudah ditarik
        val cLen = 34f
        // Top-Left
        canvas.drawLine(boxRect.left, boxRect.top, boxRect.left + cLen, boxRect.top, cornerPaint)
        canvas.drawLine(boxRect.left, boxRect.top, boxRect.left, boxRect.top + cLen, cornerPaint)
        // Top-Right
        canvas.drawLine(boxRect.right - cLen, boxRect.top, boxRect.right, boxRect.top, cornerPaint)
        canvas.drawLine(boxRect.right, boxRect.top, boxRect.right, boxRect.top + cLen, cornerPaint)
        // Bottom-Left
        canvas.drawLine(boxRect.left, boxRect.bottom - cLen, boxRect.left, boxRect.bottom, cornerPaint)
        canvas.drawLine(boxRect.left, boxRect.bottom, boxRect.left + cLen, boxRect.bottom, cornerPaint)
        // Bottom-Right
        canvas.drawLine(boxRect.right - cLen, boxRect.bottom, boxRect.right, boxRect.bottom, cornerPaint)
        canvas.drawLine(boxRect.right, boxRect.bottom - cLen, boxRect.right, boxRect.bottom, cornerPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchMode = detectTouchMode(x, y)
                lastTouchX = x
                lastTouchY = y
                return touchMode != TouchMode.NONE
            }
            MotionEvent.ACTION_MOVE -> {
                if (touchMode == TouchMode.NONE) return false
                val dx = x - lastTouchX
                val dy = y - lastTouchY
                applyTransform(dx, dy)
                lastTouchX = x
                lastTouchY = y
                invalidate()
                onSelectionChanged?.invoke(RectF(boxRect))
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touchMode = TouchMode.NONE
                onSelectionChanged?.invoke(RectF(boxRect))
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun detectTouchMode(x: Float, y: Float): TouchMode {
        val nearLeft = abs(x - boxRect.left) <= handleTouchRadius
        val nearRight = abs(x - boxRect.right) <= handleTouchRadius
        val nearTop = abs(y - boxRect.top) <= handleTouchRadius
        val nearBottom = abs(y - boxRect.bottom) <= handleTouchRadius

        return when {
            nearLeft && nearTop -> TouchMode.RESIZE_TOP_LEFT
            nearRight && nearTop -> TouchMode.RESIZE_TOP_RIGHT
            nearLeft && nearBottom -> TouchMode.RESIZE_BOTTOM_LEFT
            nearRight && nearBottom -> TouchMode.RESIZE_BOTTOM_RIGHT
            nearLeft && y in boxRect.top..boxRect.bottom -> TouchMode.RESIZE_LEFT
            nearRight && y in boxRect.top..boxRect.bottom -> TouchMode.RESIZE_RIGHT
            nearTop && x in boxRect.left..boxRect.right -> TouchMode.RESIZE_TOP
            nearBottom && x in boxRect.left..boxRect.right -> TouchMode.RESIZE_BOTTOM
            boxRect.contains(x, y) -> TouchMode.MOVE
            else -> TouchMode.NONE
        }
    }

    private fun applyTransform(dx: Float, dy: Float) {
        val maxW = width.toFloat().coerceAtLeast(minBoxSize)
        val maxH = height.toFloat().coerceAtLeast(minBoxSize)

        when (touchMode) {
            TouchMode.MOVE -> {
                val clampedDx = dx.coerceIn(-boxRect.left, maxW - boxRect.right)
                val clampedDy = dy.coerceIn(-boxRect.top, maxH - boxRect.bottom)
                boxRect.offset(clampedDx, clampedDy)
            }
            TouchMode.RESIZE_TOP_LEFT -> {
                boxRect.left = (boxRect.left + dx).coerceIn(0f, boxRect.right - minBoxSize)
                boxRect.top = (boxRect.top + dy).coerceIn(0f, boxRect.bottom - minBoxSize)
            }
            TouchMode.RESIZE_TOP_RIGHT -> {
                boxRect.right = (boxRect.right + dx).coerceIn(boxRect.left + minBoxSize, maxW)
                boxRect.top = (boxRect.top + dy).coerceIn(0f, boxRect.bottom - minBoxSize)
            }
            TouchMode.RESIZE_BOTTOM_LEFT -> {
                boxRect.left = (boxRect.left + dx).coerceIn(0f, boxRect.right - minBoxSize)
                boxRect.bottom = (boxRect.bottom + dy).coerceIn(boxRect.top + minBoxSize, maxH)
            }
            TouchMode.RESIZE_BOTTOM_RIGHT -> {
                boxRect.right = (boxRect.right + dx).coerceIn(boxRect.left + minBoxSize, maxW)
                boxRect.bottom = (boxRect.bottom + dy).coerceIn(boxRect.top + minBoxSize, maxH)
            }
            TouchMode.RESIZE_LEFT -> {
                boxRect.left = (boxRect.left + dx).coerceIn(0f, boxRect.right - minBoxSize)
            }
            TouchMode.RESIZE_RIGHT -> {
                boxRect.right = (boxRect.right + dx).coerceIn(boxRect.left + minBoxSize, maxW)
            }
            TouchMode.RESIZE_TOP -> {
                boxRect.top = (boxRect.top + dy).coerceIn(0f, boxRect.bottom - minBoxSize)
            }
            TouchMode.RESIZE_BOTTOM -> {
                boxRect.bottom = (boxRect.bottom + dy).coerceIn(boxRect.top + minBoxSize, maxH)
            }
            TouchMode.NONE -> Unit
        }
    }
}
