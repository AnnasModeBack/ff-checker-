package com.annas.aifloating.state

/**
 * Representasi alur state eksplisit untuk AI Floating Overlay:
 * IDLE -> FLOATING_BAR_OPEN -> SELECTING_BOX -> EXTRACTING -> GOOGLE_AI_MODE
 */
enum class OverlayState {
    IDLE,
    FLOATING_BAR_OPEN,
    SELECTING_BOX,
    EXTRACTING,
    GOOGLE_AI_MODE
}
