package com.annas.aifloating.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.graphics.RectF
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Layanan Aksesibilitas opsional sebagai fallback instan untuk mengambil teks node
 * yang berada tepat di dalam koordinat kotak seleksi jika MediaProjection belum aktif.
 */
class ScreenTextAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenTextAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Tidak melakukan pemindaian berat di latar belakang agar hemat baterai & memori
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun extractTextInRect(selectionRect: RectF): String {
        val root = rootInActiveWindow ?: return ""
        val target = Rect(
            selectionRect.left.toInt(),
            selectionRect.top.toInt(),
            selectionRect.right.toInt(),
            selectionRect.bottom.toInt()
        )
        val collected = mutableListOf<String>()
        collectNodesInRect(root, target, collected)
        return collected.distinct().joinToString(" ").replace(Regex("\s+"), " ").trim()
    }

    private fun collectNodesInRect(
        node: AccessibilityNodeInfo?,
        targetRect: Rect,
        output: MutableList<String>
    ) {
        if (node == null) return
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (Rect.intersects(bounds, targetRect)) {
            val text = node.text?.toString()?.trim()
            if (!text.isNullOrEmpty()) {
                output.add(text)
            }
        }
        for (i in 0 until node.childCount) {
            collectNodesInRect(node.getChild(i), targetRect, output)
        }
    }
}
