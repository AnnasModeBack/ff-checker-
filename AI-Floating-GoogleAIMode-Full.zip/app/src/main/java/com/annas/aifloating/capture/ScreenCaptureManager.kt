package com.annas.aifloating.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Mengelola sesi MediaProjection, mengambil frame layar secara on-demand,
 * dan memotong (crop) hanya piksel tepat di dalam koordinat kotak seleksi.
 */
class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun hasProjection(): Boolean = mediaProjection != null

    fun initProjection(resultCode: Int, data: Intent) {
        release()
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)?.apply {
            registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mediaProjection = null
                }
            }, mainHandler)
        }
    }

    /**
     * Mengambil screenshot layar penuh lalu melakukan crop presisi sesuai [selectionRect].
     */
    suspend fun captureCroppedArea(selectionRect: RectF): Bitmap? {
        val projection = mediaProjection ?: return null
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        val fullBitmap = withTimeoutOrNull(1800L) {
            captureSingleFrame(projection, width, height, density)
        } ?: return null

        val left = selectionRect.left.toInt().coerceIn(0, fullBitmap.width - 1)
        val top = selectionRect.top.toInt().coerceIn(0, fullBitmap.height - 1)
        val cropW = selectionRect.width().toInt().coerceIn(1, fullBitmap.width - left)
        val cropH = selectionRect.height().toInt().coerceIn(1, fullBitmap.height - top)

        val cropped = Bitmap.createBitmap(fullBitmap, left, top, cropW, cropH)
        if (cropped != fullBitmap) {
            fullBitmap.recycle()
        }
        return cropped
    }

    private suspend fun captureSingleFrame(
        projection: MediaProjection,
        width: Int,
        height: Int,
        density: Int
    ): Bitmap? = suspendCancellableCoroutine { cont ->
        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null
        var completed = false

        fun cleanup() {
            try {
                virtualDisplay?.release()
            } catch (_: Exception) {
            }
            try {
                imageReader.close()
            } catch (_: Exception) {
            }
        }

        imageReader.setOnImageAvailableListener({ reader ->
            if (completed) return@setOnImageAvailableListener
            val image = try {
                reader.acquireLatestImage()
            } catch (_: Exception) {
                null
            } ?: return@setOnImageAvailableListener

            completed = true
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val rawBitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                rawBitmap.copyPixelsFromBuffer(buffer)
                val cleanBitmap = Bitmap.createBitmap(rawBitmap, 0, 0, width, height)
                if (cleanBitmap != rawBitmap) {
                    rawBitmap.recycle()
                }
                image.close()
                cleanup()
                if (cont.isActive) cont.resume(cleanBitmap)
            } catch (_: Exception) {
                try {
                    image.close()
                } catch (_: Exception) {
                }
                cleanup()
                if (cont.isActive) cont.resume(null)
            }
        }, mainHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "AIFloatingCropCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            mainHandler
        )

        cont.invokeOnCancellation {
            completed = true
            cleanup()
        }
    }

    fun release() {
        try {
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null
    }
}
