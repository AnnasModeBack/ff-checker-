#!/usr/bin/env bash
set -euo pipefail
echo "Launcher icons pre-generated in app/src/main/res/mipmap-*/ic_launcher*.png"
ls -la app/src/main/res/mipmap-*/ic_launcher*.png
