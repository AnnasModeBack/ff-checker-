package com.annas.aifloating

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator

object Animation3DHelper {

    fun apply3DTiltEntrance(view: View, delayMs: Long = 0L) {
        view.alpha = 0f
        view.scaleX = 0.72f
        view.scaleY = 0.72f
        view.rotationX = 20f
        view.rotationY = -16f
        view.cameraDistance = 16000f * view.resources.displayMetrics.density

        view.animate()
            .setStartDelay(delayMs)
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .rotationX(0f)
            .rotationY(0f)
            .setDuration(460L)
            .setInterpolator(OvershootInterpolator(1.3f))
            .start()
    }

    fun start3DFloatingIconLoop(view: View) {
        view.cameraDistance = 14000f * view.resources.displayMetrics.density
        val pvh = PropertyValuesHolder.ofFloat(View.ROTATION_Y, -18f, 18f)
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.94f, 1.06f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.94f, 1.06f)
        ObjectAnimator.ofPropertyValuesHolder(view, pvh, scaleX, scaleY).apply {
            duration = 1600L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    fun pop3DClick(view: View) {
        view.animate()
            .scaleX(0.88f)
            .scaleY(0.88f)
            .rotationY(14f)
            .setDuration(90L)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .rotationY(0f)
                    .setDuration(150L)
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }
            .start()
    }
}
