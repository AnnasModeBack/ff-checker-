package com.annas.aifloating

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val modes = listOf(
        "Auto Tugas & Jawaban Lengkap",
        "Pilihan Ganda Cepat (A/B/C/D/E + Alasan)",
        "Esai & Penjelasan Terstruktur",
        "Matematika & Langkah Hitung",
        "Coding & Debugging"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NotificationHelper.ensureChannel(this)

        val heroIcon = findViewById<ImageView>(R.id.ivHero3D)
        val mainCard = findViewById<LinearLayout>(R.id.mainCardContainer)
        val etApiKey = findViewById<EditText>(R.id.etApiKey)
        val spinnerMode = findViewById<Spinner>(R.id.spinnerMode)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnRequestNotif = findViewById<Button>(R.id.btnRequestNotif)
        val btnStart = findViewById<Button>(R.id.btnStartOverlay)
        val btnStop = findViewById<Button>(R.id.btnStopOverlay)

        Animation3DHelper.apply3DTiltEntrance(mainCard)
        Animation3DHelper.start3DFloatingIconLoop(heroIcon)
        heroIcon.setOnClickListener { Animation3DHelper.pop3DClick(heroIcon) }

        val prefs = getSharedPreferences("annas_ai_3d_prefs", Context.MODE_PRIVATE)
        etApiKey.setText(prefs.getString("api_key", ""))

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        spinnerMode.adapter = adapter
        spinnerMode.setSelection(prefs.getInt("mode_index", 0))

        btnSave.setOnClickListener {
            Animation3DHelper.pop3DClick(btnSave)
            val key = etApiKey.text.toString().trim()
            prefs.edit()
                .putString("api_key", key)
                .putInt("mode_index", spinnerMode.selectedItemPosition)
                .putString("mode_name", modes[spinnerMode.selectedItemPosition])
                .apply()
            Toast.makeText(this, "Pengaturan Google AI disimpan!", Toast.LENGTH_SHORT).show()
            NotificationHelper.showAnswerNotification(
                this,
                "Annas AI 3D HD",
                "Pengaturan API Key & mode tugas berhasil disimpan."
            )
        }

        btnRequestNotif.setOnClickListener {
            Animation3DHelper.pop3DClick(btnRequestNotif)
            requestNotificationPermissionIfNeeded()
        }

        btnStart.setOnClickListener {
            Animation3DHelper.pop3DClick(btnStart)
            requestNotificationPermissionIfNeeded()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain untuk bubble 3D", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return@setOnClickListener
            }
            val intent = Intent(this, FloatingAIService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Toast.makeText(this, "Annas AI 3D Floating aktif!", Toast.LENGTH_SHORT).show()
        }

        btnStop.setOnClickListener {
            Animation3DHelper.pop3DClick(btnStop)
            stopService(Intent(this, FloatingAIService::class.java))
            Toast.makeText(this, "Annas AI 3D Floating dimatikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            } else {
                Toast.makeText(this, "Izin pemberitahuan sudah aktif", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Pemberitahuan aktif di versi Android ini", Toast.LENGTH_SHORT).show()
        }
    }
}
