package com.annas.aifloating

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.annas.aifloating.service.FloatingChromeService
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvNotifStatus: TextView
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerSub: TextView
    private lateinit var switchFloating: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerSub = findViewById(R.id.tvPowerSub)
        switchFloating = findViewById(R.id.switchFloating)

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            requestOverlayPermissionWithGuide()
        }

        findViewById<Button>(R.id.btnGrantNotif).setOnClickListener {
            requestNotificationPermission()
        }

        findViewById<Button>(R.id.btnTurnOn).setOnClickListener {
            turnOnFloating()
        }

        findViewById<Button>(R.id.btnTurnOff).setOnClickListener {
            turnOffFloating()
        }

        bindSwitchListener()
        updateUiState()
    }

    override fun onResume() {
        super.onResume()
        updateUiState()
    }

    private fun bindSwitchListener() {
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                turnOnFloating()
            } else {
                turnOffFloating()
            }
        }
    }

    private fun turnOnFloating() {
        if (!hasOverlayPermission()) {
            updateUiState()
            requestOverlayPermissionWithGuide()
            return
        }
        val startIntent = Intent(this, FloatingChromeService::class.java).apply {
            action = FloatingChromeService.ACTION_START
        }
        ContextCompat.startForegroundService(this, startIntent)
        updateUiState(forceActiveState = true)
        Toast.makeText(this, "AI Floating ON — Pencet icon untuk buka Web!", Toast.LENGTH_SHORT).show()
    }

    private fun turnOffFloating() {
        val stopIntent = Intent(this, FloatingChromeService::class.java).apply {
            action = FloatingChromeService.ACTION_STOP
        }
        startService(stopIntent)
        updateUiState(forceActiveState = false)
        Toast.makeText(this, "AI Floating OFF", Toast.LENGTH_SHORT).show()
    }

    private fun updateUiState(forceActiveState: Boolean? = null) {
        val overlayGranted = hasOverlayPermission()
        val notifGranted = hasNotificationPermission()

        tvOverlayStatus.text = if (overlayGranted) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvOverlayStatus.setTextColor(getColor(if (overlayGranted) R.color.neon_emerald else R.color.neon_coral))

        tvNotifStatus.text = if (notifGranted) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvNotifStatus.setTextColor(getColor(if (notifGranted) R.color.neon_emerald else R.color.neon_amber))

        val isActive = forceActiveState ?: (FloatingChromeService.isRunning && overlayGranted)
        switchFloating.setOnCheckedChangeListener(null)
        switchFloating.isChecked = isActive
        bindSwitchListener()

        if (isActive) {
            tvPowerLabel.text = "STATUS: ON"
            tvPowerLabel.setTextColor(getColor(R.color.neon_emerald))
            tvPowerSub.text = "Icon mengambang aktif. Pencet icon untuk membuka Chrome Web langsung di atas layar tanpa keluar dari aplikasi lain."
        } else {
            tvPowerLabel.text = "STATUS: OFF"
            tvPowerLabel.setTextColor(getColor(R.color.neon_coral))
            tvPowerSub.text = "Tekan ON untuk memunculkan icon Chrome mengambang di layar."
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestOverlayPermissionWithGuide() {
        AlertDialog.Builder(this)
            .setTitle("Izinkan Tampil di Atas Aplikasi")
            .setMessage("Pilih 'AI Floating' lalu aktifkan izin 'Tampilkan di atas aplikasi lain' agar jendela web mengambang bisa tampil tanpa keluar dari aplikasi yang disematkan.")
            .setPositiveButton("Buka Pengaturan") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        } else {
            Toast.makeText(this, "Izin notifikasi sudah aktif otomatis", Toast.LENGTH_SHORT).show()
        }
    }
}
