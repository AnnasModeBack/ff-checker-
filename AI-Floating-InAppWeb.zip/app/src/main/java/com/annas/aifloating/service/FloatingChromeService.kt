package com.annas.aifloating.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.R
import java.net.URLEncoder
import kotlin.math.abs

class FloatingChromeService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloating.START"
        const val ACTION_STOP = "com.annas.aifloating.STOP"
        private const val NOTIF_ID = 2026
        private const val HOME_URL = "https://www.google.com"

        @Volatile
        var isRunning: Boolean = false
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var webWindowView: View? = null
    private var webView: WebView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var webParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            removeAllViews()
            isRunning = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning = false
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        startForeground(NOTIF_ID, buildNotification())
        showBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllViews()
        isRunning = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showBubble() {
        if (bubbleView != null) {
            bubbleView?.visibility = View.VISIBLE
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                    }
                    params.x = (startX + dx).coerceAtLeast(0)
                    params.y = (startY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        openInOverlayWeb()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openInOverlayWeb() {
        // Sembunyikan bubble sementara, tampilkan jendela WebView Chrome mengambang di posisi yang sama
        // Tanpa memanggil Intent ke aplikasi Chrome eksternal sehingga aplikasi yang disematkan (Screen Pinning) tetap aman!
        bubbleView?.visibility = View.GONE

        if (webWindowView != null) {
            webWindowView?.visibility = View.VISIBLE
            return
        }

        val wView = LayoutInflater.from(this).inflate(R.layout.floating_web_window, null)
        // Tanpa FLAG_NOT_FOCUSABLE agar keyboard bisa mengetik di kotak pencarian Google/URL di dalam WebView
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (bubbleParams?.x ?: 24).coerceAtLeast(12)
            y = (bubbleParams?.y ?: 140).coerceAtLeast(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val headerDrag = wView.findViewById<LinearLayout>(R.id.headerDragBar)
        val btnBack = wView.findViewById<TextView>(R.id.btnWebBack)
        val btnHome = wView.findViewById<TextView>(R.id.btnWebHome)
        val btnMinimize = wView.findViewById<TextView>(R.id.btnMinimizeWeb)
        val etUrl = wView.findViewById<EditText>(R.id.etWebUrl)
        val btnGo = wView.findViewById<TextView>(R.id.btnWebGo)
        val wv = wView.findViewById<WebView>(R.id.floatingWebView)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
        }

        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // Pastikan semua tautan tetap dimuat di dalam WebView mengambang ini, TIDAK pernah membuka APK Chrome luar
                val targetUrl = request?.url?.toString() ?: return false
                if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
                    view?.loadUrl(targetUrl)
                    etUrl.setText(targetUrl)
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    etUrl.setText(url)
                }
            }
        }

        fun navigateFromInput() {
            val raw = etUrl.text.toString().trim()
            if (raw.isEmpty()) {
                wv.loadUrl(HOME_URL)
                return
            }
            val finalUrl = when {
                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                else -> "https://www.google.com/search?q=" + URLEncoder.encode(raw, "UTF-8")
            }
            wv.loadUrl(finalUrl)
        }

        btnGo.setOnClickListener { navigateFromInput() }

        etUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateFromInput()
                true
            } else {
                false
            }
        }

        btnBack.setOnClickListener {
            if (wv.canGoBack()) {
                wv.goBack()
            }
        }

        btnHome.setOnClickListener {
            wv.loadUrl(HOME_URL)
        }

        btnMinimize.setOnClickListener {
            // Perkecil kembali menjadi icon bulat mengambang tanpa mematikan sesi web
            webWindowView?.visibility = View.GONE
            bubbleView?.visibility = View.VISIBLE
        }

        // Drag bar di bagian atas jendela web agar jendela Chrome Web bisa digeser bebas
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        headerDrag.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    params.x = (startX + dx).coerceAtLeast(0)
                    params.y = (startY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(wView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }

        wv.loadUrl(HOME_URL)
        webView = wv
        webParams = params
        webWindowView = wView
        windowManager.addView(wView, params)
    }

    private fun removeAllViews() {
        webView?.destroy()
        webView = null
        webWindowView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        webWindowView = null

        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleView = null
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val offIntent = Intent(this, FloatingChromeService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingOff = PendingIntent.getService(
            this, 1, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle("AI Floating Web Aktif")
            .setContentText("Ketuk icon mengambang untuk membuka Chrome Web di layar.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, "Matikan (OFF)", pendingOff)
            .build()
    }
}
