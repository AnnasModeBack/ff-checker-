# Annas AI 3D Pro v7 (Java Native Clean Build)

Aplikasi asisten tugas otomatis berbasis **Java murni** dengan **3D Floating Bubble**, **Kotak Penanda + Centang (✓) ke Google AI**, **Izin Pemberitahuan**, **Animasi 3D Tingkat Tinggi**, **Tipografi Tajam**, dan **100% Vector SVG Full HD**.

## Perbaikan Build di v7
- **Menghilangkan Error `android.support.**` di R8/ProGuard:** Sebelumnya pada v6, baris `-dontwarn android.support.**` dan penyaringan dependensi AndroidX yang terlalu sempit dapat memicu R8/DEX gagal saat `isMinifyEnabled = true` pada `debug`. Pada v7, `proguard-rules.pro` dan `app/build.gradle` dirapikan agar kompilasi resource, Java, dan R8 berjalan bersih tanpa error exit code 1.
- **Struktur Java Murni & Ringan:** Target ukuran APK tetap di kisaran ~1 MB dengan konfigurasi resource dan kode Java standar.
- **Kotak Penanda + Centang (✓) ke Google AI:** Arahkan kotak ke area tugas/soal, atur ukuran kotak, lalu ketuk tombol **Centang (`✓`)** untuk langsung mengirim ke **Google AI (`gemini-flash-latest`)**.
