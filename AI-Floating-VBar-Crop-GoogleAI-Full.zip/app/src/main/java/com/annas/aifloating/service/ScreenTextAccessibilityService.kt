package com.annas.aifloating.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenTextAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenTextAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive on-demand reader
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun extractTextInsideRect(cropRect: Rect): String {
        val root = rootInActiveWindow ?: return ""
        val collected = LinkedHashSet<String>()
        traverseNode(root, cropRect, collected)
        return collected.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, cropRect: Rect, out: MutableSet<String>) {
        if (node == null) return
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (Rect.intersects(bounds, cropRect)) {
            val txt = node.text?.toString()?.trim()
            if (!txt.isNullOrEmpty() && txt.length > 1) {
                out.add(txt)
            }
            val desc = node.contentDescription?.toString()?.trim()
            if (!desc.isNullOrEmpty() && desc.length > 1) {
                out.add(desc)
            }
        }
        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), cropRect, out)
        }
    }
}
