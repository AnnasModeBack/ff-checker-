package com.annas.aifloating

import android.content.Intent

object MediaProjectionStore {
    @Volatile
    var resultCode: Int = 0

    @Volatile
    var resultData: Intent? = null

    fun hasToken(): Boolean = resultData != null && resultCode != 0

    fun clear() {
        resultCode = 0
        resultData = null
    }
}
