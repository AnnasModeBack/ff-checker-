package com.annas.aifloating.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.annas.aifloating.R
import kotlin.math.hypot

class ScreenSelectionOverlayView(
    context: Context,
    private val onCancelCrop: () -> Unit,
    private val onConfirmCrop: (Rect) -> Unit
) : View(context) {

    private enum class DragMode {
        NONE, MOVE,
        TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT,
        LEFT, TOP, RIGHT, BOTTOM
    }

    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A6040812")
        style = Paint.Style.FILL
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4400F0FF")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val cornerAccentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF9D")
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    private val cancelBtnFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF4D6D")
        style = Paint.Style.FILL
    }

    private val confirmBtnFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF9D")
        style = Paint.Style.FILL
    }

    private val btnStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#060913")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val hintTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val hintPillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC0A1428")
        style = Paint.Style.FILL
    }

    private val iconCancel: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_svg_crop_cancel)
    private val iconConfirm: Drawable? = ContextCompat.getDrawable(context, R.drawable.ic_svg_crop_confirm)

    private val cropBox = RectF()
    private val cancelBtnRect = RectF()
    private val confirmBtnRect = RectF()

    private var initialized = false
    private var dragMode = DragMode.NONE
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private val minBoxSize = 130f
    private val touchSlopRadius = 56f

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!initialized && w > 0 && h > 0) {
            val boxW = w * 0.78f
            val boxH = h * 0.28f
            val left = (w - boxW) / 2f
            val top = (h - boxH) / 2.3f
            cropBox.set(left, top, left + boxW, top + boxH)
            initialized = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // 1. Overlay gelap transparan di luar area seleksi
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)

        // 2. Lubangi bagian dalam kotak seleksi agar konten soal terlihat jernih 100%
        canvas.drawRoundRect(cropBox, 18f, 18f, clearPaint)

        // 3. Garis tepi kotak seleksi + grid bantu 3x3
        canvas.drawRoundRect(cropBox, 18f, 18f, borderPaint)

        val thirdW = cropBox.width() / 3f
        val thirdH = cropBox.height() / 3f
        canvas.drawLine(cropBox.left + thirdW, cropBox.top, cropBox.left + thirdW, cropBox.bottom, gridPaint)
        canvas.drawLine(cropBox.left + 2 * thirdW, cropBox.top, cropBox.left + 2 * thirdW, cropBox.bottom, gridPaint)
        canvas.drawLine(cropBox.left, cropBox.top + thirdH, cropBox.right, cropBox.top + thirdH, gridPaint)
        canvas.drawLine(cropBox.left, cropBox.top + 2 * thirdH, cropBox.right, cropBox.top + 2 * thirdH, gridPaint)

        // 4. L-Bracket sudut kotak seleksi agar mudah di-resize
        val arm = 34f
        // Top-Left
        canvas.drawLine(cropBox.left, cropBox.top + arm, cropBox.left, cropBox.top, cornerAccentPaint)
        canvas.drawLine(cropBox.left, cropBox.top, cropBox.left + arm, cropBox.top, cornerAccentPaint)
        // Top-Right
        canvas.drawLine(cropBox.right - arm, cropBox.top, cropBox.right, cropBox.top, cornerAccentPaint)
        canvas.drawLine(cropBox.right, cropBox.top, cropBox.right, cropBox.top + arm, cornerAccentPaint)
        // Bottom-Left
        canvas.drawLine(cropBox.left, cropBox.bottom - arm, cropBox.left, cropBox.bottom, cornerAccentPaint)
        canvas.drawLine(cropBox.left, cropBox.bottom, cropBox.left + arm, cropBox.bottom, cornerAccentPaint)
        // Bottom-Right
        canvas.drawLine(cropBox.right - arm, cropBox.bottom, cropBox.right, cropBox.bottom, cornerAccentPaint)
        canvas.drawLine(cropBox.right, cropBox.bottom - arm, cropBox.right, cropBox.bottom, cornerAccentPaint)

        // 5. Petunjuk singkat di atas kotak
        val hintY = (cropBox.top - 26f).coerceAtLeast(64f)
        val pillW = 460f
        val pillH = 54f
        val cx = cropBox.centerX().coerceIn(pillW / 2f + 20f, width - pillW / 2f - 20f)
        canvas.drawRoundRect(cx - pillW / 2f, hintY - pillH + 14f, cx + pillW / 2f, hintY + 14f, 27f, 27f, hintPillPaint)
        canvas.drawText("Geser / Tarik Sudut • Tekan ✓", cx, hintY - 4f, hintTextPaint)

        // 6. Action Bar tepat di bawah (atau di atas jika mepet bawah) kotak seleksi: Tombol X & Tombol ✓
        val btnRadius = 52f
        val gap = 42f
        val barCenterX = cropBox.centerX().coerceIn(btnRadius * 2 + gap + 24f, width - (btnRadius * 2 + gap + 24f))
        val desiredTop = cropBox.bottom + 26f
        val barCenterY = if (desiredTop + btnRadius * 2 <= height - 36f) {
            desiredTop + btnRadius
        } else {
            (cropBox.top - 26f - btnRadius).coerceAtLeast(btnRadius + 80f)
        }

        val cancelCx = barCenterX - btnRadius - gap / 2f
        val confirmCx = barCenterX + btnRadius + gap / 2f

        cancelBtnRect.set(cancelCx - btnRadius, barCenterY - btnRadius, cancelCx + btnRadius, barCenterY + btnRadius)
        confirmBtnRect.set(confirmCx - btnRadius, barCenterY - btnRadius, confirmCx + btnRadius, barCenterY + btnRadius)

        canvas.drawCircle(cancelCx, barCenterY, btnRadius, cancelBtnFill)
        canvas.drawCircle(cancelCx, barCenterY, btnRadius, btnStrokePaint)
        iconCancel?.let {
            val pad = 26
            it.setBounds(
                (cancelCx - pad).toInt(),
                (barCenterY - pad).toInt(),
                (cancelCx + pad).toInt(),
                (barCenterY + pad).toInt()
            )
            it.draw(canvas)
        }

        canvas.drawCircle(confirmCx, barCenterY, btnRadius, confirmBtnFill)
        canvas.drawCircle(confirmCx, barCenterY, btnRadius, btnStrokePaint)
        iconConfirm?.let {
            val pad = 28
            it.setBounds(
                (confirmCx - pad).toInt(),
                (barCenterY - pad).toInt(),
                (confirmCx + pad).toInt(),
                (barCenterY + pad).toInt()
            )
            it.draw(canvas)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelBtnRect.contains(x, y)) {
                    onCancelCrop()
                    return true
                }
                if (confirmBtnRect.contains(x, y)) {
                    val resultRect = Rect(
                        cropBox.left.toInt().coerceAtLeast(0),
                        cropBox.top.toInt().coerceAtLeast(0),
                        cropBox.right.toInt().coerceAtMost(width),
                        cropBox.bottom.toInt().coerceAtMost(height)
                    )
                    onConfirmCrop(resultRect)
                    return true
                }

                dragMode = detectDragMode(x, y)
                lastTouchX = x
                lastTouchY = y
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = x - lastTouchX
                val dy = y - lastTouchY
                lastTouchX = x
                lastTouchY = y
                applyBoxTransform(dx, dy)
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragMode = DragMode.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun detectDragMode(x: Float, y: Float): DragMode {
        if (hypot(x - cropBox.left, y - cropBox.top) <= touchSlopRadius) return DragMode.TOP_LEFT
        if (hypot(x - cropBox.right, y - cropBox.top) <= touchSlopRadius) return DragMode.TOP_RIGHT
        if (hypot(x - cropBox.left, y - cropBox.bottom) <= touchSlopRadius) return DragMode.BOTTOM_LEFT
        if (hypot(x - cropBox.right, y - cropBox.bottom) <= touchSlopRadius) return DragMode.BOTTOM_RIGHT

        if (kotlin.math.abs(x - cropBox.left) <= touchSlopRadius && y in cropBox.top..cropBox.bottom) return DragMode.LEFT
        if (kotlin.math.abs(x - cropBox.right) <= touchSlopRadius && y in cropBox.top..cropBox.bottom) return DragMode.RIGHT
        if (kotlin.math.abs(y - cropBox.top) <= touchSlopRadius && x in cropBox.left..cropBox.right) return DragMode.TOP
        if (kotlin.math.abs(y - cropBox.bottom) <= touchSlopRadius && x in cropBox.left..cropBox.right) return DragMode.BOTTOM

        if (cropBox.contains(x, y)) return DragMode.MOVE
        return DragMode.NONE
    }

    private fun applyBoxTransform(dx: Float, dy: Float) {
        val maxW = width.toFloat()
        val maxH = height.toFloat()

        when (dragMode) {
            DragMode.MOVE -> {
                var newLeft = cropBox.left + dx
                var newTop = cropBox.top + dy
                if (newLeft < 0f) newLeft = 0f
                if (newTop < 0f) newTop = 0f
                if (newLeft + cropBox.width() > maxW) newLeft = maxW - cropBox.width()
                if (newTop + cropBox.height() > maxH) newTop = maxH - cropBox.height()
                cropBox.offsetTo(newLeft, newTop)
            }
            DragMode.TOP_LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.TOP_RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.BOTTOM_LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.BOTTOM_RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.LEFT -> {
                cropBox.left = (cropBox.left + dx).coerceIn(0f, cropBox.right - minBoxSize)
            }
            DragMode.RIGHT -> {
                cropBox.right = (cropBox.right + dx).coerceIn(cropBox.left + minBoxSize, maxW)
            }
            DragMode.TOP -> {
                cropBox.top = (cropBox.top + dy).coerceIn(0f, cropBox.bottom - minBoxSize)
            }
            DragMode.BOTTOM -> {
                cropBox.bottom = (cropBox.bottom + dy).coerceIn(cropBox.top + minBoxSize, maxH)
            }
            DragMode.NONE -> Unit
        }
    }
}
