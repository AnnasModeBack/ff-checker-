package com.annas.aifloating

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.annas.aifloating.service.FloatingOverlayService
import com.annas.aifloating.service.ScreenTextAccessibilityService
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvScreenCapStatus: TextView
    private lateinit var tvNotifStatus: TextView
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerSub: TextView
    private lateinit var switchFloating: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvScreenCapStatus = findViewById(R.id.tvScreenCapStatus)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerSub = findViewById(R.id.tvPowerSub)
        switchFloating = findViewById(R.id.switchFloating)

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            requestOverlayPermissionWithGuide()
        }

        findViewById<Button>(R.id.btnGrantScreenCap).setOnClickListener {
            val intent = Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                putExtra(ScreenCapturePermissionActivity.EXTRA_START_CROP_AFTER, false)
            }
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnGrantNotif).setOnClickListener {
            requestNotificationPermission()
        }

        findViewById<Button>(R.id.btnTurnOn).setOnClickListener {
            turnOnFloating()
        }

        findViewById<Button>(R.id.btnTurnOff).setOnClickListener {
            turnOffFloating()
        }

        findViewById<Button>(R.id.btnHideBubble).setOnClickListener {
            if (!FloatingOverlayService.isRunning) {
                Toast.makeText(this, "Aktifkan ON terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startService(Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_HIDE_ICON
            })
            updateUiState(forceActiveState = true, forceHiddenState = true)
            Toast.makeText(this, "Icon disembunyikan ke tepi layar", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnShowBubble).setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermissionWithGuide()
                return@setOnClickListener
            }
            val actionName = if (FloatingOverlayService.isRunning) {
                FloatingOverlayService.ACTION_SHOW_ICON
            } else {
                FloatingOverlayService.ACTION_START
            }
            ContextCompat.startForegroundService(this, Intent(this, FloatingOverlayService::class.java).apply {
                action = actionName
            })
            updateUiState(forceActiveState = true, forceHiddenState = false)
            Toast.makeText(this, "Icon mengambang dimunculkan lagi!", Toast.LENGTH_SHORT).show()
        }

        bindSwitchListener()
        updateUiState()
    }

    override fun onResume() {
        super.onResume()
        updateUiState()
    }

    private fun bindSwitchListener() {
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                turnOnFloating()
            } else {
                turnOffFloating()
            }
        }
    }

    private fun turnOnFloating() {
        if (!hasOverlayPermission()) {
            updateUiState()
            requestOverlayPermissionWithGuide()
            return
        }
        val startIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_START
        }
        ContextCompat.startForegroundService(this, startIntent)
        updateUiState(forceActiveState = true, forceHiddenState = false)
        Toast.makeText(this, "AI Floating ON — Pencet bubble untuk tombol 1, 2, 3!", Toast.LENGTH_SHORT).show()
    }

    private fun turnOffFloating() {
        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_STOP
        }
        startService(stopIntent)
        updateUiState(forceActiveState = false, forceHiddenState = false)
        Toast.makeText(this, "AI Floating OFF", Toast.LENGTH_SHORT).show()
    }

    private fun updateUiState(forceActiveState: Boolean? = null, forceHiddenState: Boolean? = null) {
        val overlayGranted = hasOverlayPermission()
        val notifGranted = hasNotificationPermission()
        val captureReady = MediaProjectionStore.hasToken() || ScreenTextAccessibilityService.instance != null

        tvOverlayStatus.text = if (overlayGranted) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvOverlayStatus.setTextColor(getColor(if (overlayGranted) R.color.neon_emerald else R.color.neon_coral))

        tvScreenCapStatus.text = if (captureReady) "Aktif ✓" else "Siap (Diminta otomatis saat tekan +)"
        tvScreenCapStatus.setTextColor(getColor(if (captureReady) R.color.neon_emerald else R.color.neon_amber))

        tvNotifStatus.text = if (notifGranted) "Sudah Diizinkan ✓" else "Belum Diizinkan"
        tvNotifStatus.setTextColor(getColor(if (notifGranted) R.color.neon_emerald else R.color.neon_amber))

        val isActive = forceActiveState ?: (FloatingOverlayService.isRunning && overlayGranted)
        val isHidden = forceHiddenState ?: FloatingOverlayService.isIconHidden

        switchFloating.setOnCheckedChangeListener(null)
        switchFloating.isChecked = isActive
        bindSwitchListener()

        if (isActive) {
            if (isHidden) {
                tvPowerLabel.text = "STATUS: ON (TERSEMBUNYI)"
                tvPowerLabel.setTextColor(getColor(R.color.neon_amber))
                tvPowerSub.text = "Icon sedang disembunyikan. Ketuk 'Munculkan Lagi', panah tepi layar, atau notifikasi."
            } else {
                tvPowerLabel.text = "STATUS: ON"
                tvPowerLabel.setTextColor(getColor(R.color.neon_emerald))
                tvPowerSub.text = "Bubble mengambang aktif. Pencet bubble untuk membuka menu vertikal 1, 2, 3."
            }
        } else {
            tvPowerLabel.text = "STATUS: OFF"
            tvPowerLabel.setTextColor(getColor(R.color.neon_coral))
            tvPowerSub.text = "Tekan ON untuk memunculkan bubble mengambang SVG."
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestOverlayPermissionWithGuide() {
        AlertDialog.Builder(this)
            .setTitle("Izinkan Tampil di Atas Aplikasi")
            .setMessage("Pilih 'AI Floating' lalu aktifkan izin 'Tampilkan di atas aplikasi lain' agar bubble & kotak seleksi area bisa tampil di layar.")
            .setPositiveButton("Buka Pengaturan") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        } else {
            Toast.makeText(this, "Izin notifikasi sudah aktif otomatis", Toast.LENGTH_SHORT).show()
        }
    }
}
