package com.annas.aifloating.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.MediaProjectionStore
import com.annas.aifloating.R
import com.annas.aifloating.ScreenCapturePermissionActivity
import com.annas.aifloating.overlay.ScreenSelectionOverlayView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.net.URLEncoder
import kotlin.math.abs

class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloating.START"
        const val ACTION_STOP = "com.annas.aifloating.STOP"
        const val ACTION_HIDE_ICON = "com.annas.aifloating.HIDE_ICON"
        const val ACTION_SHOW_ICON = "com.annas.aifloating.SHOW_ICON"
        const val ACTION_ENTER_CROP_MODE = "com.annas.aifloating.ENTER_CROP_MODE"
        const val ACTION_PROJECTION_READY = "com.annas.aifloating.PROJECTION_READY"

        private const val NOTIF_ID = 2026
        private const val GOOGLE_AI_MODE_HOME = "https://www.google.com/search?udm=50"
        private const val WEB_BROWSER_HOME = "https://www.google.com"

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        var isIconHidden: Boolean = false
    }

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val textRecognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    // Views
    private var bubbleView: View? = null
    private var verticalBarView: View? = null
    private var cropOverlayView: ScreenSelectionOverlayView? = null
    private var hiddenHandleView: View? = null
    private var webWindowView: View? = null
    private var webView: WebView? = null

    // Window Params
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var vbarParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var webParams: WindowManager.LayoutParams? = null

    // Web UI references
    private var tvWindowModeTitle: TextView? = null
    private var etWebUrl: EditText? = null
    private var statusBanner: LinearLayout? = null
    private var tvProcessingStatus: TextView? = null
    private var isFullscreenMode: Boolean = true

    // MediaProjection resources
    private var mediaProjection: MediaProjection? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                cleanupAllResources()
                isRunning = false
                isIconHidden = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    hideBubbleToEdge()
                }
                return START_STICKY
            }
            ACTION_SHOW_ICON -> {
                if (isRunning && Settings.canDrawOverlays(this)) {
                    collapseToBubble()
                }
                return START_STICKY
            }
            ACTION_PROJECTION_READY -> {
                startForegroundCompat()
                initMediaProjectionIfAvailable()
                return START_STICKY
            }
            ACTION_ENTER_CROP_MODE -> {
                startForegroundCompat()
                initMediaProjectionIfAvailable()
                showCropSelectionBox()
                return START_STICKY
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning = false
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        isIconHidden = false
        startForegroundCompat()
        initMediaProjectionIfAvailable()
        collapseToBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanupAllResources()
        isRunning = false
        isIconHidden = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundCompat() {
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val fgsType = if (MediaProjectionStore.hasToken()) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            }
            startForeground(NOTIF_ID, notif, fgsType)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun initMediaProjectionIfAvailable() {
        if (mediaProjection != null) return
        if (!MediaProjectionStore.hasToken()) return
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(
                MediaProjectionStore.resultCode,
                MediaProjectionStore.resultData!!
            )?.apply {
                registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        mediaProjection = null
                        MediaProjectionStore.clear()
                    }
                }, mainHandler)
            }
        } catch (_: Exception) {
            mediaProjection = null
        }
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun getScreenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    // =========================================================================
    // 1. FLOATING BUBBLE (Draggable + Auto-Snap ke tepi layar)
    // =========================================================================
    private fun collapseToBubble() {
        removeCropOverlay()
        verticalBarView?.visibility = View.GONE
        hiddenHandleView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (bubbleView != null) {
            bubbleView?.visibility = View.VISIBLE
            snapBubbleToNearestEdge()
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 280
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                hideBubbleToEdge()
                Toast.makeText(
                    this,
                    "Icon disembunyikan. Ketuk panah tepi layar atau notifikasi untuk memunculkan lagi.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 650)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    val metrics = getScreenMetrics()
                    params.x = (startX + dx).coerceIn(0, (metrics.widthPixels - 140).coerceAtLeast(0))
                    params.y = (startY + dy).coerceIn(40, (metrics.heightPixels - 180).coerceAtLeast(40))
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!isDragging && !longPressTriggered && event.action == MotionEvent.ACTION_UP) {
                        openVerticalBar()
                    } else if (isDragging) {
                        snapBubbleToNearestEdge()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    private fun snapBubbleToNearestEdge() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        val metrics = getScreenMetrics()
        val bubbleW = if (view.width > 0) view.width else (58 * metrics.density).toInt()
        val maxX = (metrics.widthPixels - bubbleW - 12).coerceAtLeast(12)
        val targetX = if (params.x + bubbleW / 2 < metrics.widthPixels / 2) 12 else maxX

        ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                try {
                    if (view.parent != null) {
                        windowManager.updateViewLayout(view, params)
                    }
                } catch (_: Exception) {
                }
            }
            start()
        }
    }

    // =========================================================================
    // 2. FLOATING BAR VERTIKAL RINGKAS (Tombol 1, Tombol 2, Tombol 3, Tombol 4)
    // =========================================================================
    private fun openVerticalBar() {
        bubbleView?.visibility = View.GONE
        removeCropOverlay()

        val bx = bubbleParams?.x ?: 16
        val by = bubbleParams?.y ?: 280
        val metrics = getScreenMetrics()
        val barWidthPx = (64 * metrics.density).toInt()
        val safeX = bx.coerceIn(12, (metrics.widthPixels - barWidthPx - 12).coerceAtLeast(12))
        val safeY = by.coerceIn(60, (metrics.heightPixels - (260 * metrics.density).toInt()).coerceAtLeast(60))

        if (verticalBarView != null) {
            vbarParams?.x = safeX
            vbarParams?.y = safeY
            try {
                windowManager.updateViewLayout(verticalBarView, vbarParams)
            } catch (_: Exception) {
            }
            verticalBarView?.visibility = View.VISIBLE
            return
        }

        val barView = LayoutInflater.from(this).inflate(R.layout.floating_vertical_bar, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = safeX
            y = safeY
        }

        // Tombol 1 (🔍 / Cari & AI): Buka langsung tampilan Google AI Mode
        barView.findViewById<LinearLayout>(R.id.btnVbar1SearchAi).setOnClickListener {
            openFloatingWeb(
                url = GOOGLE_AI_MODE_HOME,
                title = "Google AI Mode",
                processingHint = null
            )
        }

        // Tombol 2 (+ / Seleksi Area): Aktifkan kotak seleksi layar (crop box)
        barView.findViewById<LinearLayout>(R.id.btnVbar2CropArea).setOnClickListener {
            verticalBarView?.visibility = View.GONE
            if (mediaProjection == null && !MediaProjectionStore.hasToken() &&
                ScreenTextAccessibilityService.instance == null
            ) {
                // Minta izin MediaProjection 1x agar crop gambar OCR berjalan optimal
                val permIntent = Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra(ScreenCapturePermissionActivity.EXTRA_START_CROP_AFTER, true)
                }
                startActivity(permIntent)
            } else {
                initMediaProjectionIfAvailable()
                showCropSelectionBox()
            }
        }

        // Tombol 3 (🌐 / Web & Browser): Buka halaman web/browser dalam jendela floating
        barView.findViewById<LinearLayout>(R.id.btnVbar3WebBrowser).setOnClickListener {
            openFloatingWeb(
                url = WEB_BROWSER_HOME,
                title = "Web Browser Floating",
                processingHint = null
            )
        }

        // Tombol 4 (Bawah / Tutup & Minimize): Lipat kembali ke bubble floating
        barView.findViewById<LinearLayout>(R.id.btnVbar4Collapse).setOnClickListener {
            collapseToBubble()
        }

        vbarParams = params
        verticalBarView = barView
        windowManager.addView(barView, params)
    }

    // =========================================================================
    // 3. MODE KOTAK SELEKSI (+) & TOMBOL AKSI X / ✓ -> GOOGLE AI MODE
    // =========================================================================
    private fun showCropSelectionBox() {
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        removeCropOverlay()

        val cropView = ScreenSelectionOverlayView(
            context = this,
            onCancelCrop = {
                // Tombol Batal (X): batalkan seleksi tanpa memproses & kembali ke bubble/bar
                removeCropOverlay()
                collapseToBubble()
            },
            onConfirmCrop = { selectedRect ->
                // Tombol Centang (✓): kunci area di dalam kotak seleksi, ekstrak cepat, kirim ke Google AI Mode
                removeCropOverlay()
                processCroppedSelectionToGoogleAi(selectedRect)
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        cropOverlayView = cropView
        windowManager.addView(cropView, params)
    }

    private fun removeCropOverlay() {
        cropOverlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        cropOverlayView = null
    }

    private fun processCroppedSelectionToGoogleAi(cropRect: Rect) {
        // Segera tampilkan jendela Google AI Mode dengan status indikator singkat agar transisi instan & responsif
        openFloatingWeb(
            url = GOOGLE_AI_MODE_HOME,
            title = "Google AI Mode",
            processingHint = "Membaca area kotak seleksi..."
        )

        // Beri jeda 90ms agar overlay crop benar-benar hilang dari layar sebelum capture bitmap
        mainHandler.postDelayed({
            val projection = mediaProjection
            if (projection != null) {
                captureAndOcrRect(projection, cropRect)
            } else {
                // Fallback ke AccessibilityService di dalam koordinat kotak seleksi
                val a11yText = ScreenTextAccessibilityService.instance?.extractTextInsideRect(cropRect).orEmpty()
                if (a11yText.isNotBlank()) {
                    sendExtractedTextToGoogleAiMode(a11yText)
                } else {
                    showFallbackInAiWindow("Area siap — ketik atau tempel soal di kolom AI di atas.")
                }
            }
        }, 90)
    }

    private fun captureAndOcrRect(projection: MediaProjection, cropRect: Rect) {
        try {
            val metrics = getScreenMetrics()
            val screenW = metrics.widthPixels
            val screenH = metrics.heightPixels
            val density = metrics.densityDpi

            val imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
            var virtualDisplay: VirtualDisplay? = null

            virtualDisplay = projection.createVirtualDisplay(
                "AIFloatingCropCapture",
                screenW,
                screenH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                mainHandler
            )

            mainHandler.postDelayed({
                try {
                    val image = imageReader.acquireLatestImage()
                    if (image != null) {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * screenW

                        val fullBitmap = Bitmap.createBitmap(
                            screenW + rowPadding / pixelStride,
                            screenH,
                            Bitmap.Config.ARGB_8888
                        )
                        fullBitmap.copyPixelsFromBuffer(buffer)
                        image.close()

                        virtualDisplay?.release()
                        imageReader.close()

                        // Potong HANYA bagian gambar di dalam kotak seleksi (abaikan area di luar kotak)
                        val safeLeft = cropRect.left.coerceIn(0, screenW - 10)
                        val safeTop = cropRect.top.coerceIn(0, screenH - 10)
                        val safeWidth = cropRect.width().coerceIn(10, screenW - safeLeft)
                        val safeHeight = cropRect.height().coerceIn(10, screenH - safeTop)

                        val croppedBitmap = Bitmap.createBitmap(
                            fullBitmap,
                            safeLeft,
                            safeTop,
                            safeWidth,
                            safeHeight
                        )
                        fullBitmap.recycle()

                        runMlKitOcr(croppedBitmap, cropRect)
                    } else {
                        virtualDisplay?.release()
                        imageReader.close()
                        fallbackAfterCaptureFailure(cropRect)
                    }
                } catch (_: Exception) {
                    try {
                        virtualDisplay?.release()
                        imageReader.close()
                    } catch (_: Exception) {
                    }
                    fallbackAfterCaptureFailure(cropRect)
                }
            }, 120)
        } catch (_: Exception) {
            fallbackAfterCaptureFailure(cropRect)
        }
    }

    private fun runMlKitOcr(croppedBitmap: Bitmap, cropRect: Rect) {
        val inputImage = InputImage.fromBitmap(croppedBitmap, 0)
        textRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                croppedBitmap.recycle()
                val extracted = visionText.text
                    .replace(Regex("\\s+"), " ")
                    .trim()
                if (extracted.isNotBlank()) {
                    sendExtractedTextToGoogleAiMode(extracted)
                } else {
                    fallbackAfterCaptureFailure(cropRect)
                }
            }
            .addOnFailureListener {
                croppedBitmap.recycle()
                fallbackAfterCaptureFailure(cropRect)
            }
    }

    private fun fallbackAfterCaptureFailure(cropRect: Rect) {
        val a11yText = ScreenTextAccessibilityService.instance?.extractTextInsideRect(cropRect).orEmpty()
        if (a11yText.isNotBlank()) {
            sendExtractedTextToGoogleAiMode(a11yText)
        } else {
            showFallbackInAiWindow("Teks area kurang jelas — ketik kata kunci soal di kolom atas untuk jawaban AI.")
        }
    }

    private fun sendExtractedTextToGoogleAiMode(extractedText: String) {
        val trimmedQuery = if (extractedText.length > 900) {
            extractedText.substring(0, 900)
        } else {
            extractedText
        }
        val encoded = URLEncoder.encode(trimmedQuery, "UTF-8")
        // Langsung kirim hasil ekstraksi ke Google AI Mode (udm=50)
        val googleAiUrl = "https://www.google.com/search?udm=50&q=$encoded"

        etWebUrl?.setText(trimmedQuery)
        tvProcessingStatus?.text = "Hasil area dikirim ke Google AI Mode ✓"
        webView?.loadUrl(googleAiUrl)

        mainHandler.postDelayed({
            statusBanner?.visibility = View.GONE
        }, 1600)
    }

    private fun showFallbackInAiWindow(message: String) {
        tvProcessingStatus?.text = message
        mainHandler.postDelayed({
            statusBanner?.visibility = View.GONE
        }, 3200)
    }

    // =========================================================================
    // 4. JENDELA FLOATING GOOGLE AI MODE & WEB BROWSER
    // =========================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private fun openFloatingWeb(url: String, title: String, processingHint: String?) {
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        hiddenHandleView?.visibility = View.GONE
        isIconHidden = false
        updateNotification()

        if (webWindowView != null) {
            tvWindowModeTitle?.text = title
            if (!processingHint.isNullOrBlank()) {
                statusBanner?.visibility = View.VISIBLE
                tvProcessingStatus?.text = processingHint
            } else {
                statusBanner?.visibility = View.GONE
            }
            webWindowView?.visibility = View.VISIBLE
            applyWindowSize(fullscreen = true)
            webView?.loadUrl(url)
            return
        }

        val wView = LayoutInflater.from(this).inflate(R.layout.floating_web_window, null)
        val metrics = getScreenMetrics()
        val fullW = (metrics.widthPixels * 0.96f).toInt()
        val fullH = (metrics.heightPixels * 0.88f).toInt()

        val params = WindowManager.LayoutParams(
            fullW,
            fullH,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val headerDrag = wView.findViewById<LinearLayout>(R.id.headerDragBar)
        val titleView = wView.findViewById<TextView>(R.id.tvWindowModeTitle)
        val btnRecrop = wView.findViewById<ImageButton>(R.id.btnQuickRecrop)
        val btnBack = wView.findViewById<ImageButton>(R.id.btnWebBack)
        val btnRefresh = wView.findViewById<ImageButton>(R.id.btnWebRefresh)
        val btnToggleSize = wView.findViewById<ImageButton>(R.id.btnToggleSize)
        val btnHideAll = wView.findViewById<ImageButton>(R.id.btnHideAll)
        val btnMinimize = wView.findViewById<ImageButton>(R.id.btnMinimizeWeb)
        val urlInput = wView.findViewById<EditText>(R.id.etWebUrl)
        val btnGo = wView.findViewById<LinearLayout>(R.id.btnWebGo)
        val banner = wView.findViewById<LinearLayout>(R.id.statusProcessingBanner)
        val bannerText = wView.findViewById<TextView>(R.id.tvProcessingStatus)
        val progressBar = wView.findViewById<ProgressBar>(R.id.webProgressBar)
        val wv = wView.findViewById<WebView>(R.id.floatingWebView)

        titleView.text = title
        if (!processingHint.isNullOrBlank()) {
            banner.visibility = View.VISIBLE
            bannerText.text = processingHint
        }

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val targetUrl = request?.url?.toString() ?: return false
                if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
                    view?.loadUrl(targetUrl)
                }
                return true
            }
        }

        fun submitSearchOrUrl() {
            val raw = urlInput.text.toString().trim()
            if (raw.isEmpty()) {
                wv.loadUrl(GOOGLE_AI_MODE_HOME)
                return
            }
            val finalUrl = when {
                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                else -> "https://www.google.com/search?udm=50&q=" + URLEncoder.encode(raw, "UTF-8")
            }
            wv.loadUrl(finalUrl)
        }

        btnGo.setOnClickListener { submitSearchOrUrl() }
        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                submitSearchOrUrl()
                true
            } else {
                false
            }
        }

        btnRecrop.setOnClickListener {
            showCropSelectionBox()
        }

        btnBack.setOnClickListener {
            if (wv.canGoBack()) wv.goBack()
        }

        btnRefresh.setOnClickListener {
            wv.reload()
        }

        btnToggleSize.setOnClickListener {
            isFullscreenMode = !isFullscreenMode
            applyWindowSize(fullscreen = isFullscreenMode)
        }

        btnHideAll.setOnClickListener {
            hideBubbleToEdge()
        }

        btnMinimize.setOnClickListener {
            collapseToBubble()
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        headerDrag.setOnTouchListener { _, event ->
            if (isFullscreenMode) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try {
                        windowManager.updateViewLayout(wView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }

        wv.loadUrl(url)
        isFullscreenMode = true
        tvWindowModeTitle = titleView
        etWebUrl = urlInput
        statusBanner = banner
        tvProcessingStatus = bannerText
        webView = wv
        webParams = params
        webWindowView = wView
        windowManager.addView(wView, params)
    }

    private fun applyWindowSize(fullscreen: Boolean) {
        val wView = webWindowView ?: return
        val params = webParams ?: return
        val metrics = getScreenMetrics()
        isFullscreenMode = fullscreen
        if (fullscreen) {
            params.width = (metrics.widthPixels * 0.96f).toInt()
            params.height = (metrics.heightPixels * 0.88f).toInt()
            params.gravity = Gravity.CENTER
            params.x = 0
            params.y = 0
        } else {
            params.width = (metrics.widthPixels * 0.86f).toInt()
            params.height = (metrics.heightPixels * 0.56f).toInt()
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 24
            params.y = 140
        }
        try {
            windowManager.updateViewLayout(wView, params)
        } catch (_: Exception) {
        }
    }

    // =========================================================================
    // 5. SEMBUNYIKAN & MUNCULKAN LAGI ICON MENGAMBANG
    // =========================================================================
    private fun hideBubbleToEdge() {
        isIconHidden = true
        removeCropOverlay()
        bubbleView?.visibility = View.GONE
        verticalBarView?.visibility = View.GONE
        webWindowView?.visibility = View.GONE
        updateNotification()

        if (hiddenHandleView != null) {
            hiddenHandleView?.visibility = View.VISIBLE
            return
        }

        val hView = LayoutInflater.from(this).inflate(R.layout.floating_hidden_handle, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = bubbleParams?.y ?: 280
        }

        var startY = 0
        var touchY = 0f
        var isDragging = false

        hView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = params.y
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dy) > 10) isDragging = true
                    params.y = (startY + dy).coerceAtLeast(40)
                    try {
                        windowManager.updateViewLayout(hView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        collapseToBubble()
                    }
                    true
                }
                else -> false
            }
        }

        handleParams = params
        hiddenHandleView = hView
        windowManager.addView(hView, params)
    }

    // =========================================================================
    // 6. LIFECYCLE CLEANUP & NOTIFICATION
    // =========================================================================
    private fun cleanupAllResources() {
        mainHandler.removeCallbacksAndMessages(null)
        removeCropOverlay()

        try {
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null

        webView?.destroy()
        webView = null
        webWindowView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        webWindowView = null

        verticalBarView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        verticalBarView = null

        hiddenHandleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        hiddenHandleView = null

        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleView = null
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleVisIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = if (isIconHidden) ACTION_SHOW_ICON else ACTION_HIDE_ICON
        }
        val pendingToggleVis = PendingIntent.getService(
            this, 2, toggleVisIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val offIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingOff = PendingIntent.getService(
            this, 1, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isIconHidden) "AI Floating (Icon Tersembunyi)" else "AI Floating Aktif"
        val text = if (isIconHidden) {
            "Ketuk 'Munculkan Lagi' untuk menampilkan bubble SVG."
        } else {
            "Ketuk bubble untuk membuka menu vertikal 1•AI, 2•Area (+), 3•Web."
        }
        val toggleBtnText = if (isIconHidden) "Munculkan Lagi" else "Sembunyikan"

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, toggleBtnText, pendingToggleVis)
            .addAction(0, "OFF", pendingOff)
            .build()
    }
}
