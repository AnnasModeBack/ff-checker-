package com.annas.aifloating

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.annas.aifloating.service.FloatingOverlayService

class ScreenCapturePermissionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_START_CROP_AFTER = "start_crop_after"
    }

    private var startCropAfter: Boolean = true

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            MediaProjectionStore.resultCode = result.resultCode
            MediaProjectionStore.resultData = result.data
        }
        if (FloatingOverlayService.isRunning) {
            val svcIntent = Intent(this, FloatingOverlayService::class.java).apply {
                action = if (startCropAfter) {
                    FloatingOverlayService.ACTION_ENTER_CROP_MODE
                } else {
                    FloatingOverlayService.ACTION_PROJECTION_READY
                }
            }
            ContextCompat.startForegroundService(this, svcIntent)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startCropAfter = intent.getBooleanExtra(EXTRA_START_CROP_AFTER, true)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }
}
