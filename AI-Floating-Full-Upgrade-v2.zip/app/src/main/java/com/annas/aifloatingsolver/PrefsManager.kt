package com.annas.aifloatingsolver

import android.content.Context

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("ai_floating_prefs", Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_GEMINI_KEY = "AQ.Ab8RN6Igcr4w5cRCyoh03fkvcdCgW7ZWadHycVHeDIx7jhtr_Q"
    }

    var isMasterEnabled: Boolean
        get() = prefs.getBoolean("master_enabled", false)
        set(value) = prefs.edit().putBoolean("master_enabled", value).apply()

    var isBubbleVisible: Boolean
        get() = prefs.getBoolean("bubble_visible", true)
        set(value) = prefs.edit().putBoolean("bubble_visible", value).apply()

    var apiKey: String
        get() = prefs.getString("gemini_api_key", DEFAULT_GEMINI_KEY) ?: DEFAULT_GEMINI_KEY
        set(value) = prefs.edit().putString("gemini_api_key", value.trim()).apply()

    var subject: String
        get() = prefs.getString("subject", "Semua Mata Pelajaran") ?: "Semua Mata Pelajaran"
        set(value) = prefs.edit().putString("subject", value).apply()

    var delaySeconds: Float
        get() = prefs.getFloat("delay_seconds", 2.5f)
        set(value) = prefs.edit().putFloat("delay_seconds", value.coerceIn(0.8f, 30.0f)).apply()

    var autoClickEnabled: Boolean
        get() = prefs.getBoolean("auto_click_enabled", true)
        set(value) = prefs.edit().putBoolean("auto_click_enabled", value).apply()
}
