package com.annas.aifloatingsolver.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object McqSolverEngine {

    private const val ENDPOINT_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

    fun askGeminiDirect(apiKey: String, promptText: String): String {
        val effectiveKey = apiKey.trim()
        if (effectiveKey.isEmpty()) {
            return "API Key / Token kosong. Silakan isi di Pengaturan."
        }
        return try {
            val resp = callGeminiApi(effectiveKey, promptText.take(3500))
            if (resp.isNotBlank()) resp.trim() else "Tidak ada respons teks dari Gemini."
        } catch (e: Exception) {
            "Gagal terhubung ke Gemini API: ${e.message ?: "kesalahan jaringan"}"
        }
    }

    fun solveMcq(
        apiKey: String,
        subject: String,
        questionAndOptionsText: String
    ): Pair<String, String> {
        if (apiKey.isNotBlank()) {
            try {
                val prompt = "Kamu adalah asisten soal pilihan ganda (A, B, C, D, E) untuk mata pelajaran: $subject. " +
                    "Analisis soal berikut dan jawab dengan format singkat: 'JAWABAN: <HURUF>' diikuti alasan 1 kalimat.\n\n" +
                    questionAndOptionsText.take(2500)
                val aiAnswer = callGeminiApi(apiKey.trim(), prompt)
                if (aiAnswer.isNotBlank()) {
                    val letter = extractOptionLetter(aiAnswer)
                    return Pair(letter, aiAnswer.trim())
                }
            } catch (_: Exception) {
            }
        }
        return localHeuristicSolve(subject, questionAndOptionsText)
    }

    private fun callGeminiApi(apiKey: String, textPrompt: String): String {
        val url = URL(ENDPOINT_URL)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("X-goog-api-key", apiKey)
            connectTimeout = 12000
            readTimeout = 18000
            doOutput = true
        }

        val bodyJson = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", textPrompt)))
            }))
        }

        OutputStreamWriter(conn.outputStream, "UTF-8").use { writer ->
            writer.write(bodyJson.toString())
            writer.flush()
        }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
        conn.disconnect()

        if (code !in 200..299) {
            return if (responseText.isNotBlank()) "HTTP $code: $responseText" else ""
        }
        val root = JSONObject(responseText)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0)
            .optJSONObject("content")
            ?.optJSONArray("parts") ?: return ""
        if (parts.length() == 0) return ""
        return parts.getJSONObject(0).optString("text", "")
    }

    fun extractOptionLetter(raw: String): String {
        val regex = Regex("\\b([A-E])\\b", RegexOption.IGNORE_CASE)
        val match = regex.find(raw)
        return match?.value?.uppercase() ?: "A"
    }

    private fun localHeuristicSolve(subject: String, text: String): Pair<String, String> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val optionLines = lines.filter {
            Regex("^[A-Ea-e][\\).:\\-]\\s+.+").containsMatchIn(it)
        }
        if (optionLines.isNotEmpty()) {
            val best = optionLines.maxByOrNull { it.length } ?: optionLines.first()
            val letter = best.first().uppercaseChar().toString()
            return Pair(letter, "Analisis lokal ($subject): opsi $letter paling spesifik dan lengkap.")
        }
        return Pair("A", "Analisis lokal ($subject): memilih opsi A sebagai kandidat awal.")
    }
}
