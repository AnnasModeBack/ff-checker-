# iOS Companion Module Notes

- Sistem operasi iOS menerapkan sandboxing ketat sehingga **tidak mendukung** system-wide floating bubble overlay di atas aplikasi pihak ketiga maupun auto-click lintas aplikasi seperti Android `AccessibilityService`.
- Struktur `ios_companion/` di dalam arsip proyek ini disiapkan secara terpisah dan non-intrusif agar tidak mengganggu proses kompilasi Gradle Android (`./gradlew assembleDebug assembleRelease`).
