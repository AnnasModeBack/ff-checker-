package com.annas.aifloatingsolver

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.annas.aifloatingsolver.ai.McqSolverEngine

class GeminiChatActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var tvHistory: TextView
    private lateinit var scrollHistory: ScrollView
    private lateinit var etPrompt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gemini_chat)

        prefs = PrefsManager(this)
        tvHistory = findViewById(R.id.tvChatHistory)
        scrollHistory = findViewById(R.id.scrollChatHistory)
        etPrompt = findViewById(R.id.etChatPrompt)

        findViewById<Button>(R.id.btnChatChromeSearch).setOnClickListener {
            val q = etPrompt.text.toString().trim()
            ChromeSearchHelper.searchInChrome(this, q)
        }

        findViewById<Button>(R.id.btnSendChat).setOnClickListener {
            val userMsg = etPrompt.text.toString().trim()
            if (userMsg.isEmpty()) return@setOnClickListener
            etPrompt.setText("")
            appendMessage("Kamu: $userMsg")
            appendMessage("AI Gemini: Sedang berpikir...")

            val currentKey = prefs.apiKey
            Thread {
                val reply = McqSolverEngine.askGeminiDirect(currentKey, userMsg)
                runOnUiThread {
                    val existing = tvHistory.text.toString().removeSuffix("\n\nAI Gemini: Sedang berpikir...")
                    tvHistory.text = existing
                    appendMessage("AI Gemini: $reply")
                }
            }.start()
        }
    }

    private fun appendMessage(line: String) {
        val cur = tvHistory.text.toString()
        tvHistory.text = if (cur.isBlank()) line else "$cur\n\n$line"
        scrollHistory.post { scrollHistory.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
