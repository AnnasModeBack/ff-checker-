package com.annas.aifloatingsolver.service

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.annas.aifloatingsolver.PrefsManager
import com.annas.aifloatingsolver.ai.McqSolverEngine
import java.security.MessageDigest

class QuizSolverAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: QuizSolverAccessibilityService? = null

        @Volatile
        var lastCollectedScreenText: String = ""

        private val processedQuestionHashes = LinkedHashSet<String>()
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isSolvingNow = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = PrefsManager(this)
        if (!prefs.isMasterEnabled) return
    }

    override fun onInterrupt() {
        isSolvingNow = false
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
        isSolvingNow = false
    }

    fun resetProcessedQuestions() {
        synchronized(processedQuestionHashes) {
            processedQuestionHashes.clear()
        }
    }

    fun solveCurrentScreenQuestion(
        allowDuplicate: Boolean = false,
        onResult: (statusMessage: String, recommendedLetter: String) -> Unit
    ) {
        if (isSolvingNow) {
            onResult("Sedang memproses soal sebelumnya...", "-")
            return
        }
        val root = rootInActiveWindow
        if (root == null) {
            onResult("Tidak dapat membaca layar aktif. Pastikan layar soal terbuka.", "-")
            return
        }

        val collected = mutableListOf<Pair<String, AccessibilityNodeInfo>>()
        collectNodes(root, collected)
        val screenText = collected.map { it.first }.filter { it.isNotBlank() }.joinToString("\n")
        if (screenText.isNotBlank()) {
            lastCollectedScreenText = screenText
        }

        if (screenText.isBlank()) {
            onResult("Teks soal di layar kosong atau tidak terdeteksi.", "-")
            return
        }

        val qHash = sha256(screenText.take(600))
        synchronized(processedQuestionHashes) {
            if (!allowDuplicate && processedQuestionHashes.contains(qHash)) {
                onResult("Soal ini sudah dikerjakan (Anti-Duplikasi aktif).", "-")
                return
            }
            processedQuestionHashes.add(qHash)
        }

        isSolvingNow = true
        val prefs = PrefsManager(this)

        Thread {
            val (letter, reason) = McqSolverEngine.solveMcq(
                apiKey = prefs.apiKey,
                subject = prefs.subject,
                questionAndOptionsText = screenText
            )

            val delayMs = (prefs.delaySeconds * 1000f).toLong().coerceAtLeast(800L)
            mainHandler.postDelayed({
                var clicked = false
                if (prefs.autoClickEnabled) {
                    clicked = clickOptionNode(collected, letter)
                }
                isSolvingNow = false
                val actionMsg = when {
                    !prefs.autoClickEnabled -> "Mode rekomendasi saja (Auto-Klik OFF)."
                    clicked -> "Berhasil klik otomatis opsi $letter."
                    else -> "Klik otomatis dibatasi tampilan; gunakan rekomendasi $letter."
                }
                onResult("$actionMsg $reason", letter)
            }, delayMs)
        }.start()
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<Pair<String, AccessibilityNodeInfo>>) {
        if (node == null) return
        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        val combined = if (text.isNotEmpty()) text else desc
        if (combined.isNotEmpty() && combined != "AIF" && !combined.startsWith("AI FLOATING PANEL")) {
            out.add(Pair(combined, node))
        }
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out)
        }
    }

    private fun clickOptionNode(nodes: List<Pair<String, AccessibilityNodeInfo>>, targetLetter: String): Boolean {
        val upper = targetLetter.uppercase()
        val patterns = listOf(
            Regex("^$upper\\b.*", RegexOption.IGNORE_CASE),
            Regex("^$upper[\\).:\\-]\\s*.*", RegexOption.IGNORE_CASE),
            Regex(".*\\bOpsi\\s+$upper\\b.*", RegexOption.IGNORE_CASE)
        )
        for ((label, node) in nodes) {
            val matches = patterns.any { it.matches(label) }
            if (matches) {
                var current: AccessibilityNodeInfo? = node
                while (current != null) {
                    if (current.isClickable) {
                        return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    current = current.parent
                }
            }
        }
        return false
    }

    private fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
