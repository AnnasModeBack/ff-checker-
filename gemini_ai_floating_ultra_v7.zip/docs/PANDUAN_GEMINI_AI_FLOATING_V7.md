# Gemini AI Floating v7 (Full Project + Build Gemini AI Floating APK)

## Nama Workflow & File Build
- File workflow berada di `.github/workflows/build-gemini-ai-floating-apk.yml` dengan nama **Build Gemini AI Floating APK**.
- Menghasilkan artifact bernama **Gemini-AI-Floating-APK** berisi `Gemini-AI-Floating-v7-Debug.apk` (siap langsung install di HP) dan `Gemini-AI-Floating-v7-Release-Unsigned.apk`.

## Peningkatan Terbaru di v7
1. **Tombol Tes Koneksi API**: Cek validitas API Key Gemini langsung dari layar utama sebelum mulai menggunakan panel floating.
2. **System Instruction Presisi & Temperature 0.25**: Jawaban Gemini AI lebih fokus, akurat, dan tidak bertele-tele untuk soal pilihan ganda, hitungan, maupun terjemahan.
3. **Tombol Salin Jawaban 1-Ketuk**: Setiap balasan Gemini di bubble chat dilengkapi tombol **Salin Jawaban** instan selain tekan-lama.
4. **Dukungan Tanpa API Key via Gemini Web**: Jika tidak memakai API Key, tombol **Gemini Web** langsung membuka `https://gemini.google.com/app` dan otomatis menempelkan teks yang ditandai.
