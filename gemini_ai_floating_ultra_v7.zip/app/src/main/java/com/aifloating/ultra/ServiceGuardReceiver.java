package com.aifloating.ultra;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ServiceGuardReceiver extends BroadcastReceiver {

    public static final String ACTION_RESTART_SERVICE = "com.aifloating.ultra.ACTION_RESTART_SERVICE";

    @Override
    public void onReceive(Context context, Intent intent) {
        UltraPreferences prefs = new UltraPreferences(context);
        if (prefs.isFloatingEnabled() && prefs.isAutoReviveEnabled()) {
            UltraAiApp.ensureServiceRunning(context, true);
        }
    }
}
