package com.aifloating.ultra;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.multidex.MultiDexApplication;

public class UltraAiApp extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                UltraPreferences prefs = new UltraPreferences(getApplicationContext());
                if (prefs.isFloatingEnabled()) {
                    Intent revive = new Intent(getApplicationContext(), ServiceGuardReceiver.class);
                    revive.setAction(ServiceGuardReceiver.ACTION_RESTART_SERVICE);
                    sendBroadcast(revive);
                }
            } catch (Exception ignored) {
            }
            if (defaultHandler != null) {
                defaultHandler.uncaughtException(thread, throwable);
            }
        });
    }

    public static void ensureServiceRunning(Context ctx, boolean forceStart) {
        UltraPreferences prefs = new UltraPreferences(ctx);
        if (!forceStart && !prefs.isFloatingEnabled()) return;
        if (!UltraOverlayHelper.hasOverlayPermission(ctx)) return;

        Intent svc = new Intent(ctx, UltraFloatingService.class);
        svc.setAction(UltraFloatingService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(svc);
            } else {
                ctx.startService(svc);
            }
        } catch (Exception ignored) {
        }
    }
}
