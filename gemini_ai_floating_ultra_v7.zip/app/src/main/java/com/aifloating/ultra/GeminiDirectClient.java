package com.aifloating.ultra;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiDirectClient {

    public interface ResponseCallback {
        void onResult(String reply);
        void onError(String reason);
    }

    public static class Turn {
        public final String role;
        public final String content;

        public Turn(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    private static final ExecutorService POOL = Executors.newCachedThreadPool();
    private final UltraPreferences prefs;
    private long lastSentAt = 0L;

    public GeminiDirectClient(UltraPreferences prefs) {
        this.prefs = prefs;
    }

    public void testApiKey(String candidateKey, ResponseCallback cb) {
        String cleanKey = candidateKey == null ? "" : candidateKey.trim();
        if (cleanKey.isEmpty()) {
            cb.onError("API Key kosong. Tempel kunci dari Google AI Studio (AIza...).");
            return;
        }
        POOL.execute(() -> {
            CallOutcome out = callGeminiOnce(cleanKey, prefs.getModel(), "Balas hanya dengan kata: TERHUBUNG", null, true);
            if (out.success) {
                cb.onResult("Koneksi Gemini API Valid (" + prefs.getModel() + "): " + out.text);
            } else {
                cb.onError("Tes Gagal (" + out.httpCode + "): " + out.error);
            }
        });
    }

    public void ask(String prompt, List<Turn> history, boolean stealth, ResponseCallback cb) {
        long now = System.currentTimeMillis();
        if (now - lastSentAt < 500L) {
            cb.onError("Tunggu sebentar sebelum mengirim pertanyaan berikutnya.");
            return;
        }
        lastSentAt = now;

        String clean = UltraPreferences.sanitize(prompt);
        if (clean.isEmpty()) {
            cb.onError("Pertanyaan atau teks yang ditandai masih kosong.");
            return;
        }

        final String apiKey = prefs.getGeminiApiKey();
        if (apiKey == null || apiKey.trim().isEmpty()) {
            cb.onError("API Key Gemini belum diisi. Masukkan API Key di menu utama atau tekan 'Gemini Web' untuk pakai tanpa API Key.");
            return;
        }

        final String primaryModel = prefs.getModel();

        POOL.execute(() -> {
            Set<String> modelsToTry = new LinkedHashSet<>(Arrays.asList(
                    primaryModel,
                    "gemini-2.5-flash",
                    "gemini-2.0-flash",
                    "gemini-1.5-flash"
            ));

            String lastError = "Gagal terhubung ke Gemini API.";
            for (String model : modelsToTry) {
                for (int attempt = 0; attempt < 2; attempt++) {
                    CallOutcome outcome = callGeminiOnce(apiKey.trim(), model, clean, history, stealth);
                    if (outcome.success) {
                        cb.onResult(outcome.text);
                        return;
                    }
                    lastError = outcome.error;
                    if (outcome.httpCode == 400 || outcome.httpCode == 401 || outcome.httpCode == 403) {
                        cb.onError("API Key ditolak (" + outcome.httpCode + "): " + outcome.error);
                        return;
                    }
                    try {
                        Thread.sleep(400L);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
            cb.onError(lastError);
        });
    }

    private static class CallOutcome {
        final boolean success;
        final int httpCode;
        final String text;
        final String error;

        CallOutcome(boolean success, int httpCode, String text, String error) {
            this.success = success;
            this.httpCode = httpCode;
            this.text = text;
            this.error = error;
        }
    }

    private CallOutcome callGeminiOnce(String apiKey, String model, String prompt, List<Turn> history, boolean stealth) {
        HttpURLConnection conn = null;
        try {
            String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/"
                    + URLEncoder.encode(model, "UTF-8")
                    + ":generateContent?key="
                    + URLEncoder.encode(apiKey, "UTF-8");

            URL url = new URL(endpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(35000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Accept", "application/json");

            JSONObject sysInst = new JSONObject();
            JSONArray sysParts = new JSONArray();
            JSONObject sysText = new JSONObject();
            sysText.put("text", stealth
                    ? "Kamu adalah asisten Gemini AI yang sangat akurat. Berikan jawaban langsung, tepat, dan ringkas dalam Bahasa Indonesia."
                    : "Kamu adalah asisten Gemini AI yang cerdas dan presisi. Jika diberi soal pilihan ganda atau hitungan, berikan jawaban akhir yang jelas beserta penjelasan singkat.");
            sysParts.put(sysText);
            sysInst.put("parts", sysParts);

            JSONArray contents = new JSONArray();
            if (history != null) {
                int start = Math.max(0, history.size() - 8);
                for (int i = start; i < history.size(); i++) {
                    Turn t = history.get(i);
                    JSONObject turnObj = new JSONObject();
                    turnObj.put("role", "model".equals(t.role) ? "model" : "user");
                    JSONArray parts = new JSONArray();
                    JSONObject partText = new JSONObject();
                    partText.put("text", UltraPreferences.sanitize(t.content));
                    parts.put(partText);
                    turnObj.put("parts", parts);
                    contents.put(turnObj);
                }
            }

            JSONObject userTurn = new JSONObject();
            userTurn.put("role", "user");
            JSONArray userParts = new JSONArray();
            JSONObject userTextObj = new JSONObject();
            userTextObj.put("text", UltraPreferences.sanitize(prompt));
            userParts.put(userTextObj);
            userTurn.put("parts", userParts);
            contents.put(userTurn);

            JSONObject genCfg = new JSONObject();
            genCfg.put("temperature", 0.25);

            JSONObject rootBody = new JSONObject();
            rootBody.put("systemInstruction", sysInst);
            rootBody.put("contents", contents);
            rootBody.put("generationConfig", genCfg);

            byte[] payload = rootBody.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload);
                os.flush();
            }

            int code = conn.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            String raw = readAll(is);

            if (code < 200 || code >= 300) {
                return new CallOutcome(false, code, "", extractApiError(raw, code));
            }

            String answer = extractCandidateText(raw);
            if (answer.isEmpty()) {
                return new CallOutcome(false, code, "", "Respons Gemini kosong.");
            }
            return new CallOutcome(true, code, answer.trim(), "");
        } catch (Exception e) {
            return new CallOutcome(false, 0, "", "Jaringan bermasalah: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String extractCandidateText(String rawJson) {
        try {
            JSONObject obj = new JSONObject(rawJson);
            JSONArray cands = obj.optJSONArray("candidates");
            if (cands != null && cands.length() > 0) {
                JSONObject first = cands.optJSONObject(0);
                JSONObject content = first != null ? first.optJSONObject("content") : null;
                JSONArray parts = content != null ? content.optJSONArray("parts") : null;
                if (parts != null && parts.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < parts.length(); i++) {
                        String t = parts.optJSONObject(i).optString("text", "");
                        if (!t.isEmpty()) sb.append(t);
                    }
                    return sb.toString();
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static String extractApiError(String rawJson, int code) {
        try {
            JSONObject obj = new JSONObject(rawJson);
            JSONObject err = obj.optJSONObject("error");
            if (err != null) {
                return err.optString("message", "HTTP " + code);
            }
        } catch (Exception ignored) {
        }
        String clean = rawJson == null ? "" : rawJson.trim();
        return clean.isEmpty() ? ("HTTP " + code) : (clean.length() > 140 ? clean.substring(0, 140) + "..." : clean);
    }

    private static String readAll(InputStream is) {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Exception ignored) {
        }
        return sb.toString();
    }
}
