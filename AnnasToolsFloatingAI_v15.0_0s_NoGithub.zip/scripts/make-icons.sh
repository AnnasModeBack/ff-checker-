#!/usr/bin/env bash
set -e
python3 -c "import os; from PIL import Image; src='app/src/main/assets/icon.jpg'; res='app/src/main/res'; sizes={'mipmap-mdpi':48,'mipmap-hdpi':72,'mipmap-xhdpi':96,'mipmap-xxhdpi':144,'mipmap-xxxhdpi':192}; im=Image.open(src).convert('RGBA') if os.path.exists(src) else None; [ (os.makedirs(os.path.join(res,f),exist_ok=True), im.resize((px,px),Image.Resampling.LANCZOS).save(os.path.join(res,f,'ic_launcher.png'),'PNG'), im.resize((px,px),Image.Resampling.LANCZOS).save(os.path.join(res,f,'ic_launcher_round.png'),'PNG')) for f,px in sizes.items() if im ]"
