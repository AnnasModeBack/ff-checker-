package com.annas.aifloatingsolver

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.annas.aifloatingsolver.service.FloatingBubbleService
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var switchMaster: SwitchMaterial
    private lateinit var tvMasterStatus: TextView
    private lateinit var tvPermOverlay: TextView
    private lateinit var tvPermAccessibility: TextView
    private lateinit var tvPermNotification: TextView
    private lateinit var spinnerSubject: Spinner
    private lateinit var etApiKey: EditText
    private lateinit var etDelaySec: EditText
    private lateinit var cbAutoClick: CheckBox

    private val subjects = listOf(
        "Semua Mata Pelajaran",
        "Matematika",
        "Bahasa Indonesia",
        "Bahasa Inggris",
        "PKN",
        "Sejarah / Sosiologi",
        "IPA / IPS",
        "Kejuruan / Pemrograman"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsManager(this)
        bindViews()
        setupSubjectSpinner()
        loadSavedConfig()
        setupListeners()
        refreshPermissionAndMasterUi()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionAndMasterUi()
    }

    private fun bindViews() {
        switchMaster = findViewById(R.id.switchMaster)
        tvMasterStatus = findViewById(R.id.tvMasterStatus)
        tvPermOverlay = findViewById(R.id.tvPermOverlay)
        tvPermAccessibility = findViewById(R.id.tvPermAccessibility)
        tvPermNotification = findViewById(R.id.tvPermNotification)
        spinnerSubject = findViewById(R.id.spinnerSubject)
        etApiKey = findViewById(R.id.etApiKey)
        etDelaySec = findViewById(R.id.etDelaySec)
        cbAutoClick = findViewById(R.id.cbAutoClick)
    }

    private fun setupSubjectSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, subjects)
        spinnerSubject.adapter = adapter
    }

    private fun loadSavedConfig() {
        val idx = subjects.indexOf(prefs.subject).coerceAtLeast(0)
        spinnerSubject.setSelection(idx)
        etApiKey.setText(prefs.apiKey)
        etDelaySec.setText(prefs.delaySeconds.toString())
        cbAutoClick.isChecked = prefs.autoClickEnabled
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.btnOemGuide).setOnClickListener {
            startActivity(Intent(this, OemGuideActivity::class.java))
        }

        findViewById<Button>(R.id.btnOpenGeminiChat).setOnClickListener {
            startActivity(Intent(this, GeminiChatActivity::class.java))
        }

        findViewById<Button>(R.id.btnSearchChrome).setOnClickListener {
            val q = spinnerSubject.selectedItem?.toString() ?: "materi pelajaran"
            ChromeSearchHelper.searchInChrome(this, "$q belajar soal")
        }

        switchMaster.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!hasOverlayPermission()) {
                    switchMaster.isChecked = false
                    showPermissionGuideDialog(
                        title = "Izin Tampil di Atas Aplikasi Lain Diperlukan",
                        detail = "Agar ikon bulat melayang (bubble) dan panel soal dapat muncul di layar:\n" +
                            "• Jalur Umum: Pengaturan > Aplikasi > AI Floating Solver > Tampilkan di atas aplikasi lain.\n" +
                            "• OPPO/ColorOS: Pengaturan > Manajemen aplikasi > AI Floating Solver > Tampilkan di atas aplikasi lain.\n" +
                            "• Xiaomi/HyperOS: Pengaturan > Aplikasi > Kelola aplikasi > AI Floating Solver > Izin lainnya > Tampilkan jendela pop-up.\n" +
                            "• Samsung/Vivo/Realme/Infinix: Pengaturan > Aplikasi > Akses khusus > Muncul di atas aplikasi lain.",
                        onOpenSettings = { openOverlaySettings() }
                    )
                    return@setOnCheckedChangeListener
                }
                if (!isAccessibilityEnabled()) {
                    switchMaster.isChecked = false
                    showPermissionGuideDialog(
                        title = "Izin Aksesibilitas Diperlukan",
                        detail = "Agar aplikasi dapat membaca teks soal pilihan ganda dan melakukan klik otomatis bila diizinkan:\n" +
                            "• Jalur Umum: Pengaturan > Aksesibilitas > Aplikasi terunduh / Terinstal > AI Floating Solver > Aktifkan.\n" +
                            "• Catatan Android 13+ / Setelan Terbatas: Jika tombol aktif terkunci/abu-abu, buka Info Aplikasi > menu titik tiga (⋮) > Izinkan setelan terbatas, lalu aktifkan di Aksesibilitas.",
                        onOpenSettings = { openAccessibilitySettings() }
                    )
                    return@setOnCheckedChangeListener
                }
                prefs.isMasterEnabled = true
                prefs.isBubbleVisible = true
                val intent = Intent(this, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_START
                }
                ContextCompat.startForegroundService(this, intent)
            } else {
                prefs.isMasterEnabled = false
                val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_STOP
                }
                startService(stopIntent)
            }
            refreshPermissionAndMasterUi()
        }

        findViewById<Button>(R.id.btnShowBubble).setOnClickListener {
            if (!hasOverlayPermission()) {
                showPermissionGuideDialog(
                    title = "Izin Overlay Belum Aktif",
                    detail = "Aktifkan izin 'Tampilkan di atas aplikasi lain' terlebih dahulu di Pengaturan HP.",
                    onOpenSettings = { openOverlaySettings() }
                )
                return@setOnClickListener
            }
            prefs.isMasterEnabled = true
            prefs.isBubbleVisible = true
            val intent = Intent(this, FloatingBubbleService::class.java).apply {
                action = FloatingBubbleService.ACTION_SHOW_BUBBLE
            }
            ContextCompat.startForegroundService(this, intent)
            refreshPermissionAndMasterUi()
        }

        findViewById<Button>(R.id.btnHideBubble).setOnClickListener {
            prefs.isBubbleVisible = false
            val intent = Intent(this, FloatingBubbleService::class.java).apply {
                action = FloatingBubbleService.ACTION_HIDE_BUBBLE
            }
            startService(intent)
            Toast.makeText(this, "Bubble disembunyikan", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            showPermissionGuideDialog(
                title = "Panduan Izin Overlay (Tampil di Atas Aplikasi Lain)",
                detail = "• Jalur Umum: Pengaturan > Aplikasi > AI Floating Solver > Tampilkan di atas aplikasi lain.\n" +
                    "• OPPO/ColorOS: Pengaturan > Aplikasi > Manajemen aplikasi > AI Floating Solver > Tampilkan di atas aplikasi lain.\n" +
                    "• Xiaomi/MIUI/HyperOS: Pengaturan > Aplikasi > Izin lainnya > Tampilkan jendela pop-up.\n" +
                    "• Samsung One UI: Pengaturan > Aplikasi > menu (⋮) > Akses khusus > Muncul di atas aplikasi lain.",
                onOpenSettings = { openOverlaySettings() }
            )
        }

        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            showPermissionGuideDialog(
                title = "Panduan Izin Aksesibilitas & Setelan Terbatas",
                detail = "• Jalur Umum: Pengaturan > Aksesibilitas > AI Floating Solver > Aktifkan.\n" +
                    "• OPPO / Realme / Vivo / Infinix / Samsung: Cari menu Aksesibilitas > Aplikasi terunduh / Layanan terinstal > AI Floating Solver.\n" +
                    "• Jika muncul peringatan 'Setelan terbatas' (Android 13+): Buka Pengaturan > Aplikasi > AI Floating Solver > klik titik tiga (⋮) pojok kanan atas > pilih 'Izinkan setelan terbatas', lalu kembali ke Aksesibilitas.",
                onOpenSettings = { openAccessibilitySettings() }
            )
        }

        findViewById<Button>(R.id.btnGrantNotification).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    201
                )
            } else {
                openAppDetailSettings()
            }
        }

        findViewById<Button>(R.id.btnSaveConfig).setOnClickListener {
            prefs.subject = spinnerSubject.selectedItem?.toString() ?: "Semua Mata Pelajaran"
            val inputKey = etApiKey.text.toString().trim()
            prefs.apiKey = if (inputKey.isEmpty()) PrefsManager.DEFAULT_GEMINI_KEY else inputKey
            etApiKey.setText(prefs.apiKey)
            val delayVal = etDelaySec.text.toString().toFloatOrNull() ?: 2.5f
            prefs.delaySeconds = delayVal
            prefs.autoClickEnabled = cbAutoClick.isChecked
            Toast.makeText(this, "Pengaturan & Token Gemini disimpan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshPermissionAndMasterUi() {
        val overlayOk = hasOverlayPermission()
        val accOk = isAccessibilityEnabled()
        val notifOk = hasNotificationPermission()

        tvPermOverlay.text = if (overlayOk) "Aktif ✓" else "Belum Aktif"
        tvPermOverlay.setTextColor(getColor(if (overlayOk) R.color.neon_emerald else R.color.neon_coral))

        tvPermAccessibility.text = if (accOk) "Aktif ✓" else "Belum Aktif"
        tvPermAccessibility.setTextColor(getColor(if (accOk) R.color.neon_emerald else R.color.neon_coral))

        tvPermNotification.text = if (notifOk) "Aktif ✓" else "Belum Aktif"
        tvPermNotification.setTextColor(getColor(if (notifOk) R.color.neon_emerald else R.color.neon_amber))

        val active = prefs.isMasterEnabled && overlayOk
        switchMaster.setOnCheckedChangeListener(null)
        switchMaster.isChecked = active
        setupListeners()

        if (active) {
            tvMasterStatus.text = "STATUS: ON — Layanan & Bubble Aktif"
            tvMasterStatus.setTextColor(getColor(R.color.neon_emerald))
        } else {
            tvMasterStatus.text = "STATUS: OFF — Layanan & Bubble Nonaktif"
            tvMasterStatus.setTextColor(getColor(R.color.neon_coral))
        }
    }

    private fun showPermissionGuideDialog(
        title: String,
        detail: String,
        onOpenSettings: () -> Unit
    ) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(detail)
            .setPositiveButton("Buka Pengaturan HP") { _, _ -> onOpenSettings() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val expected = "$packageName/${com.annas.aifloatingsolver.service.QuizSolverAccessibilityService::class.java.name}"
        return enabledServices.contains(expected, ignoreCase = true) || am.isEnabled
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun openOverlaySettings() {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Exception) {
            openAppDetailSettings()
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Exception) {
            openAppDetailSettings()
        }
    }

    private fun openAppDetailSettings() {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }
}
