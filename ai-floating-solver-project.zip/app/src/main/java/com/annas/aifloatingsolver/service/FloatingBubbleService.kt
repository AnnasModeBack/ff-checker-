package com.annas.aifloatingsolver.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.annas.aifloatingsolver.ChromeSearchHelper
import com.annas.aifloatingsolver.GeminiChatActivity
import com.annas.aifloatingsolver.MainActivity
import com.annas.aifloatingsolver.PrefsManager
import com.annas.aifloatingsolver.R
import kotlin.math.abs

class FloatingBubbleService : Service() {

    companion object {
        const val ACTION_START = "com.annas.aifloatingsolver.action.START"
        const val ACTION_STOP = "com.annas.aifloatingsolver.action.STOP"
        const val ACTION_SHOW_BUBBLE = "com.annas.aifloatingsolver.action.SHOW_BUBBLE"
        const val ACTION_HIDE_BUBBLE = "com.annas.aifloatingsolver.action.HIDE_BUBBLE"
        private const val NOTIF_ID = 1001
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PrefsManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var isAutoSequenceRunning = false
    private val seqHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = PrefsManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAllFloatingViews()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_BUBBLE -> {
                prefs.isMasterEnabled = true
                prefs.isBubbleVisible = true
                startForeground(NOTIF_ID, buildNotification())
                attachBubbleIfNeeded()
                bubbleView?.visibility = View.VISIBLE
            }
            ACTION_HIDE_BUBBLE -> {
                prefs.isBubbleVisible = false
                bubbleView?.visibility = View.GONE
                removePanel()
            }
            else -> {
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                prefs.isMasterEnabled = true
                startForeground(NOTIF_ID, buildNotification())
                if (prefs.isBubbleVisible) {
                    attachBubbleIfNeeded()
                    bubbleView?.visibility = View.VISIBLE
                } else {
                    attachBubbleIfNeeded()
                    bubbleView?.visibility = View.GONE
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAllFloatingViews()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun stopAllFloatingViews() {
        isAutoSequenceRunning = false
        seqHandler.removeCallbacksAndMessages(null)
        removePanel()
        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleView = null
    }

    private fun removePanel() {
        panelView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        panelView = null
    }

    private fun attachBubbleIfNeeded() {
        if (bubbleView != null) return
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 32
            y = 260
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        moved = true
                    }
                    params.x = (initialX + dx).coerceAtLeast(0)
                    params.y = (initialY + dy).coerceAtLeast(0)
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleParams = params
        bubbleView = view
        windowManager.addView(view, params)
    }

    private fun togglePanel() {
        if (panelView != null) {
            removePanel()
            return
        }
        val inflater = LayoutInflater.from(this)
        val pView = inflater.inflate(R.layout.floating_panel, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 64
            y = 140
        }

        val tvSubject = pView.findViewById<TextView>(R.id.tvPanelSubject)
        val tvStatus = pView.findViewById<TextView>(R.id.tvPanelStatus)
        val tvRec = pView.findViewById<TextView>(R.id.tvPanelRecommendation)
        val btnHide = pView.findViewById<Button>(R.id.btnPanelHideBubble)
        val btnClose = pView.findViewById<Button>(R.id.btnPanelClose)
        val btnScanOne = pView.findViewById<Button>(R.id.btnScanOne)
        val btnAutoSeq = pView.findViewById<Button>(R.id.btnAutoSeq)
        val btnChatAi = pView.findViewById<Button>(R.id.btnPanelChatAi)
        val btnChrome = pView.findViewById<Button>(R.id.btnPanelChrome)
        val btnReset = pView.findViewById<Button>(R.id.btnResetSeen)

        tvSubject.text = "Mapel: ${prefs.subject}"

        btnHide.setOnClickListener {
            prefs.isBubbleVisible = false
            bubbleView?.visibility = View.GONE
            removePanel()
        }

        btnClose.setOnClickListener {
            removePanel()
        }

        btnChatAi.setOnClickListener {
            removePanel()
            val chatIntent = Intent(this, GeminiChatActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(chatIntent)
        }

        btnChrome.setOnClickListener {
            removePanel()
            val snippet = QuizSolverAccessibilityService.lastCollectedScreenText
                .lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(3)
                .joinToString(" ")
                .take(160)
            ChromeSearchHelper.searchInChrome(this, snippet)
        }

        btnReset.setOnClickListener {
            QuizSolverAccessibilityService.instance?.resetProcessedQuestions()
            tvStatus.text = "Riwayat soal direset. Semua soal bisa dipindai ulang."
        }

        btnScanOne.setOnClickListener {
            val acc = QuizSolverAccessibilityService.instance
            if (acc == null) {
                tvStatus.text = "Aktifkan izin Aksesibilitas di aplikasi utama dahulu."
                return@setOnClickListener
            }
            tvStatus.text = "Membaca soal pilihan ganda..."
            acc.solveCurrentScreenQuestion { status, letter ->
                tvStatus.text = status
                tvRec.text = "Jawaban Rekomendasi: $letter"
            }
        }

        btnAutoSeq.setOnClickListener {
            isAutoSequenceRunning = !isAutoSequenceRunning
            if (isAutoSequenceRunning) {
                btnAutoSeq.text = "Stop Auto"
                tvStatus.text = "Mode berurutan aktif (satu per satu)."
                runSequentialLoop(tvStatus, tvRec)
            } else {
                btnAutoSeq.text = "Auto Berurutan"
                seqHandler.removeCallbacksAndMessages(null)
                tvStatus.text = "Mode berurutan dihentikan."
            }
        }

        panelView = pView
        windowManager.addView(pView, params)
    }

    private fun runSequentialLoop(tvStatus: TextView, tvRec: TextView) {
        if (!isAutoSequenceRunning) return
        val acc = QuizSolverAccessibilityService.instance
        if (acc == null) {
            isAutoSequenceRunning = false
            tvStatus.text = "Layanan Aksesibilitas belum aktif."
            return
        }
        acc.solveCurrentScreenQuestion { status, letter ->
            tvStatus.text = status
            tvRec.text = "Jawaban Rekomendasi: $letter"
            if (isAutoSequenceRunning) {
                val stepDelay = ((prefs.delaySeconds + 1.5f) * 1000f).toLong().coerceAtLeast(1800L)
                seqHandler.postDelayed({ runSequentialLoop(tvStatus, tvRec) }, stepDelay)
            }
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showBubbleIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = ACTION_SHOW_BUBBLE
        }
        val pendingShow = PendingIntent.getService(
            this, 1, showBubbleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hideBubbleIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = ACTION_HIDE_BUBBLE
        }
        val pendingHide = PendingIntent.getService(
            this, 2, hideBubbleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setContentTitle("AI Floating Solver Aktif")
            .setContentText("Ketuk untuk membuka aplikasi atau atur bubble.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(0, "Munculkan Bubble", pendingShow)
            .addAction(0, "Sembunyikan", pendingHide)
            .build()
    }
}
