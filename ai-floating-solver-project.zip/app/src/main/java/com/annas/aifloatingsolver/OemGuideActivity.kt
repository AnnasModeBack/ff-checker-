package com.annas.aifloatingsolver

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OemGuideActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_oem_guide)

        val guideText = """
            1. KOMPATIBILITAS MEREK & VERSI ANDROID
            • OPPO / ColorOS: Aktifkan 'Tampilkan di atas aplikasi lain', matikan optimasi baterai agresif, dan buka 'Izinkan setelan terbatas' di Info Aplikasi bila diperlukan.
            • Samsung / One UI: Buka Pengaturan > Aplikasi > Akses khusus > Muncul di atas aplikasi lain serta Aksesibilitas > Aplikasi terinstal.
            • Xiaomi / MIUI / HyperOS: Aktifkan 'Tampilkan jendela pop-up' dan 'Mulai otomatis', serta buka Setelan Terbatas bila dikunci sistem.
            • Vivo / Realme / Infinix: Izinkan overlay, notifikasi, dan layanan aksesibilitas agar bubble dan pembacaan soal berjalan mulus.

            2. FITUR CHAT AI GEMINI & SEARCHING CHROME
            • Endpoint: gemini-flash-latest menggunakan header X-goog-api-key dengan token default yang sudah dikonfigurasi dan bisa diubah kapan saja.
            • Tombol Searching Chrome membuka pencarian langsung di Google Chrome (dengan fallback ke browser/pencarian web bawaan).

            3. CATATAN LINTAS PLATFORM (IP / iOS)
            • iOS memblokir sistem overlay mengambang global (SYSTEM_ALERT_WINDOW) lintas aplikasi pihak ketiga serta membatasi akses baca/klik otomatis layar aplikasi lain demi sandboxing keamanan Apple.
            • Modul pendamping pada paket 'ios_companion/' disiapkan untuk arsitektur lintas platform/pendamping iOS.
        """.trimIndent()

        findViewById<TextView>(R.id.tvOemGuideContent).text = guideText
    }
}
