package com.annas.aifloatingsolver

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

object ChromeSearchHelper {
    fun searchInChrome(context: Context, query: String) {
        val cleanQuery = query.trim().ifEmpty { "bantuan belajar soal pilihan ganda" }
        val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
        val searchUrl = "https://www.google.com/search?q=$encoded"

        // 1. Coba buka langsung di Google Chrome
        try {
            val chromeIntent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                setPackage("com.android.chrome")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chromeIntent)
            return
        } catch (_: Exception) {
        }

        // 2. Fallback ke intent pencarian web / browser bawaan
        try {
            val webSearchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, cleanQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webSearchIntent)
            return
        } catch (_: Exception) {
        }

        try {
            val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
            Toast.makeText(context, "Tidak dapat membuka browser/Chrome", Toast.LENGTH_SHORT).show()
        }
    }
}
