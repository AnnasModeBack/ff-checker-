# Annas Tools Floating AI Engine v10.0

- Package: com.annas.tools
- Android: minSdk 21 to targetSdk 35 (32-bit & 64-bit)
- GitHub Actions: Clean isolated SDK installation with ZIP integrity verification (`unzip -tq`), retry loop, and caching.
