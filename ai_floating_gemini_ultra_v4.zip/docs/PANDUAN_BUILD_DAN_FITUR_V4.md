# AI Floating Gemini Ultra v4 (Full SVG + GitHub Actions Build APK)

## Fitur Utama
1. **GitHub Actions Build APK Otomatis (`.github/workflows/build-apk.yml`)**:
   - Tinggal push seluruh isi ZIP ke repository GitHub, tab **Actions** akan otomatis mengompilasi `app-debug.apk` dan `app-release-unsigned.apk` yang bisa langsung diunduh dan diinstal di semua HP Android (`minSdk 23` – `targetSdk 35`).
2. **Adaptive Icon SVG & Custom SVG UI**:
   - Ikon aplikasi utama menggunakan Adaptive Vector Drawable (`ic_launcher_fg_svg.xml` + `ic_launcher_bg_svg.xml`) dengan gradasi cyber neon.
   - Kotak centang menggunakan custom SVG selector (`selector_svg_checkbox.xml` -> `ic_svg_checkbox_checked.xml` / `ic_svg_checkbox_unchecked.xml`) lengkap dengan animasi pop.
3. **Kotak Tandai Soal + Centang Langsung ke Gemini**:
   - Isi/tempel teks pada kotak `et_marked_prompt`, lalu centang `cb_marked_go_gemini` untuk langsung mengaktifkan Floating Gemini, mengirim teks ke Gemini Direct API tanpa proxy, dan membuka halaman Gemini.
4. **Mode Menyamar & Anti-Mati**:
   - Dilengkapi Mode Menyamar (label bubble & notifikasi berubah menjadi `SystemUI` dengan ikon perisai SVG), Panic Hide sudut atas, Watchdog 9 detik, WakeLock, dan Auto-Revive Receiver.
