package com.aifloating.ultra;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class UltraPreferences {

    private static final String PREF_NAME = "ultra_gemini_direct_secure_v4";

    private static final String KEY_FLOATING_ENABLED = "floating_enabled";
    private static final String KEY_AUTO_REVIVE = "auto_revive";
    private static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    private static final String KEY_MODEL = "gemini_model";
    private static final String KEY_STEALTH = "stealth_mode";
    private static final String KEY_STEALTH_NAME = "stealth_name";
    private static final String KEY_ALPHA = "bubble_alpha";
    private static final String KEY_PIN_HASH = "pin_hash";
    private static final String KEY_PIN_ENABLED = "pin_enabled";
    private static final String KEY_LAST_URL = "last_target_url";
    private static final String KEY_INITIAL_QUERY = "initial_marked_query";

    private final SharedPreferences prefs;

    public UltraPreferences(Context context) {
        this.prefs = createEncrypted(context.getApplicationContext());
    }

    private SharedPreferences createEncrypted(Context ctx) {
        try {
            MasterKey key = new MasterKey.Builder(ctx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            return EncryptedSharedPreferences.create(
                    ctx,
                    PREF_NAME,
                    key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            return ctx.getSharedPreferences(PREF_NAME + "_plain", Context.MODE_PRIVATE);
        }
    }

    public boolean isFloatingEnabled() {
        return prefs.getBoolean(KEY_FLOATING_ENABLED, false);
    }

    public void setFloatingEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_FLOATING_ENABLED, enabled).apply();
    }

    public boolean isAutoReviveEnabled() {
        return prefs.getBoolean(KEY_AUTO_REVIVE, true);
    }

    public void setAutoReviveEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_AUTO_REVIVE, enabled).apply();
    }

    public String getGeminiApiKey() {
        return prefs.getString(KEY_GEMINI_API_KEY, "");
    }

    public void setGeminiApiKey(String key) {
        prefs.edit().putString(KEY_GEMINI_API_KEY, key == null ? "" : key.trim()).apply();
    }

    public String getModel() {
        return prefs.getString(KEY_MODEL, "gemini-2.5-flash");
    }

    public void setModel(String model) {
        String m = (model == null || model.trim().isEmpty()) ? "gemini-2.5-flash" : model.trim();
        prefs.edit().putString(KEY_MODEL, m).apply();
    }

    public boolean isStealthMode() {
        return prefs.getBoolean(KEY_STEALTH, false);
    }

    public void setStealthMode(boolean stealth) {
        prefs.edit().putBoolean(KEY_STEALTH, stealth).apply();
    }

    public String getStealthName() {
        return prefs.getString(KEY_STEALTH_NAME, "SystemUI");
    }

    public void setStealthName(String name) {
        String s = (name == null || name.trim().isEmpty()) ? "SystemUI" : name.trim();
        if (s.length() > 14) s = s.substring(0, 14);
        prefs.edit().putString(KEY_STEALTH_NAME, s).apply();
    }

    public float getBubbleAlpha() {
        float a = prefs.getFloat(KEY_ALPHA, 0.94f);
        return Math.max(0.15f, Math.min(1.0f, a));
    }

    public void setBubbleAlpha(float alpha) {
        prefs.edit().putFloat(KEY_ALPHA, Math.max(0.15f, Math.min(1.0f, alpha))).apply();
    }

    public boolean isPinEnabled() {
        return prefs.getBoolean(KEY_PIN_ENABLED, false);
    }

    public void setPin(String pin) {
        if (pin == null || pin.trim().isEmpty()) {
            prefs.edit().remove(KEY_PIN_HASH).putBoolean(KEY_PIN_ENABLED, false).apply();
            return;
        }
        prefs.edit()
                .putString(KEY_PIN_HASH, sha256(pin.trim()))
                .putBoolean(KEY_PIN_ENABLED, true)
                .apply();
    }

    public boolean verifyPin(String pin) {
        String hash = prefs.getString(KEY_PIN_HASH, null);
        if (hash == null || !isPinEnabled()) return true;
        if (pin == null) return false;
        return hash.equals(sha256(pin.trim()));
    }

    public String getLastTargetUrl() {
        return prefs.getString(KEY_LAST_URL, "https://gemini.google.com/app");
    }

    public void setLastTargetUrl(String url) {
        prefs.edit().putString(KEY_LAST_URL, url == null ? "" : url.trim()).apply();
    }

    public String getInitialMarkedQuery() {
        return prefs.getString(KEY_INITIAL_QUERY, "");
    }

    public void setInitialMarkedQuery(String q) {
        prefs.edit().putString(KEY_INITIAL_QUERY, q == null ? "" : q.trim()).apply();
    }

    public static String sha256(String raw) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return Base64.encodeToString(raw.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        }
    }

    public static String sanitize(String text) {
        if (text == null) return "";
        String t = text.replaceAll("[\u0000-\u0008\u000B\u000C\u000E-\u001F]", "").trim();
        return t.length() > 6000 ? t.substring(0, 6000) : t;
    }
}
