package com.annas.aifloating.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenTextAccessibilityService : AccessibilityService() {

    data class ScreenTextBlock(
        val bounds: Rect,
        val text: String
    )

    companion object {
        @Volatile
        var instance: ScreenTextAccessibilityService? = null

        @Volatile
        private var cachedBlocks: List<ScreenTextBlock> = emptyList()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        captureCurrentScreenBlocks()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg != packageName) {
            captureCurrentScreenBlocks()
        }
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun captureCurrentScreenBlocks() {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() == packageName) return
        val list = ArrayList<ScreenTextBlock>()
        val seen = HashSet<String>()
        traverseNode(root, list, seen)
        if (list.isNotEmpty()) {
            cachedBlocks = list
        }
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo?,
        out: MutableList<ScreenTextBlock>,
        seen: MutableSet<String>
    ) {
        if (node == null) return
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val rawText = node.text?.toString()?.trim()
        val rawDesc = node.contentDescription?.toString()?.trim()
        val content = when {
            !rawText.isNullOrEmpty() -> rawText
            !rawDesc.isNullOrEmpty() -> rawDesc
            else -> ""
        }

        if (content.isNotEmpty() && bounds.width() > 0 && bounds.height() > 0) {
            val key = "${bounds.left}:${bounds.top}:${bounds.right}:${bounds.bottom}:$content"
            if (seen.add(key)) {
                out.add(ScreenTextBlock(Rect(bounds), content))
            }
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), out, seen)
        }
    }

    fun extractTextInsideRect(cropRect: Rect): String {
        captureCurrentScreenBlocks()

        val matched = cachedBlocks
            .filter { block ->
                val cx = block.bounds.centerX()
                val cy = block.bounds.centerY()
                cropRect.contains(cx, cy) || Rect.intersects(block.bounds, cropRect)
            }
            .sortedWith(compareBy({ it.bounds.top / 24 }, { it.bounds.left }))

        val uniqueLines = LinkedHashSet<String>()
        for (item in matched) {
            val clean = item.text.replace(Regex("\\s+"), " ").trim()
            if (clean.isNotEmpty()) {
                uniqueLines.add(clean)
            }
        }
        return uniqueLines.joinToString("
").trim()
    }
}
