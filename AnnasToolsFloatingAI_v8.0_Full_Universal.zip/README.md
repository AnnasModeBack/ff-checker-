# Annas Tools Floating AI Engine v8.0

## Struktur Proyek
- `app/src/main/AndroidManifest.xml`
- `app/src/main/assets/index.html`
- `app/src/main/assets/icon.jpg`
- `app/src/main/java/com/annas/tools/MainActivity.java`
- `app/src/main/java/com/annas/tools/FloatingAiService.java`
- `app/src/main/java/com/annas/tools/ScreenAutoService.java`
- `app/src/main/res/values/strings.xml`
- `app/src/main/res/values/styles.xml`
- `app/src/main/res/xml/network_security_config.xml`
- `app/src/main/res/xml/accessibility_service_config.xml`
