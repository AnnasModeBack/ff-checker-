package com.annas.tools;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    public static MainActivity activeActivity = null;
    private WebView webView;
    private long lastBackPress = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeActivity = this;

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AnnasToolsBridge(), "AnnasBridge");
        webView.loadUrl("file:///android_asset/index.html");

        setContentView(webView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeActivity = this;
        notifyWebSync();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (activeActivity == this) {
            activeActivity = null;
        }
    }

    public void notifyWebSync() {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript("if(window.syncFromNative){ window.syncFromNative(); }", null);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean checkOverlayGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    public boolean checkAccessibilityGranted() {
        if (ScreenAutoService.instance != null) return true;
        int enabled = 0;
        final String serviceId = getPackageName() + "/" + ScreenAutoService.class.getCanonicalName();
        try {
            enabled = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Settings.SettingNotFoundException ignored) {
        }
        if (enabled == 1) {
            String settingValue = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
                splitter.setString(settingValue);
                while (splitter.hasNext()) {
                    String componentName = splitter.next();
                    if (componentName.equalsIgnoreCase(serviceId)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean checkNotificationGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public class AnnasToolsBridge {

        @JavascriptInterface
        public String getFullStatusJson() {
            boolean overlay = checkOverlayGranted();
            boolean access = checkAccessibilityGranted();
            boolean notif = checkNotificationGranted();
            boolean serviceOn = FloatingAiService.isRunning;
            boolean autoLoop = FloatingAiService.autoLoopRunning;
            SharedPreferences prefs = getSharedPreferences("annas_ai_prefs", Context.MODE_PRIVATE);
            String apiKey = prefs.getString("ai_api_key", "");
            return "{"
                    + ""overlay":" + overlay + ","
                    + ""accessibility":" + access + ","
                    + ""notification":" + notif + ","
                    + ""serviceRunning":" + serviceOn + ","
                    + ""autoLoop":" + autoLoop + ","
                    + ""hasApiKey":" + (!apiKey.isEmpty()) + ","
                    + ""apiKeyMasked":"" + (apiKey.length() > 6 ? apiKey.substring(0, 4) + "••••" : apiKey) + """
                    + "}";
        }

        @JavascriptInterface
        public void saveApiKey(String key) {
            SharedPreferences prefs = getSharedPreferences("annas_ai_prefs", Context.MODE_PRIVATE);
            prefs.edit().putString("ai_api_key", key == null ? "" : key.trim()).apply();
            notifyWebSync();
        }

        @JavascriptInterface
        public String getApiKey() {
            SharedPreferences prefs = getSharedPreferences("annas_ai_prefs", Context.MODE_PRIVATE);
            return prefs.getString("ai_api_key", "");
        }

        @JavascriptInterface
        public void openOverlaySettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        @JavascriptInterface
        public void openAppInfoSettings() {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !checkNotificationGranted()) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 801);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(intent);
            }
        }

        @JavascriptInterface
        public boolean setMasterService(boolean enable) {
            if (enable) {
                if (!checkOverlayGranted() || !checkAccessibilityGranted()) {
                    notifyWebSync();
                    return false;
                }
                Intent svc = new Intent(MainActivity.this, FloatingAiService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                notifyWebSync();
                return true;
            } else {
                FloatingAiService.autoLoopRunning = false;
                stopService(new Intent(MainActivity.this, FloatingAiService.class));
                notifyWebSync();
                return true;
            }
        }

        @JavascriptInterface
        public void openChromeSearch(String query) {
            Uri uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }
}
