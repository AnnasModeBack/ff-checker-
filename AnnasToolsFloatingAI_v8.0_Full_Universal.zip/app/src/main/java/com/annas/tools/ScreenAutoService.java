package com.annas.tools;

import android.accessibilityservice.AccessibilityService;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenAutoService extends AccessibilityService {

    public static ScreenAutoService instance = null;

    public static class SolveDecision {
        public final String optionLetter;
        public final String optionText;

        public SolveDecision(String optionLetter, String optionText) {
            this.optionLetter = optionLetter;
            this.optionText = optionText;
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        if (MainActivity.activeActivity != null) {
            MainActivity.activeActivity.notifyWebSync();
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    public String extractScreenText() {
        StringBuilder sb = new StringBuilder();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null && !windows.isEmpty()) {
                    for (AccessibilityWindowInfo w : windows) {
                        if (w != null && w.getRoot() != null) {
                            AccessibilityNodeInfo root = w.getRoot();
                            if (root.getPackageName() != null && getPackageName().equals(root.getPackageName().toString())) {
                                continue;
                            }
                            traverseNode(root, sb);
                        }
                    }
                }
            }
            if (sb.length() == 0) {
                AccessibilityNodeInfo activeRoot = getRootInActiveWindow();
                if (activeRoot != null) {
                    traverseNode(activeRoot, sb);
                }
            }
        } catch (Exception ignored) {
        }
        return sb.toString().trim();
    }

    private void traverseNode(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;
        try {
            CharSequence txt = node.getText();
            CharSequence desc = node.getContentDescription();
            if (txt != null && txt.toString().trim().length() > 0) {
                sb.append(txt.toString().trim()).append("\n");
            } else if (desc != null && desc.toString().trim().length() > 0) {
                sb.append(desc.toString().trim()).append("\n");
            }
            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                traverseNode(node.getChild(i), sb);
            }
        } catch (Exception ignored) {
        }
    }

    public boolean clickOptionOnScreen(String optionLetter, String optionText) {
        try {
            List<AccessibilityNodeInfo> roots = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo w : windows) {
                        if (w != null && w.getRoot() != null) {
                            AccessibilityNodeInfo r = w.getRoot();
                            if (r.getPackageName() != null && !getPackageName().equals(r.getPackageName().toString())) {
                                roots.add(r);
                            }
                        }
                    }
                }
            }
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null) roots.add(active);

            for (AccessibilityNodeInfo root : roots) {
                if (optionText != null && optionText.length() > 1) {
                    List<AccessibilityNodeInfo> matches = root.findAccessibilityNodeInfosByText(optionText);
                    if (matches != null) {
                        for (AccessibilityNodeInfo m : matches) {
                            if (clickSelfOrParent(m)) return true;
                        }
                    }
                }
                String[] prefixes = {optionLetter + ".", optionLetter + ")", optionLetter + " "};
                for (String p : prefixes) {
                    List<AccessibilityNodeInfo> letterMatches = root.findAccessibilityNodeInfosByText(p);
                    if (letterMatches != null) {
                        for (AccessibilityNodeInfo m : letterMatches) {
                            if (clickSelfOrParent(m)) return true;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean clickSelfOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo curr = node;
        int depth = 0;
        while (curr != null && depth < 6) {
            if (curr.isClickable() && curr.isEnabled()) {
                return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            curr = curr.getParent();
            depth++;
        }
        return false;
    }

    public SolveDecision solveLocallyFallback(String rawText) {
        String clean = rawText.replace("×", "*").replace("÷", "/");
        Map<String, String> options = new LinkedHashMap<>();
        String[] letters = {"A", "B", "C", "D", "E"};

        for (String l : letters) {
            Pattern p = Pattern.compile("(?m)^" + l + "[\\.\\)\\:]\\s*(.+)$");
            Matcher m = p.matcher(clean);
            if (m.find()) {
                options.put(l, m.group(1).trim());
            }
        }

        Matcher mathM = Pattern.compile("(-?\\d+)\\s*([\\+\\-\\*\\/])\\s*(-?\\d+)").matcher(clean);
        if (mathM.find()) {
            int a = Integer.parseInt(mathM.group(1));
            String op = mathM.group(2);
            int b = Integer.parseInt(mathM.group(3));
            int res = a + b;
            if ("-".equals(op)) res = a - b;
            if ("*".equals(op)) res = a * b;
            if ("/".equals(op) && b != 0) res = a / b;
            String ansStr = String.valueOf(res);

            for (Map.Entry<String, String> entry : options.entrySet()) {
                if (entry.getValue().contains(ansStr)) {
                    return new SolveDecision(entry.getKey(), entry.getValue());
                }
            }
        }

        if (!options.isEmpty()) {
            String upper = clean.toUpperCase();
            boolean hasNegation = upper.contains("KECUALI") || upper.contains("BUKAN") || upper.contains("YANG SALAH");
            List<String> keys = new ArrayList<>(options.keySet());
            String chosen = hasNegation ? keys.get(keys.size() - 1) : keys.get(0);
            return new SolveDecision(chosen, options.get(chosen));
        }

        return new SolveDecision("A", "Opsi A");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        if (MainActivity.activeActivity != null) {
            MainActivity.activeActivity.notifyWebSync();
        }
    }
}
