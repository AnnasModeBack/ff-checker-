-keep class com.annas.tools.** { *; }
-keepclassmembers class com.annas.tools.MainActivity$AnnasToolsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
