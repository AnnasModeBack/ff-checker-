package com.annas.aifloating

import android.content.Intent
import android.graphics.Bitmap

object MediaProjectionStore {
    @Volatile var resultCode: Int = 0
    @Volatile var resultData: Intent? = null
    @Volatile var lastCroppedBitmap: Bitmap? = null
    @Volatile var lastScreenText: String = ""

    fun hasProjectionData(): Boolean = resultCode != 0 && resultData != null

    fun clear() {
        resultCode = 0
        resultData = null
        lastCroppedBitmap = null
    }
}
