package com.annas.aifloating

import androidx.multidex.MultiDexApplication

class AIFloatingApp : MultiDexApplication() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: AIFloatingApp
            private set
    }
}
