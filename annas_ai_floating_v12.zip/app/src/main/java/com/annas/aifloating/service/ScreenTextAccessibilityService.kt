package com.annas.aifloating.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.annas.aifloating.MediaProjectionStore

class ScreenTextAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val extracted = extractText(root, StringBuilder(), 0).toString().trim()
        if (extracted.isNotEmpty()) {
            MediaProjectionStore.lastScreenText = extracted.take(4000)
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun captureCurrentScreenText(): String {
        val root = rootInActiveWindow ?: return MediaProjectionStore.lastScreenText
        val text = extractText(root, StringBuilder(), 0).toString().trim()
        if (text.isNotEmpty()) {
            MediaProjectionStore.lastScreenText = text.take(4000)
        }
        return MediaProjectionStore.lastScreenText
    }

    private fun extractText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int): StringBuilder {
        if (node == null || depth > 25 || sb.length >= 4000) return sb
        val txt = node.text?.toString()?.trim()
        if (!txt.isNullOrEmpty() && txt != "AI" && txt != "SystemUI") {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(txt)
        }
        for (i in 0 until node.childCount) {
            extractText(node.getChild(i), sb, depth + 1)
            if (sb.length >= 4000) break
        }
        return sb
    }

    companion object {
        @Volatile var instance: ScreenTextAccessibilityService? = null
    }
}
