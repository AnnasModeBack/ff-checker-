package com.annas.aifloating.service

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.annas.aifloating.MainActivity
import com.annas.aifloating.MediaProjectionStore
import com.annas.aifloating.R
import com.annas.aifloating.ScreenCapturePermissionActivity
import com.annas.aifloating.overlay.ScreenSelectionOverlayView
import org.json.JSONObject

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubbleView: View? = null
    private var verticalBarView: View? = null
    private var hiddenHandleView: View? = null
    private var webWindowView: View? = null
    private var cropOverlayView: ScreenSelectionOverlayView? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var vbarParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var webWinParams: WindowManager.LayoutParams? = null

    private var webView: WebView? = null
    private var webEtUrl: EditText? = null
    private var webTvTitle: TextView? = null
    private var webProgress: ProgressBar? = null

    private var isBarExpanded = false
    private var isEdgeHidden = false
    private var isWebOpen = false
    private var isFullscreenWeb = false
    private var pendingPromptAfterLoad: String = ""
    private var bubbleRotate: ObjectAnimator? = null

    private val prefs by lazy {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        if (canDrawOverlays()) {
            initBubble()
            initVerticalBar()
            initHiddenHandle()
            showBubble()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        if (!canDrawOverlays()) return START_STICKY

        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
                removeAllOverlays()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_OPEN_WEB -> {
                val url = intent.getStringExtra(EXTRA_URL) ?: currentTargetUrl()
                val prompt = intent.getStringExtra(EXTRA_PROMPT) ?: ""
                openFloatingWebWindow(url, prompt)
            }
            ACTION_QUERY_TEXT -> {
                val prompt = intent.getStringExtra(EXTRA_PROMPT) ?: ""
                if (prompt.isNotBlank()) {
                    openFloatingWebWindow(currentTargetUrl(), prompt)
                }
            }
            ACTION_START_CROP_SESSION -> {
                launchCropSelectionOverlay()
            }
        }
        return START_STICKY
    }

    private fun canDrawOverlays(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun currentTargetUrl(): String {
        val saved = prefs.getString(KEY_TARGET_URL, "")?.trim().orEmpty()
        return if (saved.isBlank()) DEFAULT_GEMINI_URL else saved
    }

    private fun isStealthEnabled(): Boolean = prefs.getBoolean(KEY_STEALTH, false)

    private fun stealthLabel(): String =
        prefs.getString(KEY_STEALTH_TAG, "SystemUI")?.trim().orEmpty().ifBlank { "SystemUI" }

    @SuppressLint("ClickableViewAccessibility")
    private fun initBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(KEY_BUBBLE_X, 24)
            y = prefs.getInt(KEY_BUBBLE_Y, 260)
        }

        val icon = view.findViewById<ImageView>(R.id.iv_bubble_icon)
        val badge = view.findViewById<TextView>(R.id.tv_bubble_badge)
        badge?.text = if (isStealthEnabled()) stealthLabel().take(4).uppercase() else "AI"

        icon?.let {
            bubbleRotate = ObjectAnimator.ofFloat(it, View.ROTATION, 0f, 360f).apply {
                duration = 9000L
                repeatCount = ValueAnimator.INFINITE
                interpolator = AccelerateDecelerateInterpolator()
                start()
            }
        }

        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    params.x = maxOf(0, startX + dx)
                    params.y = maxOf(0, startY + dy)
                    safeUpdateLayout(v, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        toggleVerticalBar(params.x, params.y)
                    } else {
                        val screenW = resources.displayMetrics.widthPixels
                        val snapX = if (params.x + v.width / 2 < screenW / 2) 16 else maxOf(16, screenW - v.width - 16)
                        animateSnapX(v, params, params.x, snapX)
                        prefs.edit().putInt(KEY_BUBBLE_X, snapX).putInt(KEY_BUBBLE_Y, params.y).apply()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleView = view
        bubbleParams = params
    }

    private fun initVerticalBar() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_vertical_bar, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }

        view.findViewById<ImageButton>(R.id.vbar_btn_ai_search)?.setOnClickListener {
            val prompt = resolveQuickPrompt()
            if (prompt.isBlank()) {
                Toast.makeText(this, "Salin teks atau aktifkan Aksesibilitas untuk tanya AI", Toast.LENGTH_SHORT).show()
                openFloatingWebWindow(currentTargetUrl(), "")
            } else {
                openFloatingWebWindow(currentTargetUrl(), prompt)
            }
        }

        view.findViewById<ImageButton>(R.id.vbar_btn_crop)?.setOnClickListener {
            if (MediaProjectionStore.hasProjectionData()) {
                launchCropSelectionOverlay()
            } else {
                startActivity(Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }

        view.findViewById<ImageButton>(R.id.vbar_btn_web)?.setOnClickListener {
            val marked = prefs.getString(KEY_MARKED_TEXT, "")?.trim().orEmpty()
            openFloatingWebWindow(currentTargetUrl(), marked)
        }

        view.findViewById<ImageButton>(R.id.vbar_btn_hide)?.setOnClickListener {
            hideToEdgeHandle()
        }

        view.findViewById<ImageButton>(R.id.vbar_btn_collapse)?.setOnClickListener {
            collapseToBubble()
        }

        verticalBarView = view
        vbarParams = params
    }

    private fun initHiddenHandle() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_hidden_handle, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 320
        }

        view.setOnClickListener {
            isEdgeHidden = false
            safeRemoveView(hiddenHandleView)
            showBubble()
        }

        hiddenHandleView = view
        handleParams = params
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun initWebWindow() {
        if (webWindowView != null) return
        val dm = resources.displayMetrics
        val view = LayoutInflater.from(this).inflate(R.layout.floating_web_window, null)
        val params = WindowManager.LayoutParams(
            (dm.widthPixels * 0.92f).toInt(),
            (dm.heightPixels * 0.68f).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val wv = view.findViewById<WebView>(R.id.web_view)
        val etUrl = view.findViewById<EditText>(R.id.web_et_url)
        val tvTitle = view.findViewById<TextView>(R.id.web_tv_title)
        val pb = view.findViewById<ProgressBar>(R.id.web_progress)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = userAgentString.replace("; wv", "")
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                url?.let {
                    etUrl?.setText(it)
                    prefs.edit().putString(KEY_TARGET_URL, it).apply()
                }
                val title = v?.title
                if (!title.isNullOrBlank()) {
                    tvTitle?.text = if (isStealthEnabled()) stealthLabel() else title
                }
                if (pendingPromptAfterLoad.isNotBlank() && url != null && url.contains("gemini.google.com")) {
                    injectPromptIntoGemini(wv, pendingPromptAfterLoad)
                    pendingPromptAfterLoad = ""
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, newProgress: Int) {
                pb?.progress = newProgress
                pb?.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }

        view.findViewById<ImageButton>(R.id.web_btn_back)?.setOnClickListener {
            if (wv.canGoBack()) wv.goBack()
        }
        view.findViewById<ImageButton>(R.id.web_btn_forward)?.setOnClickListener {
            if (wv.canGoForward()) wv.goForward()
        }
        view.findViewById<ImageButton>(R.id.web_btn_refresh)?.setOnClickListener {
            wv.reload()
        }
        view.findViewById<ImageButton>(R.id.web_btn_fullscreen)?.setOnClickListener {
            isFullscreenWeb = !isFullscreenWeb
            val metrics = resources.displayMetrics
            if (isFullscreenWeb) {
                params.width = (metrics.widthPixels * 0.98f).toInt()
                params.height = (metrics.heightPixels * 0.90f).toInt()
            } else {
                params.width = (metrics.widthPixels * 0.92f).toInt()
                params.height = (metrics.heightPixels * 0.68f).toInt()
            }
            safeUpdateLayout(view, params)
        }
        view.findViewById<ImageButton>(R.id.web_btn_minimize)?.setOnClickListener {
            closeFloatingWebWindow()
        }
        view.findViewById<ImageButton>(R.id.web_btn_go)?.setOnClickListener {
            val raw = etUrl?.text?.toString()?.trim().orEmpty()
            if (raw.isBlank()) return@setOnClickListener
            val normalized = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
            prefs.edit().putString(KEY_TARGET_URL, normalized).apply()
            wv.loadUrl(normalized)
        }

        var dragStartX = 0f
        var dragStartY = 0f
        var winStartX = 0
        var winStartY = 0
        view.findViewById<View>(R.id.web_win_header)?.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = ev.rawX
                    dragStartY = ev.rawY
                    winStartX = params.x
                    winStartY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = winStartX + (ev.rawX - dragStartX).toInt()
                    params.y = winStartY + (ev.rawY - dragStartY).toInt()
                    safeUpdateLayout(view, params)
                    true
                }
                else -> false
            }
        }

        webView = wv
        webEtUrl = etUrl
        webTvTitle = tvTitle
        webProgress = pb
        webWindowView = view
        webWinParams = params
    }

    private fun openFloatingWebWindow(baseUrl: String, prompt: String) {
        initWebWindow()
        val wv = webView ?: return
        val params = webWinParams ?: return
        val view = webWindowView ?: return

        val finalUrl = if (prompt.isNotBlank() && baseUrl.contains("gemini.google.com")) {
            pendingPromptAfterLoad = prompt
            "https://gemini.google.com/app?q=" + Uri.encode(prompt)
        } else {
            pendingPromptAfterLoad = prompt
            baseUrl
        }

        webEtUrl?.setText(finalUrl)
        if (view.windowToken == null) {
            safeAddView(view, params)
        } else {
            safeUpdateLayout(view, params)
        }
        isWebOpen = true
        wv.loadUrl(finalUrl)
    }

    private fun closeFloatingWebWindow() {
        safeRemoveView(webWindowView)
        isWebOpen = false
    }

    private fun injectPromptIntoGemini(wv: WebView, prompt: String) {
        val quoted = JSONObject.quote(prompt)
        val js = "(function(){try{var el=document.querySelector('textarea,[contenteditable=\"true\"]');if(el){el.focus();if(el.tagName==='TEXTAREA'){el.value=" + quoted + ";}else{el.innerText=" + quoted + ";}el.dispatchEvent(new Event('input',{bubbles:true}));}}catch(e){}})();"
        mainHandler.postDelayed({ wv.evaluateJavascript(js, null) }, 900L)
    }

    private fun launchCropSelectionOverlay() {
        if (cropOverlayView != null) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val overlay = ScreenSelectionOverlayView(
            context = this,
            onRegionSelected = { rect ->
                removeCropOverlay()
                val textHint = ScreenTextAccessibilityService.instance?.captureCurrentScreenText().orEmpty()
                val combinedPrompt = if (textHint.isNotBlank()) {
                    "Bantu jawab area soal (${rect.width().toInt()}x${rect.height().toInt()}px). Konteks teks layar:\n$textHint"
                } else {
                    "Bantu jawab area soal yang dipilih (${rect.width().toInt()}x${rect.height().toInt()}px)."
                }
                openFloatingWebWindow(currentTargetUrl(), combinedPrompt)
            },
            onCancelled = {
                removeCropOverlay()
            }
        )
        cropOverlayView = overlay
        safeAddView(overlay, params)
    }

    private fun removeCropOverlay() {
        safeRemoveView(cropOverlayView)
        cropOverlayView = null
    }

    private fun resolveQuickPrompt(): String {
        val marked = prefs.getString(KEY_MARKED_TEXT, "")?.trim().orEmpty()
        if (marked.isNotBlank()) return marked
        val accText = ScreenTextAccessibilityService.instance?.captureCurrentScreenText().orEmpty()
        if (accText.isNotBlank()) return accText.take(1500)
        return try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun showBubble() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        if (view.windowToken == null) {
            safeAddView(view, params)
        }
        isBarExpanded = false
    }

    private fun toggleVerticalBar(anchorX: Int, anchorY: Int) {
        if (isBarExpanded) {
            collapseToBubble()
        } else {
            safeRemoveView(bubbleView)
            val bar = verticalBarView ?: return
            val params = vbarParams ?: return
            val screenW = resources.displayMetrics.widthPixels
            params.x = if (anchorX < screenW / 2) 16 else maxOf(16, screenW - 140)
            params.y = maxOf(80, anchorY - 40)
            safeAddView(bar, params)
            isBarExpanded = true
        }
    }

    private fun collapseToBubble() {
        safeRemoveView(verticalBarView)
        isBarExpanded = false
        showBubble()
    }

    private fun hideToEdgeHandle() {
        safeRemoveView(verticalBarView)
        safeRemoveView(bubbleView)
        isBarExpanded = false
        isEdgeHidden = true
        val handle = hiddenHandleView ?: return
        val params = handleParams ?: return
        safeAddView(handle, params)
    }

    private fun animateSnapX(view: View, params: WindowManager.LayoutParams, fromX: Int, toX: Int) {
        ValueAnimator.ofInt(fromX, toX).apply {
            duration = 200L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                safeUpdateLayout(view, params)
            }
            start()
        }
    }

    private fun safeAddView(view: View?, params: WindowManager.LayoutParams?) {
        if (view == null || params == null) return
        try {
            if (view.windowToken == null) windowManager.addView(view, params)
        } catch (_: Exception) {
        }
    }

    private fun safeUpdateLayout(view: View?, params: WindowManager.LayoutParams?) {
        if (view == null || params == null) return
        try {
            if (view.windowToken != null) windowManager.updateViewLayout(view, params)
        } catch (_: Exception) {
        }
    }

    private fun safeRemoveView(view: View?) {
        if (view == null) return
        try {
            if (view.windowToken != null) windowManager.removeView(view)
        } catch (_: Exception) {
        }
    }

    private fun removeAllOverlays() {
        removeCropOverlay()
        closeFloatingWebWindow()
        safeRemoveView(verticalBarView)
        safeRemoveView(hiddenHandleView)
        safeRemoveView(bubbleView)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                if (isStealthEnabled()) stealthLabel() else "Annas AI Floating",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val openMain = PendingIntent.getActivity(
            this, 100, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 101,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (isStealthEnabled()) "${stealthLabel()} Service" else "Annas AI Floating Aktif"
        val body = if (isStealthEnabled()) "Layanan latar belakang berjalan" else "Ketuk bubble untuk membuka panel AI & Web"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.drawable.ic_ai_floating_svg)
            .setContentIntent(openMain)
            .setOngoing(true)
            .addAction(0, "Matikan", stopIntent)
            .build()
    }

    override fun onDestroy() {
        bubbleRotate?.cancel()
        removeAllOverlays()
        super.onDestroy()
    }

    companion object {
        const val PREFS_NAME = "annas_ai_floating_prefs_v10"
        const val KEY_ACTIVE = "overlay_active"
        const val KEY_MARKED_TEXT = "marked_text"
        const val KEY_TARGET_URL = "target_url"
        const val KEY_STEALTH = "stealth_mode"
        const val KEY_STEALTH_TAG = "stealth_tag"
        const val KEY_BUBBLE_X = "bubble_x"
        const val KEY_BUBBLE_Y = "bubble_y"
        const val DEFAULT_GEMINI_URL = "https://gemini.google.com/app"

        const val ACTION_OPEN_WEB = "com.annas.aifloating.action.OPEN_WEB"
        const val ACTION_QUERY_TEXT = "com.annas.aifloating.action.QUERY_TEXT"
        const val ACTION_START_CROP_SESSION = "com.annas.aifloating.action.START_CROP_SESSION"
        const val ACTION_STOP_SERVICE = "com.annas.aifloating.action.STOP_SERVICE"

        const val EXTRA_URL = "extra_url"
        const val EXTRA_PROMPT = "extra_prompt"

        private const val CHANNEL_ID = "annas_ai_floating_channel_v10"
        private const val NOTIF_ID = 10010
    }
}