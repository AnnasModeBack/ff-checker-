package com.annas.aifloating

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.annas.aifloating.service.FloatingOverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var etMarkedText: EditText
    private lateinit var etTargetUrl: EditText
    private lateinit var etStealthTag: EditText
    private lateinit var cbAutoOpenWeb: CheckBox
    private lateinit var cbStealthMode: CheckBox

    private val prefs by lazy {
        getSharedPreferences(FloatingOverlayService.PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_service_status)
        etMarkedText = findViewById(R.id.et_marked_text)
        etTargetUrl = findViewById(R.id.et_target_url)
        etStealthTag = findViewById(R.id.et_stealth_tag)
        cbAutoOpenWeb = findViewById(R.id.cb_auto_open_web)
        cbStealthMode = findViewById(R.id.cb_stealth_mode)

        etMarkedText.setText(prefs.getString(FloatingOverlayService.KEY_MARKED_TEXT, ""))
        etTargetUrl.setText(
            prefs.getString(FloatingOverlayService.KEY_TARGET_URL, FloatingOverlayService.DEFAULT_GEMINI_URL)
                ?.ifBlank { FloatingOverlayService.DEFAULT_GEMINI_URL }
        )
        etStealthTag.setText(prefs.getString(FloatingOverlayService.KEY_STEALTH_TAG, "SystemUI"))
        cbStealthMode.isChecked = prefs.getBoolean(FloatingOverlayService.KEY_STEALTH, false)

        findViewById<Button>(R.id.btn_paste_clipboard).setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
            if (clip.isNotEmpty()) {
                etMarkedText.setText(clip)
                Toast.makeText(this, "Teks ditempel dari clipboard", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Clipboard kosong", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_clear_marked).setOnClickListener {
            etMarkedText.setText("")
            prefs.edit().remove(FloatingOverlayService.KEY_MARKED_TEXT).apply()
        }

        findViewById<Button>(R.id.btn_start_overlay).setOnClickListener {
            saveConfig()
            if (!hasOverlayPermission()) {
                Toast.makeText(this, "Aktifkan izin Tampil di atas aplikasi lain terlebih dahulu", Toast.LENGTH_LONG).show()
                openOverlayPermissionSettings()
                return@setOnClickListener
            }
            startFloatingService(openWeb = cbAutoOpenWeb.isChecked)
        }

        findViewById<Button>(R.id.btn_stop_overlay).setOnClickListener {
            startService(Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_STOP_SERVICE
            })
            refreshStatus()
            Toast.makeText(this, "Layanan floating dihentikan", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btn_request_crop_perm).setOnClickListener {
            saveConfig()
            if (!hasOverlayPermission()) {
                openOverlayPermissionSettings()
                return@setOnClickListener
            }
            startActivity(Intent(this, ScreenCapturePermissionActivity::class.java))
        }

        findViewById<Button>(R.id.btn_open_accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btn_open_overlay_perm).setOnClickListener {
            openOverlayPermissionSettings()
        }

        handleProcessTextIntent(intent)
        refreshStatus()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleProcessTextIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun handleProcessTextIntent(intent: Intent?) {
        if (intent == null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Intent.ACTION_PROCESS_TEXT == intent.action) {
            val selected = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.trim().orEmpty()
            if (selected.isNotEmpty()) {
                etMarkedText.setText(selected)
                saveConfig()
                if (hasOverlayPermission()) {
                    startFloatingService(openWeb = true)
                } else {
                    openOverlayPermissionSettings()
                }
            }
        }
    }

    private fun saveConfig() {
        val rawUrl = etTargetUrl.text.toString().trim().ifBlank { FloatingOverlayService.DEFAULT_GEMINI_URL }
        val normalizedUrl = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "https://$rawUrl"
        etTargetUrl.setText(normalizedUrl)

        prefs.edit()
            .putBoolean(FloatingOverlayService.KEY_ACTIVE, true)
            .putString(FloatingOverlayService.KEY_MARKED_TEXT, etMarkedText.text.toString().trim())
            .putString(FloatingOverlayService.KEY_TARGET_URL, normalizedUrl)
            .putBoolean(FloatingOverlayService.KEY_STEALTH, cbStealthMode.isChecked)
            .putString(FloatingOverlayService.KEY_STEALTH_TAG, etStealthTag.text.toString().trim().ifBlank { "SystemUI" })
            .apply()
    }

    private fun startFloatingService(openWeb: Boolean) {
        val marked = etMarkedText.text.toString().trim()
        val url = etTargetUrl.text.toString().trim().ifBlank { FloatingOverlayService.DEFAULT_GEMINI_URL }

        val intent = Intent(this, FloatingOverlayService::class.java).apply {
            action = if (openWeb) FloatingOverlayService.ACTION_OPEN_WEB else FloatingOverlayService.ACTION_QUERY_TEXT
            putExtra(FloatingOverlayService.EXTRA_URL, url)
            putExtra(FloatingOverlayService.EXTRA_PROMPT, marked)
        }
        startForegroundService(intent)
        refreshStatus()
    }

    private fun hasOverlayPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun openOverlayPermissionSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    private fun refreshStatus() {
        val overlayOk = hasOverlayPermission()
        val active = prefs.getBoolean(FloatingOverlayService.KEY_ACTIVE, false) && overlayOk
        tvStatus.text = when {
            !overlayOk -> "Status: Izin Overlay Belum Aktif"
            active && cbStealthMode.isChecked -> "Status: Aktif (${etStealthTag.text.toString().trim().ifBlank { "SystemUI" }})"
            active -> "Status: Annas AI Floating Aktif"
            else -> "Status: Siap Diaktifkan"
        }
    }
}
