package com.annas.aifloating.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

class ScreenSelectionOverlayView(
    context: Context,
    private val onRegionSelected: (RectF) -> Unit,
    private val onCancelled: () -> Unit
) : View(context) {

    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#99030712")
    }
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F8FAFC")
        textSize = 36f
    }

    private var startX = 0f
    private var startY = 0f
    private var curX = 0f
    private var curY = 0f
    private var dragging = false

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)

        if (dragging) {
            val rect = currentRect()
            canvas.drawRect(rect, clearPaint)
            canvas.drawRect(rect, borderPaint)
        } else {
            canvas.drawText("Seret jari untuk memilih area soal / layar", 36f, 110f, guidePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                curX = event.x
                curY = event.y
                dragging = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                curX = event.x
                curY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                curX = event.x
                curY = event.y
                val rect = currentRect()
                dragging = false
                invalidate()
                if (rect.width() > 36f && rect.height() > 36f) {
                    onRegionSelected(rect)
                } else {
                    onCancelled()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun currentRect(): RectF {
        val left = minOf(startX, curX)
        val top = minOf(startY, curY)
        val right = maxOf(startX, curX)
        val bottom = maxOf(startY, curY)
        return RectF(left, top, right, bottom)
    }
}
