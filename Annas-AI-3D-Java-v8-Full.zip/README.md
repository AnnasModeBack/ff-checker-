# Annas AI 3D Pro v8 (Java Native Full Complete ZIP)

Aplikasi asisten tugas otomatis berbasis **Java murni** dengan **3D Floating Bubble**, **Kotak Penanda + Centang (✓) ke Google AI**, **Izin Pemberitahuan**, **Animasi 3D Tingkat Tinggi**, **Tipografi Tajam**, dan **100% Vector SVG Full HD**.

## Perbaikan Utama v8
- **Menghilangkan Error `BuildLayoutValidator` (`To create a new Gradle build in this directory run 'gradle init'`):** Pada v7 sebelumnya, file `build.gradle`, `settings.gradle`, `app/build.gradle`, dan `app/proguard-rules.pro` sempat terlewat dari ZIP kedua/ketiga sehingga Gradle tidak menemukan `settings.gradle` & `build.gradle` di direktori root. Di **v8**, seluruh 38 file (termasuk `settings.gradle`, `build.gradle`, `app/build.gradle`, `app/proguard-rules.pro`, `gradle.properties`, dan `.github/workflows/build-apk.yml`) dipastikan lengkap di dalam ZIP.
- **Auto-Extract Fleksibel di `build-apk.yml`:** Otomatis mencari `settings.gradle` atau `app/build.gradle` di kedalaman mana pun di dalam ZIP (baik root maupun subfolder), menyalinnya ke root repository, lalu menjalankan `gradle assembleDebug --no-daemon --stacktrace`.
