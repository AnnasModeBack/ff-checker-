package com.annas.tools;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;

public class FloatingAiService extends Service {

    public static boolean isRunning = false;
    public static boolean autoSolveEnabled = true;
    public static FloatingAiService instance = null;

    private WindowManager windowManager;
    private LinearLayout rootLayout;
    private TextView bubbleBadge;
    private LinearLayout expandedPanel;
    private TextView statusPill;
    private TextView resultOutputView;
    private Button btnToggleMode;
    private Button btnRunAction;
    private EditText searchInput;
    private boolean isExpanded = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        instance = this;
        startForegroundNotification();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 28;
        params.y = 260;

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);

        bubbleBadge = new TextView(this);
        bubbleBadge.setText("AI");
        bubbleBadge.setTextColor(Color.parseColor("#22D3EE"));
        bubbleBadge.setTextSize(15f);
        bubbleBadge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bubbleBadge.setGravity(Gravity.CENTER);
        bubbleBadge.setWidth(136);
        bubbleBadge.setHeight(136);
        bubbleBadge.setElevation(18f);
        updateBubbleDrawable();

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(36f);
        panelBg.setColor(Color.parseColor("#F5090D16"));
        panelBg.setStroke(3, Color.parseColor("#22D3EE"));

        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.VERTICAL);
        expandedPanel.setBackground(panelBg);
        expandedPanel.setPadding(28, 24, 28, 24);
        expandedPanel.setVisibility(View.GONE);
        expandedPanel.setElevation(24f);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText("ANNAS TOOLS AI v7.0");
        titleView.setTextColor(Color.parseColor("#F8FAFC"));
        titleView.setTextSize(13f);
        titleView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        titleView.setPadding(0, 0, 16, 0);

        statusPill = new TextView(this);
        statusPill.setTextSize(11f);
        statusPill.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statusPill.setPadding(16, 6, 16, 6);

        headerRow.addView(titleView);
        headerRow.addView(statusPill);

        btnToggleMode = new Button(this);
        btnToggleMode.setTextSize(12f);
        btnToggleMode.setAllCaps(false);
        btnToggleMode.setOnClickListener(v -> {
            autoSolveEnabled = !autoSolveEnabled;
            refreshOverlayState();
        });

        btnRunAction = new Button(this);
        btnRunAction.setTextSize(12.5f);
        btnRunAction.setAllCaps(false);
        btnRunAction.setOnClickListener(v -> executeFloatingStep());

        searchInput = new EditText(this);
        searchInput.setHint("Cari materi di Chrome...");
        searchInput.setHintTextColor(Color.parseColor("#64748B"));
        searchInput.setTextColor(Color.parseColor("#F8FAFC"));
        searchInput.setTextSize(12.5f);

        Button btnChromeSearch = new Button(this);
        btnChromeSearch.setText("Searching Chrome");
        btnChromeSearch.setTextColor(Color.parseColor("#090D16"));
        btnChromeSearch.setBackgroundColor(Color.parseColor("#22D3EE"));
        btnChromeSearch.setTextSize(12f);
        btnChromeSearch.setAllCaps(false);
        btnChromeSearch.setOnClickListener(v -> {
            String q = searchInput.getText().toString().trim();
            if (!q.isEmpty()) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(browserIntent);
            } else {
                Toast.makeText(this, "Ketik kata kunci pencarian", Toast.LENGTH_SHORT).show();
            }
        });

        resultOutputView = new TextView(this);
        resultOutputView.setTextColor(Color.parseColor("#94A3B8"));
        resultOutputView.setTextSize(11.5f);
        resultOutputView.setTypeface(Typeface.MONOSPACE);
        resultOutputView.setPadding(0, 12, 0, 4);
        resultOutputView.setMaxWidth(640);
        resultOutputView.setText("[FLOATING READY] Tekan tombol di atas untuk memproses 1 soal aktif.");

        expandedPanel.addView(headerRow);
        expandedPanel.addView(btnToggleMode);
        expandedPanel.addView(btnRunAction);
        expandedPanel.addView(searchInput);
        expandedPanel.addView(btnChromeSearch);
        expandedPanel.addView(resultOutputView);

        rootLayout.addView(bubbleBadge);
        rootLayout.addView(expandedPanel);

        bubbleBadge.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        bubbleBadge.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int) (event.getRawX() - touchX);
                        params.y = startY + (int) (event.getRawY() - touchY);
                        windowManager.updateViewLayout(rootLayout, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                        bubbleBadge.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                        double dist = Math.hypot(event.getRawX() - touchX, event.getRawY() - touchY);
                        if (dist < 14.0) {
                            isExpanded = !isExpanded;
                            expandedPanel.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
                            if (isExpanded) {
                                params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                            } else {
                                params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                            }
                            windowManager.updateViewLayout(rootLayout, params);
                        }
                        return true;
                }
                return false;
            }
        });

        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        windowManager.addView(rootLayout, params);
        refreshOverlayState();
    }

    private void updateBubbleDrawable() {
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#090D16"));
        circle.setStroke(5, autoSolveEnabled ? Color.parseColor("#22C55E") : Color.parseColor("#22D3EE"));
        bubbleBadge.setBackground(circle);
    }

    public void refreshOverlayState() {
        new Handler(Looper.getMainLooper()).post(() -> {
            updateBubbleDrawable();
            if (autoSolveEnabled) {
                statusPill.setText("ON · 1-BY-1");
                statusPill.setTextColor(Color.parseColor("#22C55E"));
                btnToggleMode.setText("Sakelar: AUTO_SOLVE = ON (Klik untuk OFF)");
                btnToggleMode.setBackgroundColor(Color.parseColor("#14532D"));
                btnToggleMode.setTextColor(Color.parseColor("#86EFAC"));
                btnRunAction.setText("Kerjakan 1 Soal Aktif (1-by-1)");
                btnRunAction.setBackgroundColor(Color.parseColor("#22C55E"));
                btnRunAction.setTextColor(Color.parseColor("#052E16"));
            } else {
                statusPill.setText("OFF · STUDY");
                statusPill.setTextColor(Color.parseColor("#94A3B8"));
                btnToggleMode.setText("Sakelar: AUTO_SOLVE = OFF (Klik untuk ON)");
                btnToggleMode.setBackgroundColor(Color.parseColor("#1E293B"));
                btnToggleMode.setTextColor(Color.parseColor("#CBD5E1"));
                btnRunAction.setText("Ringkas Konsep & Kata Kunci");
                btnRunAction.setBackgroundColor(Color.parseColor("#334155"));
                btnRunAction.setTextColor(Color.parseColor("#F8FAFC"));
            }
        });
    }

    private void executeFloatingStep() {
        ScreenAutoService acc = ScreenAutoService.instance;
        if (acc == null) {
            resultOutputView.setText("[PERLU IZIN] Aktifkan Layanan Aksesibilitas Annas Tools di Pengaturan HP.");
            return;
        }
        String screenText = acc.extractScreenText();
        if (screenText == null || screenText.trim().isEmpty()) {
            resultOutputView.setText("[INFO] Tidak ada teks soal terbaca di layar aktif.");
            return;
        }
        if (autoSolveEnabled) {
            String solvedJson = acc.solveAndSelectOneByOne(screenText);
            resultOutputView.setText(solvedJson);
        } else {
            String studySummary = acc.buildStudyAndKeywords(screenText);
            resultOutputView.setText(studySummary);
        }
    }

    private void startForegroundNotification() {
        String channelId = "annas_tools_floating_v7";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(channelId, "Annas Tools Floating AI", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        Notification notif = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("Annas Tools Floating AI v7.0")
                .setContentText("Panel AI melayang aktif di atas aplikasi lain")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
        startForeground(70, notif);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        instance = null;
        if (rootLayout != null && windowManager != null) {
            windowManager.removeView(rootLayout);
        }
    }
}
