package com.annas.tools;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_STORAGE_PERMISSION = 1001;

    private WebView webView;
    private FrameLayout fullscreenContainer;
    private View customVideoView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private String pendingDownloadUrl;
    private String pendingDownloadFilename;
    private String pendingDownloadMime;
    private long lastBackPressTime = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor("#090B10"));
        window.setNavigationBarColor(Color.parseColor("#090B10"));

        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.parseColor("#090B10"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#090B10"));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);

        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        rootLayout.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(rootLayout);

        configureWebView();
        setupBackNavigation();

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        String defaultUA = settings.getUserAgentString();
        settings.setUserAgentString(defaultUA + " AnnasToolsApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("file:///android_asset/")) {
                    return false;
                }
                if (url.endsWith(".mp4") || url.endsWith(".mp3") || url.endsWith(".jpg") || url.endsWith(".png")) {
                    enqueueDownload(url, null, null);
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customVideoView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customVideoView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(customVideoView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                ));
                fullscreenContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreenVideo();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                String guessedName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                enqueueDownload(url, guessedName, mimeType);
            }
        });
    }

    private void exitFullscreenVideo() {
        if (customVideoView == null) return;
        fullscreenContainer.removeView(customVideoView);
        fullscreenContainer.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        customVideoView = null;
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (customVideoView != null) {
                    exitFullscreenVideo();
                    return;
                }

                webView.evaluateJavascript(
                        "(function(){ return (typeof window.handleAndroidBack === 'function') ? String(window.handleAndroidBack()) : 'false'; })()",
                        result -> {
                            boolean handledByWeb = result != null && result.replace("\"", "").equalsIgnoreCase("true");
                            if (!handledByWeb) {
                                long now = System.currentTimeMillis();
                                if (now - lastBackPressTime < 2000L) {
                                    finish();
                                } else {
                                    lastBackPressTime = now;
                                    Toast.makeText(MainActivity.this, "Tekan kembali sekali lagi untuk keluar", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                );
            }
        });
    }

    public void enqueueDownload(String url, String filename, String mimeType) {
        if (url == null || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            runOnUiThread(() -> Toast.makeText(this, "URL unduhan tidak valid", Toast.LENGTH_SHORT).show());
            return;
        }

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingDownloadUrl = url;
                pendingDownloadFilename = filename;
                pendingDownloadMime = mimeType;
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQ_STORAGE_PERMISSION
                );
                return;
            }
        }

        try {
            String safeName = (filename != null && !filename.trim().isEmpty())
                    ? filename.trim()
                    : URLUtil.guessFileName(url, null, mimeType);
            safeName = safeName.replaceAll("[^a-zA-Z0-9._-]", "_");
            if (safeName.length() > 90) {
                String ext = safeName.contains(".") ? safeName.substring(safeName.lastIndexOf('.')) : ".mp4";
                safeName = "AnnasTools_" + System.currentTimeMillis() + ext;
            }

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(safeName);
            request.setDescription("Mengunduh media via Annas Tools");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AnnasTools/" + safeName);
            request.allowScanningByMediaScanner();

            String ua = webView.getSettings().getUserAgentString();
            request.addRequestHeader("User-Agent", ua);
            if (url.contains("tiktok") || url.contains("tikwm")) {
                request.addRequestHeader("Referer", "https://www.tiktok.com/");
            } else if (url.contains("instagram") || url.contains("cdninstagram")) {
                request.addRequestHeader("Referer", "https://www.instagram.com/");
            }

            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                final String displayFile = safeName;
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Mengunduh ke Download/AnnasTools/" + displayFile,
                        Toast.LENGTH_LONG
                ).show());
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    "Gagal memulai unduhan: " + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingDownloadUrl != null) {
                    enqueueDownload(pendingDownloadUrl, pendingDownloadFilename, pendingDownloadMime);
                }
            } else {
                Toast.makeText(this, "Izin penyimpanan diperlukan untuk mengunduh file", Toast.LENGTH_LONG).show();
            }
            pendingDownloadUrl = null;
            pendingDownloadFilename = null;
            pendingDownloadMime = null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void downloadFile(String url, String filename) {
            enqueueDownload(url, filename, null);
        }

        @JavascriptInterface
        public String getClipboardText() {
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData clip = clipboard.getPrimaryClip();
                    if (clip != null && clip.getItemCount() > 0) {
                        CharSequence text = clip.getItemAt(0).coerceToText(MainActivity.this);
                        return text != null ? text.toString() : "";
                    }
                }
            } catch (Exception ignored) {
            }
            return "";
        }

        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
