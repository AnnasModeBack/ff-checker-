package com.annas.tools;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private long lastBackPress = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AnnasToolsBridge(), "AnnasBridge");
        webView.loadUrl("file:///android_asset/index.html");

        setContentView(webView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("if(window.syncNativeState){ window.syncNativeState(); }", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar", Toast.LENGTH_SHORT).show();
        }
    }

    public class AnnasToolsBridge {

        @JavascriptInterface
        public boolean isFloatingActive() {
            return FloatingAiService.isRunning;
        }

        @JavascriptInterface
        public boolean hasOverlayPermission() {
            return Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface
        public boolean isAccessibilityActive() {
            return ScreenAutoService.instance != null;
        }

        @JavascriptInterface
        public void openOverlayPermission() {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
        }

        @JavascriptInterface
        public void openAccessibilityPermission() {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        @JavascriptInterface
        public boolean setFloatingOverlay(boolean enable) {
            if (enable) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Aktifkan izin Tampilkan di atas aplikasi lain", Toast.LENGTH_LONG).show();
                        openOverlayPermission();
                    });
                    return false;
                }
                Intent svc = new Intent(MainActivity.this, FloatingAiService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                return true;
            } else {
                stopService(new Intent(MainActivity.this, FloatingAiService.class));
                return true;
            }
        }

        @JavascriptInterface
        public void syncAutoSolveMode(boolean isOn) {
            FloatingAiService.autoSolveEnabled = isOn;
            if (FloatingAiService.instance != null) {
                FloatingAiService.instance.refreshOverlayState();
            }
        }

        @JavascriptInterface
        public String captureActiveScreenText() {
            if (ScreenAutoService.instance != null) {
                return ScreenAutoService.instance.extractScreenText();
            }
            return "";
        }

        @JavascriptInterface
        public boolean executeOptionSelection(String optionLetter, String optionText) {
            if (ScreenAutoService.instance != null) {
                return ScreenAutoService.instance.selectOptionOnScreen(optionLetter, optionText);
            }
            return false;
        }

        @JavascriptInterface
        public void openChromeSearch(String query) {
            Uri uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }
}
