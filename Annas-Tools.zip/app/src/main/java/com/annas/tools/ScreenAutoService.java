package com.annas.tools;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenAutoService extends AccessibilityService {

    public static ScreenAutoService instance = null;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    public String extractScreenText() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        collectNodeText(root, sb);
        return sb.toString().trim();
    }

    private void collectNodeText(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;
        if (node.getText() != null) {
            String t = node.getText().toString().trim();
            if (!t.isEmpty()) {
                sb.append(t).append("\n");
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectNodeText(node.getChild(i), sb);
        }
    }

    public boolean selectOptionOnScreen(String optionLetter, String optionText) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        if (optionText != null && !optionText.isEmpty()) {
            List<AccessibilityNodeInfo> byText = root.findAccessibilityNodeInfosByText(optionText);
            if (byText != null) {
                for (AccessibilityNodeInfo n : byText) {
                    if (performClickRecursive(n)) return true;
                }
            }
        }
        List<AccessibilityNodeInfo> byLetter = root.findAccessibilityNodeInfosByText(optionLetter + ".");
        if (byLetter != null) {
            for (AccessibilityNodeInfo n : byLetter) {
                if (performClickRecursive(n)) return true;
            }
        }
        return false;
    }

    private boolean performClickRecursive(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        while (current != null) {
            if (current.isClickable()) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            current = current.getParent();
        }
        return false;
    }

    public String solveAndSelectOneByOne(String rawScreenText) {
        String clean = rawScreenText.replace("×", "*").replace("÷", "/");
        List<String> availableOptions = new ArrayList<>();
        String[] letters = {"A", "B", "C", "D", "E"};
        String selectedLetter = "A";
        String selectedText = "Opsi A";

        for (String l : letters) {
            Pattern p = Pattern.compile("(?m)^" + l + "[\\.\\)\\:]\\s*(.+)$");
            Matcher m = p.matcher(clean);
            if (m.find()) {
                availableOptions.add(l);
                if (availableOptions.size() == 1) {
                    selectedLetter = l;
                    selectedText = m.group(1).trim();
                }
            }
        }
        if (availableOptions.isEmpty()) {
            availableOptions.add("A");
            availableOptions.add("B");
            availableOptions.add("C");
            availableOptions.add("D");
        }

        Matcher mathM = Pattern.compile("(-?\\d+)\\s*([\\+\\-\\*\\/])\\s*(-?\\d+)").matcher(clean);
        if (mathM.find()) {
            int a = Integer.parseInt(mathM.group(1));
            String op = mathM.group(2);
            int b = Integer.parseInt(mathM.group(3));
            int res = a + b;
            if ("-".equals(op)) res = a - b;
            if ("*".equals(op)) res = a * b;
            if ("/".equals(op) && b != 0) res = a / b;
            String ansStr = String.valueOf(res);

            for (String l : availableOptions) {
                Pattern optP = Pattern.compile("(?m)^" + l + "[\\.\\)\\:]\\s*(.*" + Pattern.quote(ansStr) + ".*)$");
                Matcher optM = optP.matcher(clean);
                if (optM.find()) {
                    selectedLetter = l;
                    selectedText = optM.group(1).trim();
                    break;
                }
            }
        }

        selectOptionOnScreen(selectedLetter, selectedText);

        return "{\n" +
                "  \"auto_solve\": \"ON\",\n" +
                "  \"mode\": \"ONE_BY_ONE\",\n" +
                "  \"project\": \"com.annas.tools\",\n" +
                "  \"selected_option\": \"" + selectedLetter + "\",\n" +
                "  \"selected_option_text\": \"" + selectedText.replace("\"", "'") + "\",\n" +
                "  \"action\": \"SELECT_OPTION\"\n" +
                "}";
    }

    public String buildStudyAndKeywords(String rawScreenText) {
        String snippet = rawScreenText.replace("\n", " ").trim();
        if (snippet.length() > 70) snippet = snippet.substring(0, 70);
        return "[OFF · STUDY & SEARCH]\n" +
               "• Mode Otomatis: NONAKTIF (action: NONE)\n" +
               "• Kata Kunci Chrome:\n" +
               "  1. " + snippet + "\n" +
               "  2. rumus dan pembahasan " + snippet + "\n" +
               "  3. contoh soal dan jawaban " + snippet;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }
}
