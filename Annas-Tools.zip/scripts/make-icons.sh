#!/usr/bin/env bash
set -euo pipefail

RES_DIR="app/src/main/res"
SRC_ICON=""

if [ -f "assets/icon.jpg" ]; then
  SRC_ICON="assets/icon.jpg"
elif [ -f "app/src/main/assets/icon.jpg" ]; then
  SRC_ICON="app/src/main/assets/icon.jpg"
fi

if [ -z "$SRC_ICON" ]; then
  echo "[!] assets/icon.jpg tidak ditemukan. Membuat ikon default Annas Tools..."
  mkdir -p assets
  convert -size 512x512 xc:"#090B10" \
    -fill "#00E5FF" -draw "roundrectangle 48,48 464,464 96,96" \
    -fill "#090B10" -draw "roundrectangle 64,64 448,448 82,82" \
    -fill "#00E5FF" -font DejaVu-Sans-Bold -pointsize 210 -gravity center -annotate +0+10 "AT" \
    assets/icon.jpg
  SRC_ICON="assets/icon.jpg"
fi

echo "[*] Menggunakan sumber ikon: $SRC_ICON"

declare -A SIZES=(
  ["mipmap-mdpi"]=48
  ["mipmap-hdpi"]=72
  ["mipmap-xhdpi"]=96
  ["mipmap-xxhdpi"]=144
  ["mipmap-xxxhdpi"]=192
)

for DIR in "${!SIZES[@]}"; do
  SIZE=${SIZES[$DIR]}
  OUT_DIR="$RES_DIR/$DIR"
  mkdir -p "$OUT_DIR"

  # Ikon Persegi Standar
  convert "$SRC_ICON" -resize "${SIZE}x${SIZE}^" -gravity center -extent "${SIZE}x${SIZE}" \
    "$OUT_DIR/ic_launcher.png"

  # Ikon Bulat (Round Icon)
  HALF=$((SIZE / 2))
  convert "$SRC_ICON" -resize "${SIZE}x${SIZE}^" -gravity center -extent "${SIZE}x${SIZE}" \
    \( -size "${SIZE}x${SIZE}" xc:none -fill white -draw "circle ${HALF},${HALF} ${HALF},0" \) \
    -alpha set -compose DstIn -composite \
    "$OUT_DIR/ic_launcher_round.png"
done

echo "[+] Semua ikon launcher berhasil dibuat di $RES_DIR/mipmap-*/"
