#!/usr/bin/env bash
set -e
SRC="app/src/main/assets/icon.jpg"
RES="app/src/main/res"

mkdir -p "$RES/mipmap-mdpi" "$RES/mipmap-hdpi" "$RES/mipmap-xhdpi" "$RES/mipmap-xxhdpi" "$RES/mipmap-xxxhdpi"

if command -v convert >/dev/null 2>&1; then
  convert "$SRC" -resize 48x48 "$RES/mipmap-mdpi/ic_launcher.png"
  convert "$SRC" -resize 72x72 "$RES/mipmap-hdpi/ic_launcher.png"
  convert "$SRC" -resize 96x96 "$RES/mipmap-xhdpi/ic_launcher.png"
  convert "$SRC" -resize 144x144 "$RES/mipmap-xxhdpi/ic_launcher.png"
  convert "$SRC" -resize 192x192 "$RES/mipmap-xxxhdpi/ic_launcher.png"
  echo "Icons generated successfully."
else
  echo "ImageMagick not installed; skipping raster resize."
fi
