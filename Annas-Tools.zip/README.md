# Annas Tools

1. Taruh ikon di `asset/icon.jpg` (jika kosong, dibuat ikon default).
2. Push ke GitHub (branch main/master) atau jalankan workflow manual.
3. Ambil `Annas-Tools-APK.zip` dari Actions > Artifacts atau Releases.
