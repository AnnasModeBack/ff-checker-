# Annas Tools Floating AI Engine (v7.0)

Native Android Overlay + Accessibility + WebView AI Solver (`com.annas.tools`) with Modular Skill-Card UI, Crisp Typography, and Zero-Slop Precision.

## Structure
- `AndroidManifest.xml`: Declares `SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE`, `BIND_ACCESSIBILITY_SERVICE`, and `MainActivity`.
- `MainActivity.java`: Controls overlay permission, accessibility settings, foreground floating bubble service, and WebView bridge.
- `FloatingAiService.java`: System-level floating hexagonal shield bubble that expands over any external APK with `AUTO_SOLVE = ON/OFF` 1-by-1 execution and Chrome search.
- `ScreenAutoService.java`: Accessibility service for reading active screen text (OCR/Node tree) and executing automated option selection (`A/B/C/D/E`).
- `app/src/main/assets/index.html`: Full-featured modular dark UI (`#090D16` / `#22D3EE` / `#22C55E`) synchronized with native floating controls.
