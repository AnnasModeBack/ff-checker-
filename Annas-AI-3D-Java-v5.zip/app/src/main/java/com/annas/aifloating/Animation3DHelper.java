package com.annas.aifloating;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

public class Animation3DHelper {

    public static void apply3DTiltEntrance(View view, long delayMs) {
        if (view == null) return;
        float density = view.getResources().getDisplayMetrics().density;
        view.setAlpha(0f);
        view.setScaleX(0.72f);
        view.setScaleY(0.72f);
        view.setRotationX(20f);
        view.setRotationY(-16f);
        view.setCameraDistance(16000f * density);

        view.animate()
                .setStartDelay(delayMs)
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .rotationX(0f)
                .rotationY(0f)
                .setDuration(460L)
                .setInterpolator(new OvershootInterpolator(1.3f))
                .start();
    }

    public static void start3DFloatingIconLoop(View view) {
        if (view == null) return;
        float density = view.getResources().getDisplayMetrics().density;
        view.setCameraDistance(14000f * density);

        PropertyValuesHolder rotY = PropertyValuesHolder.ofFloat(View.ROTATION_Y, -18f, 18f);
        PropertyValuesHolder sx = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.94f, 1.06f);
        PropertyValuesHolder sy = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.94f, 1.06f);

        ObjectAnimator anim = ObjectAnimator.ofPropertyValuesHolder(view, rotY, sx, sy);
        anim.setDuration(1600L);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setRepeatMode(ValueAnimator.REVERSE);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }

    public static void pop3DClick(final View view) {
        if (view == null) return;
        view.animate()
                .scaleX(0.88f)
                .scaleY(0.88f)
                .rotationY(14f)
                .setDuration(90L)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        view.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .rotationY(0f)
                                .setDuration(150L)
                                .setInterpolator(new OvershootInterpolator())
                                .start();
                    }
                })
                .start();
    }
}
