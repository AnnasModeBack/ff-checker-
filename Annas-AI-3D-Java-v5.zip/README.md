# Annas AI 3D Pro (Java Native Edition)

Aplikasi asisten tugas otomatis berbasis **Java murni** dengan **3D Floating Bubble**, **Kotak Penanda + Centang (✓) ke Google AI**, **Izin Pemberitahuan**, dan **100% Vector SVG Full HD**.

## Fitur Unggulan
- **Java Native Architecture:** Seluruh logika aplikasi ditulis menggunakan Java standar Android SDK tanpa ketergantungan Kotlin runtime berlebih.
- **Kotak Penanda AI + Centang (✓):** Tekan tombol kotak penanda, geser kotak ke area tugas/soal, ubah ukuran kotak sesuai kebutuhan, lalu ketuk tombol **Centang (✓)** untuk mengirim langsung ke **Google AI (`gemini-flash-latest`)**.
- **Animasi 3D & Full HD SVG:** Animasi rotasi 3D, tilt entrance, pop click 3D, serta seluruh ikon menggunakan Vector SVG tajam di semua ukuran layar.
- **Notifikasi Hasil AI:** Pemberitahuan status layanan dan hasil jawaban Google AI langsung muncul di panel notifikasi.
- **Anti-Gagal di GitHub Actions:** Workflow `.github/workflows/build-apk.yml` menonaktifkan cache bermasalah, mempertahankan file `.zip` di root, dan menghasilkan APK debug.
